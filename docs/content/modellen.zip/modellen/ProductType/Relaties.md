```mermaid
graph LR
7892caec-471a-11ee-a9ac-00163e71351b["crm:E99_Product_Type"]-->|"crm:P127_has_broader_term"|d1a3d1cc-5222-11ee-974d-00163e71351b["crm:E99_Product_Type"]
7892caec-471a-11ee-a9ac-00163e71351b["crm:E99_Product_Type"]-->|"crm:P137i_is_exemplified_by"|9475fd4e-4727-11ee-b0c4-00163e71351b["crm:E22_Human-Made_Object"]
d1a3d1cc-5222-11ee-974d-00163e71351b["crm:E99_Product_Type"]-.-d1a3d1cc-5222-11ee-974d-00163e71351b_s(["Productreeks"])
9475fd4e-4727-11ee-b0c4-00163e71351b["crm:E22_Human-Made_Object"]-.-9475fd4e-4727-11ee-b0c4-00163e71351b_s(["Product"])
style d1a3d1cc-5222-11ee-974d-00163e71351b_s stroke-dasharray: 5
style 9475fd4e-4727-11ee-b0c4-00163e71351b_s stroke-dasharray: 5
style 7892caec-471a-11ee-a9ac-00163e71351b fill:#ffa500
style 9475fd4e-4727-11ee-b0c4-00163e71351b fill:#B0927A
style d1a3d1cc-5222-11ee-974d-00163e71351b fill:#ffa500
```
