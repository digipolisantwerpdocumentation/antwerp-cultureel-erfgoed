```mermaid
graph LR
7892caec-471a-11ee-a9ac-00163e71351b["crm:E99_Product_Type"]-->|"crm:P3_has_note"|800ef872-471f-11ee-b0c4-00163e71351b(rdfs:Literal)
style 800ef872-471f-11ee-b0c4-00163e71351b_s stroke-dasharray: 5
800ef872-471f-11ee-b0c4-00163e71351b["rdfs:Literal"]-.-800ef872-471f-11ee-b0c4-00163e71351b_s(["Opmerking tekst"])
style 800ef872-471f-11ee-b0c4-00163e71351b fill:#D3D3D3
```
