```mermaid
graph LR
7892caec-471a-11ee-a9ac-00163e71351b["crm:E99_Product_Type"]-->|"crm:P2_has_type"|908c5cfe-4728-11ee-974d-00163e71351b["crm:E55_Type"]
908c5cfe-4728-11ee-974d-00163e71351b["crm:E55_Type"]-.-908c5cfe-4728-11ee-974d-00163e71351b_s(["Type"])
style 908c5cfe-4728-11ee-974d-00163e71351b_s stroke-dasharray: 5
style 7892caec-471a-11ee-a9ac-00163e71351b fill:#ffa500
style 908c5cfe-4728-11ee-974d-00163e71351b fill:#ffa500
```
