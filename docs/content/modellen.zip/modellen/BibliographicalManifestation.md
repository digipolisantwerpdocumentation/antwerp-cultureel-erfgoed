```mermaid
graph LR
024f06e7-94e9-11ee-b10b-960002548b4f["crm:E74_Group"]-->|"rdfs:label"|024f08dd-94e9-11ee-a867-960002548b4f(xsd:string)
0990a97a-936e-11ee-a1bf-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|0990acbf-936e-11ee-8fa2-960002548b4f(xsd:string)
0990ab90-936e-11ee-8276-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|0990ac3a-936e-11ee-b5b1-960002548b4f(xsd:string)
09e43c33-9363-11ee-814c-960002548b4f["crm:E53_Place"]-->|"crm:P3_has_note"|15fe2cb0-cb09-11ee-b492-960002548b4f(rdfs:Literal)
1025ca6d-94ea-11ee-b6c8-960002548b4f["crm:E33_Linguistic_Object"]-->|"crm:P190_has_symbolic_content"|1025cda9-94ea-11ee-ac93-960002548b4f(rdfs:Literal)
1025cd00-94ea-11ee-b23b-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|1025cf17-94ea-11ee-b0ea-960002548b4f(xsd:string)
1025ce29-94ea-11ee-97f2-960002548b4f["crm:E56_Language"]-->|"rdfs:label"|1025cea2-94ea-11ee-9b0f-960002548b4f(xsd:string)
1353d187-94e9-11ee-a929-960002548b4f["crm:E33_Linguistic_Object"]-->|"crm:P190_has_symbolic_content"|1353d5ab-94e9-11ee-ba06-960002548b4f(rdfs:Literal)
1353d387-94e9-11ee-aed3-960002548b4f["crm:E56_Language"]-->|"rdfs:label"|1353d445-94e9-11ee-aeb6-960002548b4f(xsd:string)
1353d4c6-94e9-11ee-b2f7-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|1353d539-94e9-11ee-b7c9-960002548b4f(xsd:string)
17e0cbc0-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P190_has_symbolic_content"|17e10388-8e93-11ee-8f9d-96a6d245525a(rdfs:Literal)
17e0d502-8e93-11ee-8f9d-96a6d245525a["crm:E35_Title"]-->|"crm:P190_has_symbolic_content"|17e110da-8e93-11ee-8f9d-96a6d245525a(rdfs:Literal)
17e0d8b8-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|17e1127e-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e0da7a-8e93-11ee-8f9d-96a6d245525a["crm:E42_Identifier"]-->|"crm:P190_has_symbolic_content"|17e112ba-8e93-11ee-8f9d-96a6d245525a(rdfs:Literal)
17e0dfca-8e93-11ee-8f9d-96a6d245525a["crm:E39_Actor"]-->|"rdfs:label"|17e0f10e-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e0e34e-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|17e11530-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e0e894-8e93-11ee-8f9d-96a6d245525a["crm:E4_Period"]-->|"rdfs:label"|17e115c6-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e0ea4c-8e93-11ee-8f9d-96a6d245525a["crm:E53_Place"]-->|"rdfs:label"|17e11652-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e0ec04-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P190_has_symbolic_content"|17e11724-8e93-11ee-8f9d-96a6d245525a(rdfs:Literal)
17e0edc6-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P190_has_symbolic_content"|17e117f6-8e93-11ee-8f9d-96a6d245525a(rdfs:Literal)
17e0efec-8e93-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-->|"crm:P3_has_note"|cb795e8e-cb07-11ee-b504-960002548b4f(rdfs:Literal)
17e0f3de-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|17e0fb22-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e0f708-8e93-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-->|"crm:P190_has_symbolic_content"|17e0f74e-8e93-11ee-8f9d-96a6d245525a(rdfs:Literal)
17e0f794-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|17e0f7da-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e0f820-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|17e0f866-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e0f8f2-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P190_has_symbolic_content"|17e0f938-8e93-11ee-8f9d-96a6d245525a(rdfs:Literal)
17e0f9c4-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|17e0f97e-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e0fa96-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]-->|"rdfs:label"|17e0fa0a-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e0fcee-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P190_has_symbolic_content"|17e0fd34-8e93-11ee-8f9d-96a6d245525a(rdfs:Literal)
17e0fdc0-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|17e0fd7a-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e0fe60-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]-->|"rdfs:label"|17e0fe06-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e0fff0-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|17e1007c-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e10036-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|17e100c2-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e102c0-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|17e10414-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e10324-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]-->|"rdfs:label"|17e103ce-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e1059a-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P190_has_symbolic_content"|17e105e0-8e93-11ee-8f9d-96a6d245525a(rdfs:Literal)
17e10676-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|17e10626-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e10702-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]-->|"rdfs:label"|17e106bc-8e93-11ee-8f9d-96a6d245525a(xsd:string)
0990a97a-936e-11ee-a1bf-960002548b4f["crm:E55_Type"]-->|"crm:P2_has_type"|0990ab90-936e-11ee-8276-960002548b4f["crm:E55_Type"]
09e43c33-9363-11ee-814c-960002548b4f["crm:E53_Place"]-->|"crm:P1_is_identified_by"|30725f2f-94e9-11ee-85c8-960002548b4f["crm:E42_Identifier"]
09e43c33-9363-11ee-814c-960002548b4f["crm:E53_Place"]-->|"crm:P1_is_identified_by"|b26c0ceb-94f9-11ee-8f0f-960002548b4f["crm:E41_Appellation"]
09e43c33-9363-11ee-814c-960002548b4f["crm:E53_Place"]-->|"crm:P129i_is_subject_of"|1025ca6d-94ea-11ee-b6c8-960002548b4f["crm:E33_Linguistic_Object"]
09e43c33-9363-11ee-814c-960002548b4f["crm:E53_Place"]-->|"crm:P2_has_type"|f5911ec5-94e8-11ee-ad8d-960002548b4f["crm:E55_Type"]
09e43c33-9363-11ee-814c-960002548b4f["crm:E53_Place"]-->|"crm:P53i_is_former_or_current_location_of"|5a62c11c-94f1-11ee-9220-960002548b4f["crm:E22_Human-Made_Object"]
09e43c33-9363-11ee-814c-960002548b4f["crm:E53_Place"]-->|"crm:P67i_is_referred_to_by"|1353d187-94e9-11ee-a929-960002548b4f["crm:E33_Linguistic_Object"]
09e43c33-9363-11ee-814c-960002548b4f["crm:E53_Place"]-->|"crm:P67i_is_referred_to_by"|4124c22a-94e9-11ee-baab-960002548b4f["lrm:F3_Manifestation"]
09e43c33-9363-11ee-814c-960002548b4f["crm:E53_Place"]-->|"crm:P74i_is_current_or_former_residence_of"|024f06e7-94e9-11ee-b10b-960002548b4f["crm:E74_Group"]
1025ca6d-94ea-11ee-b6c8-960002548b4f["crm:E33_Linguistic_Object"]-->|"crm:P2_has_type"|1025cd00-94ea-11ee-b23b-960002548b4f["crm:E55_Type"]
1025ca6d-94ea-11ee-b6c8-960002548b4f["crm:E33_Linguistic_Object"]-->|"crm:P72_has_language"|1025ce29-94ea-11ee-97f2-960002548b4f["crm:E56_Language"]
1353d187-94e9-11ee-a929-960002548b4f["crm:E33_Linguistic_Object"]-->|"crm:P2_has_type"|1353d4c6-94e9-11ee-b2f7-960002548b4f["crm:E55_Type"]
1353d187-94e9-11ee-a929-960002548b4f["crm:E33_Linguistic_Object"]-->|"crm:P72_has_language"|1353d387-94e9-11ee-aed3-960002548b4f["crm:E56_Language"]
17e0c936-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P72_has_language"|17e10752-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]
17e0cbc0-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P2_has_type"|17e102c0-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]
17e0cbc0-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P72_has_language"|17e10324-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]
17e0cdb4-8e93-11ee-8f9d-96a6d245525a["crm:PC130_shows_features_of"]-->|"crm:P02_has_range"|17e10d06-8e93-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]
17e0cdb4-8e93-11ee-8f9d-96a6d245525a["crm:PC130_shows_features_of"]-->|"crm:P130.1_kind_of_similarity"|17e0f3de-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]
17e0cf8a-8e93-11ee-8f9d-96a6d245525a["crm:E31_Document"]-->|"crm:P1_is_identified_by"|17e0f398-8e93-11ee-8f9d-96a6d245525a["crm:E42_Identifier"]
17e0cf8a-8e93-11ee-8f9d-96a6d245525a["crm:E31_Document"]-->|"crm:P1_is_identified_by"|17e0f708-8e93-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]
17e0cf8a-8e93-11ee-8f9d-96a6d245525a["crm:E31_Document"]-->|"crm:P2_has_type"|17e10c7a-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]
17e0d156-8e93-11ee-8f9d-96a6d245525a["crm:E54_Dimension"]-->|"crm:P129i_is_subject_of"|17e0f8f2-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]
17e0d156-8e93-11ee-8f9d-96a6d245525a["crm:E54_Dimension"]-->|"crm:P129i_is_subject_of"|17e0fcee-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]
17e0d156-8e93-11ee-8f9d-96a6d245525a["crm:E54_Dimension"]-->|"crm:P129i_is_subject_of"|17e1059a-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]
17e0d156-8e93-11ee-8f9d-96a6d245525a["crm:E54_Dimension"]-->|"crm:P129i_is_subject_of"|17e10798-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]
17e0d156-8e93-11ee-8f9d-96a6d245525a["crm:E54_Dimension"]-->|"crm:P129i_is_subject_of"|17e10d4c-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]
17e0d156-8e93-11ee-8f9d-96a6d245525a["crm:E54_Dimension"]-->|"crm:P2_has_type"|17e0fff0-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]
17e0d156-8e93-11ee-8f9d-96a6d245525a["crm:E54_Dimension"]-->|"crm:P2_has_type"|17e10d92-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]
17e0d156-8e93-11ee-8f9d-96a6d245525a["crm:E54_Dimension"]-->|"crm:P43i_is_dimension_of"|17e10a4a-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]
17e0d502-8e93-11ee-8f9d-96a6d245525a["crm:E35_Title"]-->|"crm:P2_has_type"|17e11094-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]
17e0d502-8e93-11ee-8f9d-96a6d245525a["crm:E35_Title"]-->|"crm:P72_has_language"|17e11008-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]
17e0d8b8-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"crm:P2_has_type"|17e111f2-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]
17e0da7a-8e93-11ee-8f9d-96a6d245525a["crm:E42_Identifier"]-->|"crm:P2_has_type"|17e11300-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]
17e0dfca-8e93-11ee-8f9d-96a6d245525a["crm:E39_Actor"]-->|"crm:P2_has_type"|18620f96-934b-11ee-b409-960002548b4f["crm:E55_Type"]
17e0e34e-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"crm:P2_has_type"|a93af378-934a-11ee-a78f-960002548b4f["crm:E55_Type"]
17e0e894-8e93-11ee-8f9d-96a6d245525a["crm:E4_Period"]-->|"crm:P2_has_type"|e4f6427b-934a-11ee-a55c-960002548b4f["crm:E55_Type"]
17e0ea4c-8e93-11ee-8f9d-96a6d245525a["crm:E53_Place"]-->|"crm:P2_has_type"|c8e6299f-934a-11ee-ba61-960002548b4f["crm:E55_Type"]
17e0ec04-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P2_has_type"|17e11698-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]
17e0ec04-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P72_has_language"|17e116de-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]
17e0edc6-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P2_has_type"|17e11878-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]
17e0edc6-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P72_has_language"|17e11904-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]
17e0efec-8e93-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-->|"lrm:R24i_was_created_through"|b2832db2-8e98-11ee-8f9d-96a6d245525a["lrm:F30_Manifestation_Creation"]
17e0efec-8e93-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-->|"crm:P01i_is_domain_of"|17e0cdb4-8e93-11ee-8f9d-96a6d245525a["crm:PC130_shows_features_of"]
17e0efec-8e93-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-->|"crm:P1_is_identified_by"|17e0da7a-8e93-11ee-8f9d-96a6d245525a["crm:E42_Identifier"]
17e0efec-8e93-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-->|"crm:P1_is_identified_by"|c538dbd4-cf15-11ee-aabf-960002548b4f["crm:E42_Identifier"]
17e0efec-8e93-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-->|"crm:P102_has_title"|17e0d502-8e93-11ee-8f9d-96a6d245525a["crm:E35_Title"]
17e0efec-8e93-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-->|"crm:P106_is_composed_of"|17e0c936-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]
17e0efec-8e93-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-->|"crm:P129_is_about"|17e0dfca-8e93-11ee-8f9d-96a6d245525a["crm:E39_Actor"]
17e0efec-8e93-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-->|"crm:P129_is_about"|17e0e34e-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]
17e0efec-8e93-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-->|"crm:P129_is_about"|17e0e894-8e93-11ee-8f9d-96a6d245525a["crm:E4_Period"]
17e0efec-8e93-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-->|"crm:P129_is_about"|17e0ea4c-8e93-11ee-8f9d-96a6d245525a["crm:E53_Place"]
17e0efec-8e93-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-->|"crm:P129_is_about"|7f378e46-934b-11ee-8649-960002548b4f["crm:E22_Human-Made_Object"]
17e0efec-8e93-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-->|"crm:P129i_is_subject_of"|17e0cbc0-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]
17e0efec-8e93-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-->|"crm:P129i_is_subject_of"|17e0edc6-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]
17e0efec-8e93-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-->|"crm:P148_has_component"|654f9122-8e96-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]
17e0efec-8e93-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-->|"crm:P148i_is_component_of"|5aca3730-8e95-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]
17e0efec-8e93-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-->|"crm:P2_has_type"|0990a97a-936e-11ee-a1bf-960002548b4f["crm:E55_Type"]
17e0efec-8e93-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-->|"crm:P2_has_type"|17e0d8b8-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]
17e0efec-8e93-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-->|"crm:P43_has_dimension"|17e0d156-8e93-11ee-8f9d-96a6d245525a["crm:E54_Dimension"]
17e0efec-8e93-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-->|"crm:P67_refers_to"|09e43c33-9363-11ee-814c-960002548b4f["crm:E53_Place"]
17e0efec-8e93-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-->|"crm:P67i_is_referred_to_by"|17e0ec04-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]
17e0efec-8e93-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-->|"crm:P70i_is_documented_in"|17e0cf8a-8e93-11ee-8f9d-96a6d245525a["crm:E31_Document"]
17e0efec-8e93-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-->|"crm:P94i_was_created_by"|af0a497a-8e9a-11ee-8f9d-96a6d245525a["lrm:F28_Expression_Creation"]
17e0f708-8e93-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-->|"crm:P2_has_type"|17e0f794-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]
17e0f8f2-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P2_has_type"|17e0f9c4-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]
17e0f8f2-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P72_has_language"|17e0fa96-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]
17e0fcee-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P2_has_type"|17e0fdc0-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]
17e0fcee-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P72_has_language"|17e0fe60-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]
0990ab90-936e-11ee-8276-960002548b4f["crm:E55_Type"]-.-0990ab90-936e-11ee-8276-960002548b4f_s(["Mediumtype type"])
30725f2f-94e9-11ee-85c8-960002548b4f["crm:E42_Identifier"]-.-30725f2f-94e9-11ee-85c8-960002548b4f_s(["Location Identifier"])
b26c0ceb-94f9-11ee-8f0f-960002548b4f["crm:E41_Appellation"]-.-b26c0ceb-94f9-11ee-8f0f-960002548b4f_s(["Location Name"])
1025ca6d-94ea-11ee-b6c8-960002548b4f["crm:E33_Linguistic_Object"]-.-1025ca6d-94ea-11ee-b6c8-960002548b4f_s(["Holding Information"])
f5911ec5-94e8-11ee-ad8d-960002548b4f["crm:E55_Type"]-.-f5911ec5-94e8-11ee-ad8d-960002548b4f_s(["Plaatskenmerk type"])
15fe2cb0-cb09-11ee-b492-960002548b4f["rdfs:Literal"]-.-15fe2cb0-cb09-11ee-b492-960002548b4f_s(["Plaatskenmerk opmerking"])
5a62c11c-94f1-11ee-9220-960002548b4f["crm:E22_Human-Made_Object"]-.-5a62c11c-94f1-11ee-9220-960002548b4f_s(["Volume"])
1353d187-94e9-11ee-a929-960002548b4f["crm:E33_Linguistic_Object"]-.-1353d187-94e9-11ee-a929-960002548b4f_s(["Location Annotation"])
4124c22a-94e9-11ee-baab-960002548b4f["lrm:F3_Manifestation"]-.-4124c22a-94e9-11ee-baab-960002548b4f_s(["Convoluut manifestatie"])
024f06e7-94e9-11ee-b10b-960002548b4f["crm:E74_Group"]-.-024f06e7-94e9-11ee-b10b-960002548b4f_s(["Bibliotheek"])
1025cda9-94ea-11ee-ac93-960002548b4f["rdfs:Literal"]-.-1025cda9-94ea-11ee-ac93-960002548b4f_s(["Bezitsinformatie"])
1025cd00-94ea-11ee-b23b-960002548b4f["crm:E55_Type"]-.-1025cd00-94ea-11ee-b23b-960002548b4f_s(["Bezitsinformatie type"])
1025ce29-94ea-11ee-97f2-960002548b4f["crm:E56_Language"]-.-1025ce29-94ea-11ee-97f2-960002548b4f_s(["Bezitsinformatie taal"])
1353d5ab-94e9-11ee-ba06-960002548b4f["rdfs:Literal"]-.-1353d5ab-94e9-11ee-ba06-960002548b4f_s(["Plaatskenmerk toelichting"])
1353d4c6-94e9-11ee-b2f7-960002548b4f["crm:E55_Type"]-.-1353d4c6-94e9-11ee-b2f7-960002548b4f_s(["Plaatskenmerk toelichting type"])
1353d387-94e9-11ee-aed3-960002548b4f["crm:E56_Language"]-.-1353d387-94e9-11ee-aed3-960002548b4f_s(["Plaatskenmerk toelichting taal"])
17e10752-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]-.-17e10752-8e93-11ee-8f9d-96a6d245525a_s(["Taal"])
17e10388-8e93-11ee-8f9d-96a6d245525a["rdfs:Literal"]-.-17e10388-8e93-11ee-8f9d-96a6d245525a_s(["Editie"])
17e102c0-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-17e102c0-8e93-11ee-8f9d-96a6d245525a_s(["Editie type"])
17e10324-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]-.-17e10324-8e93-11ee-8f9d-96a6d245525a_s(["Editie taal"])
17e10d06-8e93-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-.-17e10d06-8e93-11ee-8f9d-96a6d245525a_s(["Gelijkaardige manifestatie"])
17e0f3de-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-17e0f3de-8e93-11ee-8f9d-96a6d245525a_s(["Gelijkenis type"])
17e0f398-8e93-11ee-8f9d-96a6d245525a["crm:E42_Identifier"]-.-17e0f398-8e93-11ee-8f9d-96a6d245525a_s(["Document URL"])
17e0f708-8e93-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-.-17e0f708-8e93-11ee-8f9d-96a6d245525a_s(["Document Name"])
17e10c7a-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-17e10c7a-8e93-11ee-8f9d-96a6d245525a_s(["Document type"])
17e0f8f2-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-.-17e0f8f2-8e93-11ee-8f9d-96a6d245525a_s(["Collation Accompanying Material"])
17e0fcee-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-.-17e0fcee-8e93-11ee-8f9d-96a6d245525a_s(["Collation ISBD"])
17e1059a-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-.-17e1059a-8e93-11ee-8f9d-96a6d245525a_s(["Collation Illustration"])
17e10798-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-.-17e10798-8e93-11ee-8f9d-96a6d245525a_s(["Collation Size"])
17e10d4c-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-.-17e10d4c-8e93-11ee-8f9d-96a6d245525a_s(["Collation Pagination"])
17e0fff0-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-17e0fff0-8e93-11ee-8f9d-96a6d245525a_s(["Formaat"])
17e10d92-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-17e10d92-8e93-11ee-8f9d-96a6d245525a_s(["Collatie type"])
17e10a4a-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-.-17e10a4a-8e93-11ee-8f9d-96a6d245525a_s(["Collation Section Structure"])
17e110da-8e93-11ee-8f9d-96a6d245525a["rdfs:Literal"]-.-17e110da-8e93-11ee-8f9d-96a6d245525a_s(["Titel"])
17e11094-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-17e11094-8e93-11ee-8f9d-96a6d245525a_s(["Titel type"])
17e11008-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]-.-17e11008-8e93-11ee-8f9d-96a6d245525a_s(["Titel taal"])
17e111f2-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-17e111f2-8e93-11ee-8f9d-96a6d245525a_s(["Publicatietype type"])
17e112ba-8e93-11ee-8f9d-96a6d245525a["rdfs:Literal"]-.-17e112ba-8e93-11ee-8f9d-96a6d245525a_s(["Manifestatie identificator (c-loi, maar ook ISBN, OCLC, ...)"])
17e11300-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-17e11300-8e93-11ee-8f9d-96a6d245525a_s(["Manifestatie identificator type"])
18620f96-934b-11ee-b409-960002548b4f["crm:E55_Type"]-.-18620f96-934b-11ee-b409-960002548b4f_s(["Onderwerp agent type"])
a93af378-934a-11ee-a78f-960002548b4f["crm:E55_Type"]-.-a93af378-934a-11ee-a78f-960002548b4f_s(["Onderwerp concept type"])
e4f6427b-934a-11ee-a55c-960002548b4f["crm:E55_Type"]-.-e4f6427b-934a-11ee-a55c-960002548b4f_s(["Onderwerp periode type"])
c8e6299f-934a-11ee-ba61-960002548b4f["crm:E55_Type"]-.-c8e6299f-934a-11ee-ba61-960002548b4f_s(["Onderwerp plaats"])
17e11724-8e93-11ee-8f9d-96a6d245525a["rdfs:Literal"]-.-17e11724-8e93-11ee-8f9d-96a6d245525a_s(["Manifestatie toelichting"])
17e11698-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-17e11698-8e93-11ee-8f9d-96a6d245525a_s(["Manifestatie toelichting type"])
17e116de-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]-.-17e116de-8e93-11ee-8f9d-96a6d245525a_s(["Manifestatie toelichting taal"])
17e117f6-8e93-11ee-8f9d-96a6d245525a["rdfs:Literal"]-.-17e117f6-8e93-11ee-8f9d-96a6d245525a_s(["Manifestatie beschrijving"])
17e11878-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-17e11878-8e93-11ee-8f9d-96a6d245525a_s(["Manifestatie beschrijving type"])
17e11904-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]-.-17e11904-8e93-11ee-8f9d-96a6d245525a_s(["Manifestatie beschrijving taal"])
b2832db2-8e98-11ee-8f9d-96a6d245525a["lrm:F30_Manifestation_Creation"]-.-b2832db2-8e98-11ee-8f9d-96a6d245525a_s(["Manifestation Creation"])
17e0cdb4-8e93-11ee-8f9d-96a6d245525a["crm:PC130_shows_features_of"]-.-17e0cdb4-8e93-11ee-8f9d-96a6d245525a_s(["Similarity"])
17e0da7a-8e93-11ee-8f9d-96a6d245525a["crm:E42_Identifier"]-.-17e0da7a-8e93-11ee-8f9d-96a6d245525a_s(["Manifestation Identifier"])
c538dbd4-cf15-11ee-aabf-960002548b4f["crm:E42_Identifier"]-.-c538dbd4-cf15-11ee-aabf-960002548b4f_s(["Manifestation Identifier Other"])
17e0d502-8e93-11ee-8f9d-96a6d245525a["crm:E35_Title"]-.-17e0d502-8e93-11ee-8f9d-96a6d245525a_s(["Title"])
17e0c936-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-.-17e0c936-8e93-11ee-8f9d-96a6d245525a_s(["Linguistic Object"])
17e0dfca-8e93-11ee-8f9d-96a6d245525a["crm:E39_Actor"]-.-17e0dfca-8e93-11ee-8f9d-96a6d245525a_s(["Onderwerp agent"])
17e0e34e-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-17e0e34e-8e93-11ee-8f9d-96a6d245525a_s(["Onderwerp concept"])
17e0e894-8e93-11ee-8f9d-96a6d245525a["crm:E4_Period"]-.-17e0e894-8e93-11ee-8f9d-96a6d245525a_s(["Onderwerp periode"])
17e0ea4c-8e93-11ee-8f9d-96a6d245525a["crm:E53_Place"]-.-17e0ea4c-8e93-11ee-8f9d-96a6d245525a_s(["Onderwerp plaats"])
7f378e46-934b-11ee-8649-960002548b4f["crm:E22_Human-Made_Object"]-.-7f378e46-934b-11ee-8649-960002548b4f_s(["Onderwerp object"])
17e0cbc0-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-.-17e0cbc0-8e93-11ee-8f9d-96a6d245525a_s(["Edition"])
17e0edc6-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-.-17e0edc6-8e93-11ee-8f9d-96a6d245525a_s(["Manifestation Description"])
654f9122-8e96-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-.-654f9122-8e96-11ee-8f9d-96a6d245525a_s(["Heeft component manifestatie"])
5aca3730-8e95-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-.-5aca3730-8e95-11ee-8f9d-96a6d245525a_s(["Is component van manifestatie"])
0990a97a-936e-11ee-a1bf-960002548b4f["crm:E55_Type"]-.-0990a97a-936e-11ee-a1bf-960002548b4f_s(["Mediumtype"])
17e0d8b8-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-17e0d8b8-8e93-11ee-8f9d-96a6d245525a_s(["Publicatietype"])
cb795e8e-cb07-11ee-b504-960002548b4f["rdfs:Literal"]-.-cb795e8e-cb07-11ee-b504-960002548b4f_s(["Manifestatie opmerking"])
17e0d156-8e93-11ee-8f9d-96a6d245525a["crm:E54_Dimension"]-.-17e0d156-8e93-11ee-8f9d-96a6d245525a_s(["Dimension"])
09e43c33-9363-11ee-814c-960002548b4f["crm:E53_Place"]-.-09e43c33-9363-11ee-814c-960002548b4f_s(["Plaatskenmerk"])
17e0ec04-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-.-17e0ec04-8e93-11ee-8f9d-96a6d245525a_s(["Manifestation Annotation"])
17e0cf8a-8e93-11ee-8f9d-96a6d245525a["crm:E31_Document"]-.-17e0cf8a-8e93-11ee-8f9d-96a6d245525a_s(["Document"])
af0a497a-8e9a-11ee-8f9d-96a6d245525a["lrm:F28_Expression_Creation"]-.-af0a497a-8e9a-11ee-8f9d-96a6d245525a_s(["Expression Creation"])
17e0f74e-8e93-11ee-8f9d-96a6d245525a["rdfs:Literal"]-.-17e0f74e-8e93-11ee-8f9d-96a6d245525a_s(["Document"])
17e0f794-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-17e0f794-8e93-11ee-8f9d-96a6d245525a_s(["Document naam type"])
17e0f938-8e93-11ee-8f9d-96a6d245525a["rdfs:Literal"]-.-17e0f938-8e93-11ee-8f9d-96a6d245525a_s(["Begeleidend materiaal"])
17e0f9c4-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-17e0f9c4-8e93-11ee-8f9d-96a6d245525a_s(["Begeleidend materiaal type"])
17e0fa96-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]-.-17e0fa96-8e93-11ee-8f9d-96a6d245525a_s(["Begeleidend materiaal taal"])
17e0fd34-8e93-11ee-8f9d-96a6d245525a["rdfs:Literal"]-.-17e0fd34-8e93-11ee-8f9d-96a6d245525a_s(["Collatie ISBD"])
17e0fdc0-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-17e0fdc0-8e93-11ee-8f9d-96a6d245525a_s(["Collatie ISBD type"])
17e0fe60-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]-.-17e0fe60-8e93-11ee-8f9d-96a6d245525a_s(["Collatie ISBD taal"])
17e10752-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]-->|"rdfs:label"|17e1194a-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e10798-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P190_has_symbolic_content"|17e107de-8e93-11ee-8f9d-96a6d245525a(rdfs:Literal)
17e1086a-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|17e10824-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e108f6-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]-->|"rdfs:label"|17e108b0-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e10a4a-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P190_has_symbolic_content"|17e10a90-8e93-11ee-8f9d-96a6d245525a(rdfs:Literal)
17e10b1c-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|17e10ad6-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e10bee-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]-->|"rdfs:label"|17e10b62-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e10c7a-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|17e0f23a-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e10d4c-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P190_has_symbolic_content"|17e10e28-8e93-11ee-8f9d-96a6d245525a(rdfs:Literal)
17e10d92-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|17e10dd8-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e10eaa-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|17e10ef0-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e10f36-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]-->|"rdfs:label"|17e10e6e-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e11008-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]-->|"rdfs:label"|17e11120-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e11094-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|17e1104e-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e111f2-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|17e11238-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e11300-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|17e11346-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e11698-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|17e117b0-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e116de-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]-->|"rdfs:label"|17e1176a-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e11878-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|17e1183c-8e93-11ee-8f9d-96a6d245525a(xsd:string)
17e11904-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]-->|"rdfs:label"|17e118be-8e93-11ee-8f9d-96a6d245525a(xsd:string)
18620f96-934b-11ee-b409-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|186212b9-934b-11ee-afd4-960002548b4f(xsd:string)
2d1ec11f-94f8-11ee-a675-960002548b4f["crm:E33_Linguistic_Object"]-->|"crm:P190_has_symbolic_content"|2d1ec47d-94f8-11ee-b762-960002548b4f(rdfs:Literal)
2d1ec336-94f8-11ee-9c4b-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|2d1ec584-94f8-11ee-8a85-960002548b4f(xsd:string)
2d1ec3e7-94f8-11ee-96de-960002548b4f["crm:E56_Language"]-->|"rdfs:label"|2d1ec50a-94f8-11ee-b549-960002548b4f(xsd:string)
30725f2f-94e9-11ee-85c8-960002548b4f["crm:E42_Identifier"]-->|"crm:P190_has_symbolic_content"|30726293-94e9-11ee-8137-960002548b4f(rdfs:Literal)
3072613d-94e9-11ee-99cf-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|30726213-94e9-11ee-9f22-960002548b4f(xsd:string)
37fd48e9-cf15-11ee-b45f-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|37fd4c54-cf15-11ee-bbd2-960002548b4f(xsd:string)
5a62c11c-94f1-11ee-9220-960002548b4f["crm:E22_Human-Made_Object"]-->|"crm:P3_has_note"|4aa5cc92-cb12-11ee-a964-960002548b4f(rdfs:Literal)
5ccfc3f7-934c-11ee-8da1-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|8239f35e-934c-11ee-9e1e-960002548b4f(xsd:string)
7f378e46-934b-11ee-8649-960002548b4f["crm:E22_Human-Made_Object"]-->|"rdfs:label"|1ddfcd21-934c-11ee-bd20-960002548b4f(xsd:string)
83463627-934d-11ee-9e33-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|834639ce-934d-11ee-a516-960002548b4f(xsd:string)
960a47dc-94fe-11ee-9c98-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|960a4b26-94fe-11ee-a096-960002548b4f(xsd:string)
a13e386b-934d-11ee-a820-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|a13e3c31-934d-11ee-a98f-960002548b4f(xsd:string)
a5ab2f50-94fa-11ee-a37e-960002548b4f["crm:E41_Appellation"]-->|"crm:P190_has_symbolic_content"|b9ff70f4-94fa-11ee-8c90-960002548b4f(rdfs:Literal)
a93af378-934a-11ee-a78f-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|a93af6be-934a-11ee-97cd-960002548b4f(xsd:string)
af0a4c36-8e9a-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-->|"crm:P190_has_symbolic_content"|af0a4cb8-8e9a-11ee-8f9d-96a6d245525a(rdfs:Literal)
af0a4d1c-8e9a-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|af0a4d94-8e9a-11ee-8f9d-96a6d245525a(xsd:string)
af0a4df8-8e9a-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|af0a4b96-8e9a-11ee-8f9d-96a6d245525a(xsd:string)
af0a4e70-8e9a-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-->|"crm:P190_has_symbolic_content"|af0a4ed4-8e9a-11ee-8f9d-96a6d245525a(rdfs:Literal)
af0a4f42-8e9a-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|af0a4fb0-8e9a-11ee-8f9d-96a6d245525a(xsd:string)
af0a508c-8e9a-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-->|"crm:P190_has_symbolic_content"|af0a50f0-8e9a-11ee-8f9d-96a6d245525a(rdfs:Literal)
af0a515e-8e9a-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|af0a51b8-8e9a-11ee-8f9d-96a6d245525a(xsd:string)
af0a5226-8e9a-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-->|"crm:P190_has_symbolic_content"|af0a5294-8e9a-11ee-8f9d-96a6d245525a(rdfs:Literal)
af0a52ee-8e9a-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|af0a5366-8e9a-11ee-8f9d-96a6d245525a(xsd:string)
af0a542e-8e9a-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-->|"crm:P190_has_symbolic_content"|af0a54a6-8e9a-11ee-8f9d-96a6d245525a(rdfs:Literal)
af0a550a-8e9a-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|af0a5578-8e9a-11ee-8f9d-96a6d245525a(xsd:string)
af0a564a-8e9a-11ee-8f9d-96a6d245525a["crm:E39_Actor"]-->|"rdfs:label"|af0a56ae-8e9a-11ee-8f9d-96a6d245525a(xsd:string)
af0a5712-8e9a-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|af0a55dc-8e9a-11ee-8f9d-96a6d245525a(xsd:string)
af0a5780-8e9a-11ee-8f9d-96a6d245525a["crm:E39_Actor"]-->|"rdfs:label"|af0a501e-8e9a-11ee-8f9d-96a6d245525a(xsd:string)
b26c0ceb-94f9-11ee-8f0f-960002548b4f["crm:E41_Appellation"]-->|"crm:P190_has_symbolic_content"|c49a56a0-94f9-11ee-9be8-960002548b4f(rdfs:Literal)
b2832f1a-8e98-11ee-8f9d-96a6d245525a["crm:E39_Actor"]-->|"rdfs:label"|b2832fe2-8e98-11ee-8f9d-96a6d245525a(xsd:string)
b2833032-8e98-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-->|"crm:P190_has_symbolic_content"|b2833078-8e98-11ee-8f9d-96a6d245525a(rdfs:Literal)
b28330c8-8e98-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|b283310e-8e98-11ee-8f9d-96a6d245525a(xsd:string)
b2833154-8e98-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-->|"crm:P190_has_symbolic_content"|b283319a-8e98-11ee-8f9d-96a6d245525a(rdfs:Literal)
b2833276-8e98-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-->|"crm:P190_has_symbolic_content"|b28332bc-8e98-11ee-8f9d-96a6d245525a(rdfs:Literal)
b2833398-8e98-11ee-8f9d-96a6d245525a["crm:E52_Time-Span"]-->|"crm:P82a_begin_of_the_begin"|b283342e-8e98-11ee-8f9d-96a6d245525a(rdfs:Literal)
b2833398-8e98-11ee-8f9d-96a6d245525a["crm:E52_Time-Span"]-->|"crm:P82b_end_of_the_end"|b28334c4-8e98-11ee-8f9d-96a6d245525a(rdfs:Literal)
b2833474-8e98-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"rdfs:label"|b283355a-8e98-11ee-8f9d-96a6d245525a(xsd:string)
b283350a-8e98-11ee-8f9d-96a6d245525a["crm:E53_Place"]-->|"rdfs:label"|b2832f88-8e98-11ee-8f9d-96a6d245525a(xsd:string)
c538dbd4-cf15-11ee-aabf-960002548b4f["crm:E42_Identifier"]-->|"crm:P190_has_symbolic_content"|c538dea4-cf15-11ee-971a-960002548b4f(rdfs:Literal)
c538df27-cf15-11ee-be5d-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|c538ddf8-cf15-11ee-b62b-960002548b4f(xsd:string)
c8e6299f-934a-11ee-ba61-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|c8e62cfe-934a-11ee-bd35-960002548b4f(xsd:string)
e4f6427b-934a-11ee-a55c-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|e4f645cb-934a-11ee-b60e-960002548b4f(xsd:string)
f5911ec5-94e8-11ee-ad8d-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|f59120f1-94e8-11ee-a417-960002548b4f(xsd:string)
f59121a0-94e8-11ee-b33b-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|f5912226-94e8-11ee-94e7-960002548b4f(xsd:string)
f5e2e871-94fa-11ee-bc5a-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|f5e2ebc1-94fa-11ee-b1d8-960002548b4f(xsd:string)
style af0a4cb8-8e9a-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 5aca3730-8e95-11ee-8f9d-96a6d245525a fill:#ffff00
style b9ff70f4-94fa-11ee-8c90-960002548b4f fill:#D3D3D3
style 1025cf17-94ea-11ee-b0ea-960002548b4f fill:#D3D3D3
style 17e10f36-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style 17e0f8f2-8e93-11ee-8f9d-96a6d245525a fill:#ffff00
style 1ddfcd21-934c-11ee-bd20-960002548b4f fill:#D3D3D3
style 17e10324-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style af0a550a-8e9a-11ee-8f9d-96a6d245525a fill:#ffa500
style 17e0da7a-8e93-11ee-8f9d-96a6d245525a fill:#EEE8AA
style 2d1ec47d-94f8-11ee-b762-960002548b4f fill:#D3D3D3
style 17e0fa96-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style c538df27-cf15-11ee-be5d-960002548b4f fill:#ffa500
style 2d1ec3e7-94f8-11ee-96de-960002548b4f fill:#ffa500
style e4f6427b-934a-11ee-a55c-960002548b4f fill:#ffa500
style 17e0fe60-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style f5912226-94e8-11ee-94e7-960002548b4f fill:#D3D3D3
style 0990ac3a-936e-11ee-b5b1-960002548b4f fill:#D3D3D3
style af0a57da-8e9a-11ee-8f9d-96a6d245525a fill:#ffffff
style af0a4f42-8e9a-11ee-8f9d-96a6d245525a fill:#ffa500
style 1353d387-94e9-11ee-aed3-960002548b4f fill:#ffa500
style 4124c22a-94e9-11ee-baab-960002548b4f fill:#ffff00
style 17e0f794-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style b2833032-8e98-11ee-8f9d-96a6d245525a fill:#EEE8AA
style 17e1176a-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e11652-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e0f938-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e0f7da-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style f5e2e871-94fa-11ee-bc5a-960002548b4f fill:#ffa500
style 7f378e46-934b-11ee-8649-960002548b4f fill:#B0927A
style 17e11238-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 1025cda9-94ea-11ee-ac93-960002548b4f fill:#D3D3D3
style 960a4b26-94fe-11ee-a096-960002548b4f fill:#D3D3D3
style 17e0fd7a-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e0fff0-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style 17e0cbc0-8e93-11ee-8f9d-96a6d245525a fill:#ffff00
style a13e386b-934d-11ee-a820-960002548b4f fill:#ffa500
style f5911ec5-94e8-11ee-ad8d-960002548b4f fill:#ffa500
style 5a62c11c-94f1-11ee-9220-960002548b4f fill:#B0927A
style af0a4b96-8e9a-11ee-8f9d-96a6d245525a fill:#D3D3D3
style af0a564a-8e9a-11ee-8f9d-96a6d245525a fill:#ffc0cb
style 17e107de-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e0f398-8e93-11ee-8f9d-96a6d245525a fill:#EEE8AA
style 30725f2f-94e9-11ee-85c8-960002548b4f fill:#EEE8AA
style 17e0fa0a-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 0990a97a-936e-11ee-a1bf-960002548b4f fill:#ffa500
style 17e10a4a-8e93-11ee-8f9d-96a6d245525a fill:#ffff00
style 17e1059a-8e93-11ee-8f9d-96a6d245525a fill:#ffff00
style 17e10702-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style 17e11120-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e0d8b8-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style e4f645cb-934a-11ee-b60e-960002548b4f fill:#D3D3D3
style 17e10626-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 1025cea2-94ea-11ee-9b0f-960002548b4f fill:#D3D3D3
style 17e10c7a-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style 0990ab90-936e-11ee-8276-960002548b4f fill:#ffa500
style 17e10d4c-8e93-11ee-8f9d-96a6d245525a fill:#ffff00
style a93af6be-934a-11ee-97cd-960002548b4f fill:#D3D3D3
style b2832db2-8e98-11ee-8f9d-96a6d245525a fill:#5DAEEC
style 17e10ef0-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e0ec04-8e93-11ee-8f9d-96a6d245525a fill:#ffff00
style cb795e8e-cb07-11ee-b504-960002548b4f fill:#D3D3D3
style af0a51b8-8e9a-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e105e0-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 09e43c33-9363-11ee-814c-960002548b4f fill:#8CBF76
style 17e0cdb4-8e93-11ee-8f9d-96a6d245525a fill:#ffffff
style 17e10a90-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style c49a56a0-94f9-11ee-9be8-960002548b4f fill:#D3D3D3
style c538ddf8-cf15-11ee-b62b-960002548b4f fill:#D3D3D3
style 17e1086a-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style 17e10414-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e0fe06-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style b283319a-8e98-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e10676-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style af0a4d1c-8e9a-11ee-8f9d-96a6d245525a fill:#ffa500
style 83463627-934d-11ee-9e33-960002548b4f fill:#ffa500
style c8e6299f-934a-11ee-ba61-960002548b4f fill:#ffa500
style 5ccfc3f7-934c-11ee-8da1-960002548b4f fill:#ffa500
style b2833276-8e98-11ee-8f9d-96a6d245525a fill:#EEE8AA
style 17e102c0-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style b26c0ceb-94f9-11ee-8f0f-960002548b4f fill:#EEE8AA
style 17e0fdc0-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style 2d1ec584-94f8-11ee-8a85-960002548b4f fill:#D3D3D3
style 024f08dd-94e9-11ee-a867-960002548b4f fill:#D3D3D3
style 17e11904-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style af0a5780-8e9a-11ee-8f9d-96a6d245525a fill:#ffc0cb
style 17e10752-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
17e0fff0-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"crm:P2_has_type"|17e10036-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]
17e1059a-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P2_has_type"|17e10676-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]
17e1059a-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P72_has_language"|17e10702-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]
17e10798-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P2_has_type"|17e1086a-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]
17e10798-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P72_has_language"|17e108f6-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]
17e10a4a-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P2_has_type"|17e10b1c-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]
17e10a4a-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P72_has_language"|17e10bee-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]
17e10d4c-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P2_has_type"|17e10eaa-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]
17e10d4c-8e93-11ee-8f9d-96a6d245525a["crm:E33_Linguistic_Object"]-->|"crm:P72_has_language"|17e10f36-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]
17e10d92-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-->|"crm:P2_has_type"|17e0f820-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]
2d1ec11f-94f8-11ee-a675-960002548b4f["crm:E33_Linguistic_Object"]-->|"crm:P2_has_type"|2d1ec336-94f8-11ee-9c4b-960002548b4f["crm:E55_Type"]
2d1ec11f-94f8-11ee-a675-960002548b4f["crm:E33_Linguistic_Object"]-->|"crm:P72_has_language"|2d1ec3e7-94f8-11ee-96de-960002548b4f["crm:E56_Language"]
30725f2f-94e9-11ee-85c8-960002548b4f["crm:E42_Identifier"]-->|"crm:P2_has_type"|3072613d-94e9-11ee-99cf-960002548b4f["crm:E55_Type"]
4124c22a-94e9-11ee-baab-960002548b4f["lrm:F3_Manifestation"]-->|"crm:P2_has_type"|37fd48e9-cf15-11ee-b45f-960002548b4f["crm:E55_Type"]
5a62c11c-94f1-11ee-9220-960002548b4f["crm:E22_Human-Made_Object"]-->|"crm:P1_is_identified_by"|a5ab2f50-94fa-11ee-a37e-960002548b4f["crm:E41_Appellation"]
5a62c11c-94f1-11ee-9220-960002548b4f["crm:E22_Human-Made_Object"]-->|"crm:P2_has_type"|f5e2e871-94fa-11ee-bc5a-960002548b4f["crm:E55_Type"]
5a62c11c-94f1-11ee-9220-960002548b4f["crm:E22_Human-Made_Object"]-->|"crm:P46_is_composed_of"|43608edc-94f2-11ee-b4b5-960002548b4f["crm:E22_Human-Made_Object"]
5a62c11c-94f1-11ee-9220-960002548b4f["crm:E22_Human-Made_Object"]-->|"crm:P67i_is_referred_to_by"|2d1ec11f-94f8-11ee-a675-960002548b4f["crm:E33_Linguistic_Object"]
5aca3730-8e95-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-->|"crm:P2_has_type"|83463627-934d-11ee-9e33-960002548b4f["crm:E55_Type"]
654f9122-8e96-11ee-8f9d-96a6d245525a["lrm:F3_Manifestation"]-->|"crm:P2_has_type"|a13e386b-934d-11ee-a820-960002548b4f["crm:E55_Type"]
7f378e46-934b-11ee-8649-960002548b4f["crm:E22_Human-Made_Object"]-->|"crm:P2_has_type"|5ccfc3f7-934c-11ee-8da1-960002548b4f["crm:E55_Type"]
af0a497a-8e9a-11ee-8f9d-96a6d245525a["lrm:F28_Expression_Creation"]-->|"crm:P01i_is_domain_of"|af0a53c0-8e9a-11ee-8f9d-96a6d245525a["crm:PC14_carried_out_by"]
af0a497a-8e9a-11ee-8f9d-96a6d245525a["lrm:F28_Expression_Creation"]-->|"crm:P01i_is_domain_of"|af0a57da-8e9a-11ee-8f9d-96a6d245525a["crm:PC14_carried_out_by"]
af0a4c36-8e9a-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-->|"crm:P2_has_type"|af0a4d1c-8e9a-11ee-8f9d-96a6d245525a["crm:E55_Type"]
af0a4e70-8e9a-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-->|"crm:P2_has_type"|af0a4f42-8e9a-11ee-8f9d-96a6d245525a["crm:E55_Type"]
af0a508c-8e9a-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-->|"crm:P2_has_type"|af0a515e-8e9a-11ee-8f9d-96a6d245525a["crm:E55_Type"]
af0a5226-8e9a-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-->|"crm:P2_has_type"|af0a52ee-8e9a-11ee-8f9d-96a6d245525a["crm:E55_Type"]
af0a53c0-8e9a-11ee-8f9d-96a6d245525a["crm:PC14_carried_out_by"]-->|"crm:P02_has_range"|af0a564a-8e9a-11ee-8f9d-96a6d245525a["crm:E39_Actor"]
af0a53c0-8e9a-11ee-8f9d-96a6d245525a["crm:PC14_carried_out_by"]-->|"crm:P14.1_in_the_role_of"|af0a4df8-8e9a-11ee-8f9d-96a6d245525a["crm:E55_Type"]
af0a542e-8e9a-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-->|"crm:P2_has_type"|af0a550a-8e9a-11ee-8f9d-96a6d245525a["crm:E55_Type"]
af0a564a-8e9a-11ee-8f9d-96a6d245525a["crm:E39_Actor"]-->|"crm:P1_is_identified_by"|af0a4c36-8e9a-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]
af0a564a-8e9a-11ee-8f9d-96a6d245525a["crm:E39_Actor"]-->|"crm:P1_is_identified_by"|af0a508c-8e9a-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]
af0a564a-8e9a-11ee-8f9d-96a6d245525a["crm:E39_Actor"]-->|"crm:P1_is_identified_by"|af0a5226-8e9a-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]
af0a5780-8e9a-11ee-8f9d-96a6d245525a["crm:E39_Actor"]-->|"crm:P1_is_identified_by"|af0a4e70-8e9a-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]
af0a5780-8e9a-11ee-8f9d-96a6d245525a["crm:E39_Actor"]-->|"crm:P1_is_identified_by"|af0a542e-8e9a-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]
af0a57da-8e9a-11ee-8f9d-96a6d245525a["crm:PC14_carried_out_by"]-->|"crm:P02_has_range"|af0a5780-8e9a-11ee-8f9d-96a6d245525a["crm:E39_Actor"]
af0a57da-8e9a-11ee-8f9d-96a6d245525a["crm:PC14_carried_out_by"]-->|"crm:P14.1_in_the_role_of"|af0a5712-8e9a-11ee-8f9d-96a6d245525a["crm:E55_Type"]
b2832db2-8e98-11ee-8f9d-96a6d245525a["lrm:F30_Manifestation_Creation"]-->|"crm:P01i_is_domain_of"|b28333e8-8e98-11ee-8f9d-96a6d245525a["crm:PC14_carried_out_by"]
b2832db2-8e98-11ee-8f9d-96a6d245525a["lrm:F30_Manifestation_Creation"]-->|"crm:P4_has_time-span"|b2833398-8e98-11ee-8f9d-96a6d245525a["crm:E52_Time-Span"]
b2832db2-8e98-11ee-8f9d-96a6d245525a["lrm:F30_Manifestation_Creation"]-->|"crm:P7_took_place_at"|b283350a-8e98-11ee-8f9d-96a6d245525a["crm:E53_Place"]
b2832f1a-8e98-11ee-8f9d-96a6d245525a["crm:E39_Actor"]-->|"crm:P1_is_identified_by"|b2833032-8e98-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]
b2832f1a-8e98-11ee-8f9d-96a6d245525a["crm:E39_Actor"]-->|"crm:P1_is_identified_by"|b2833276-8e98-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]
b2833032-8e98-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-->|"crm:P2_has_type"|b28330c8-8e98-11ee-8f9d-96a6d245525a["crm:E55_Type"]
b2833276-8e98-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-->|"crm:P2_has_type"|960a47dc-94fe-11ee-9c98-960002548b4f["crm:E55_Type"]
b28333e8-8e98-11ee-8f9d-96a6d245525a["crm:PC14_carried_out_by"]-->|"crm:P02_has_range"|b2832f1a-8e98-11ee-8f9d-96a6d245525a["crm:E39_Actor"]
b28333e8-8e98-11ee-8f9d-96a6d245525a["crm:PC14_carried_out_by"]-->|"crm:P14.1_in_the_role_of"|b2833474-8e98-11ee-8f9d-96a6d245525a["crm:E55_Type"]
b283350a-8e98-11ee-8f9d-96a6d245525a["crm:E53_Place"]-->|"crm:P1_is_identified_by"|b2833154-8e98-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]
c538dbd4-cf15-11ee-aabf-960002548b4f["crm:E42_Identifier"]-->|"crm:P2_has_type"|c538df27-cf15-11ee-be5d-960002548b4f["crm:E55_Type"]
f5911ec5-94e8-11ee-ad8d-960002548b4f["crm:E55_Type"]-->|"crm:P2_has_type"|f59121a0-94e8-11ee-b33b-960002548b4f["crm:E55_Type"]
style 0990ab90-936e-11ee-8276-960002548b4f_s stroke-dasharray: 5
style 30725f2f-94e9-11ee-85c8-960002548b4f_s stroke-dasharray: 5
style b26c0ceb-94f9-11ee-8f0f-960002548b4f_s stroke-dasharray: 5
style 1025ca6d-94ea-11ee-b6c8-960002548b4f_s stroke-dasharray: 5
style f5911ec5-94e8-11ee-ad8d-960002548b4f_s stroke-dasharray: 5
style 15fe2cb0-cb09-11ee-b492-960002548b4f_s stroke-dasharray: 5
style 5a62c11c-94f1-11ee-9220-960002548b4f_s stroke-dasharray: 5
style 1353d187-94e9-11ee-a929-960002548b4f_s stroke-dasharray: 5
style 4124c22a-94e9-11ee-baab-960002548b4f_s stroke-dasharray: 5
style 024f06e7-94e9-11ee-b10b-960002548b4f_s stroke-dasharray: 5
style 1025cda9-94ea-11ee-ac93-960002548b4f_s stroke-dasharray: 5
style 1025cd00-94ea-11ee-b23b-960002548b4f_s stroke-dasharray: 5
style 1025ce29-94ea-11ee-97f2-960002548b4f_s stroke-dasharray: 5
style 1353d5ab-94e9-11ee-ba06-960002548b4f_s stroke-dasharray: 5
style 1353d4c6-94e9-11ee-b2f7-960002548b4f_s stroke-dasharray: 5
style 1353d387-94e9-11ee-aed3-960002548b4f_s stroke-dasharray: 5
style 17e10752-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e10388-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e102c0-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e10324-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e10d06-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e0f3de-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e0f398-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e0f708-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e10c7a-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e0f8f2-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e0fcee-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e1059a-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e10798-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e10d4c-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e0fff0-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e10d92-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e10a4a-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e110da-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e11094-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e11008-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e111f2-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e112ba-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e11300-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 18620f96-934b-11ee-b409-960002548b4f_s stroke-dasharray: 5
style a93af378-934a-11ee-a78f-960002548b4f_s stroke-dasharray: 5
style e4f6427b-934a-11ee-a55c-960002548b4f_s stroke-dasharray: 5
style c8e6299f-934a-11ee-ba61-960002548b4f_s stroke-dasharray: 5
style 17e11724-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e11698-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e116de-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e117f6-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e11878-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e11904-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style b2832db2-8e98-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e0cdb4-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e0da7a-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style c538dbd4-cf15-11ee-aabf-960002548b4f_s stroke-dasharray: 5
style 17e0d502-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e0c936-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e0dfca-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e0e34e-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e0e894-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e0ea4c-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 7f378e46-934b-11ee-8649-960002548b4f_s stroke-dasharray: 5
style 17e0cbc0-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e0edc6-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 654f9122-8e96-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 5aca3730-8e95-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 0990a97a-936e-11ee-a1bf-960002548b4f_s stroke-dasharray: 5
style 17e0d8b8-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style cb795e8e-cb07-11ee-b504-960002548b4f_s stroke-dasharray: 5
style 17e0d156-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 09e43c33-9363-11ee-814c-960002548b4f_s stroke-dasharray: 5
style 17e0ec04-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e0cf8a-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style af0a497a-8e9a-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e0f74e-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e0f794-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e0f938-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e0f9c4-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e0fa96-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e0fd34-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e0fdc0-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e0fe60-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e10036-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e105e0-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e10676-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e10702-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e107de-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e1086a-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e108f6-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e10a90-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e10b1c-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e10bee-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e10e28-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e10eaa-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e10f36-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 17e0f820-8e93-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 2d1ec47d-94f8-11ee-b762-960002548b4f_s stroke-dasharray: 5
style 2d1ec336-94f8-11ee-9c4b-960002548b4f_s stroke-dasharray: 5
style 2d1ec3e7-94f8-11ee-96de-960002548b4f_s stroke-dasharray: 5
style 30726293-94e9-11ee-8137-960002548b4f_s stroke-dasharray: 5
style 3072613d-94e9-11ee-99cf-960002548b4f_s stroke-dasharray: 5
style 37fd48e9-cf15-11ee-b45f-960002548b4f_s stroke-dasharray: 5
style a5ab2f50-94fa-11ee-a37e-960002548b4f_s stroke-dasharray: 5
style f5e2e871-94fa-11ee-bc5a-960002548b4f_s stroke-dasharray: 5
style 4aa5cc92-cb12-11ee-a964-960002548b4f_s stroke-dasharray: 5
style 43608edc-94f2-11ee-b4b5-960002548b4f_s stroke-dasharray: 5
style 2d1ec11f-94f8-11ee-a675-960002548b4f_s stroke-dasharray: 5
style 83463627-934d-11ee-9e33-960002548b4f_s stroke-dasharray: 5
style a13e386b-934d-11ee-a820-960002548b4f_s stroke-dasharray: 5
style 5ccfc3f7-934c-11ee-8da1-960002548b4f_s stroke-dasharray: 5
style b9ff70f4-94fa-11ee-8c90-960002548b4f_s stroke-dasharray: 5
style af0a53c0-8e9a-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style af0a57da-8e9a-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style af0a4cb8-8e9a-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style af0a4d1c-8e9a-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style af0a4ed4-8e9a-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style af0a4f42-8e9a-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style af0a50f0-8e9a-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style af0a515e-8e9a-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style af0a5294-8e9a-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style af0a52ee-8e9a-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style af0a564a-8e9a-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style af0a4df8-8e9a-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style af0a54a6-8e9a-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style af0a550a-8e9a-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style af0a4c36-8e9a-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style af0a508c-8e9a-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style af0a5226-8e9a-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style af0a4e70-8e9a-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style af0a542e-8e9a-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style af0a5780-8e9a-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style af0a5712-8e9a-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style c49a56a0-94f9-11ee-9be8-960002548b4f_s stroke-dasharray: 5
style b28333e8-8e98-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style b2833398-8e98-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style b283350a-8e98-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style b2833032-8e98-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style b2833276-8e98-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style b2833078-8e98-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style b28330c8-8e98-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style b283319a-8e98-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style b28332bc-8e98-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style 960a47dc-94fe-11ee-9c98-960002548b4f_s stroke-dasharray: 5
style b283342e-8e98-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style b28334c4-8e98-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style b2832f1a-8e98-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style b2833474-8e98-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style b2833154-8e98-11ee-8f9d-96a6d245525a_s stroke-dasharray: 5
style c538dea4-cf15-11ee-971a-960002548b4f_s stroke-dasharray: 5
style c538df27-cf15-11ee-be5d-960002548b4f_s stroke-dasharray: 5
style f59121a0-94e8-11ee-b33b-960002548b4f_s stroke-dasharray: 5
17e10036-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-17e10036-8e93-11ee-8f9d-96a6d245525a_s(["Formaat type"])
17e105e0-8e93-11ee-8f9d-96a6d245525a["rdfs:Literal"]-.-17e105e0-8e93-11ee-8f9d-96a6d245525a_s(["Illustratie"])
17e10676-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-17e10676-8e93-11ee-8f9d-96a6d245525a_s(["Illustratie type"])
17e10702-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]-.-17e10702-8e93-11ee-8f9d-96a6d245525a_s(["Illustratie taal"])
17e107de-8e93-11ee-8f9d-96a6d245525a["rdfs:Literal"]-.-17e107de-8e93-11ee-8f9d-96a6d245525a_s(["Omvang"])
17e1086a-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-17e1086a-8e93-11ee-8f9d-96a6d245525a_s(["Omvang type"])
17e108f6-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]-.-17e108f6-8e93-11ee-8f9d-96a6d245525a_s(["Omvang taal"])
17e10a90-8e93-11ee-8f9d-96a6d245525a["rdfs:Literal"]-.-17e10a90-8e93-11ee-8f9d-96a6d245525a_s(["Katernopbouw"])
17e10b1c-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-17e10b1c-8e93-11ee-8f9d-96a6d245525a_s(["Katernopbouw type"])
17e10bee-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]-.-17e10bee-8e93-11ee-8f9d-96a6d245525a_s(["Katernopbouw taal"])
17e10e28-8e93-11ee-8f9d-96a6d245525a["rdfs:Literal"]-.-17e10e28-8e93-11ee-8f9d-96a6d245525a_s(["Paginering"])
17e10eaa-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-17e10eaa-8e93-11ee-8f9d-96a6d245525a_s(["Paginering type"])
17e10f36-8e93-11ee-8f9d-96a6d245525a["crm:E56_Language"]-.-17e10f36-8e93-11ee-8f9d-96a6d245525a_s(["Paginering taal"])
17e0f820-8e93-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-17e0f820-8e93-11ee-8f9d-96a6d245525a_s(["Collatie type type"])
2d1ec47d-94f8-11ee-b762-960002548b4f["rdfs:Literal"]-.-2d1ec47d-94f8-11ee-b762-960002548b4f_s(["Volume toelichting"])
2d1ec336-94f8-11ee-9c4b-960002548b4f["crm:E55_Type"]-.-2d1ec336-94f8-11ee-9c4b-960002548b4f_s(["Volume toelichting type"])
2d1ec3e7-94f8-11ee-96de-960002548b4f["crm:E56_Language"]-.-2d1ec3e7-94f8-11ee-96de-960002548b4f_s(["Volume toelichting taal"])
30726293-94e9-11ee-8137-960002548b4f["rdfs:Literal"]-.-30726293-94e9-11ee-8137-960002548b4f_s(["Plaatskenmerk identicator (p-loi)"])
3072613d-94e9-11ee-99cf-960002548b4f["crm:E55_Type"]-.-3072613d-94e9-11ee-99cf-960002548b4f_s(["Plaatskenmerk identicator type"])
37fd48e9-cf15-11ee-b45f-960002548b4f["crm:E55_Type"]-.-37fd48e9-cf15-11ee-b45f-960002548b4f_s(["Convoluut manifestatie type"])
a5ab2f50-94fa-11ee-a37e-960002548b4f["crm:E41_Appellation"]-.-a5ab2f50-94fa-11ee-a37e-960002548b4f_s(["Volume Name"])
f5e2e871-94fa-11ee-bc5a-960002548b4f["crm:E55_Type"]-.-f5e2e871-94fa-11ee-bc5a-960002548b4f_s(["Volume type"])
4aa5cc92-cb12-11ee-a964-960002548b4f["rdfs:Literal"]-.-4aa5cc92-cb12-11ee-a964-960002548b4f_s(["Volume opmerking"])
43608edc-94f2-11ee-b4b5-960002548b4f["crm:E22_Human-Made_Object"]-.-43608edc-94f2-11ee-b4b5-960002548b4f_s(["Object"])
2d1ec11f-94f8-11ee-a675-960002548b4f["crm:E33_Linguistic_Object"]-.-2d1ec11f-94f8-11ee-a675-960002548b4f_s(["Volume Annotation"])
83463627-934d-11ee-9e33-960002548b4f["crm:E55_Type"]-.-83463627-934d-11ee-9e33-960002548b4f_s(["Is component van manifestatie type"])
a13e386b-934d-11ee-a820-960002548b4f["crm:E55_Type"]-.-a13e386b-934d-11ee-a820-960002548b4f_s(["Heeft component type"])
5ccfc3f7-934c-11ee-8da1-960002548b4f["crm:E55_Type"]-.-5ccfc3f7-934c-11ee-8da1-960002548b4f_s(["Onderwerp object type"])
b9ff70f4-94fa-11ee-8c90-960002548b4f["rdfs:Literal"]-.-b9ff70f4-94fa-11ee-8c90-960002548b4f_s(["Volume"])
af0a53c0-8e9a-11ee-8f9d-96a6d245525a["crm:PC14_carried_out_by"]-.-af0a53c0-8e9a-11ee-8f9d-96a6d245525a_s(["Expression Creation Carried Out By Personal Author"])
af0a57da-8e9a-11ee-8f9d-96a6d245525a["crm:PC14_carried_out_by"]-.-af0a57da-8e9a-11ee-8f9d-96a6d245525a_s(["Expression Creation Carried Out By Corporate Author"])
af0a4cb8-8e9a-11ee-8f9d-96a6d245525a["rdfs:Literal"]-.-af0a4cb8-8e9a-11ee-8f9d-96a6d245525a_s(["Personele auteur voornaam"])
af0a4d1c-8e9a-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-af0a4d1c-8e9a-11ee-8f9d-96a6d245525a_s(["Personele auteur voornaam type"])
af0a4ed4-8e9a-11ee-8f9d-96a6d245525a["rdfs:Literal"]-.-af0a4ed4-8e9a-11ee-8f9d-96a6d245525a_s(["Corporatieve auteur naam"])
af0a4f42-8e9a-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-af0a4f42-8e9a-11ee-8f9d-96a6d245525a_s(["Corporatieve auteur naam type"])
af0a50f0-8e9a-11ee-8f9d-96a6d245525a["rdfs:Literal"]-.-af0a50f0-8e9a-11ee-8f9d-96a6d245525a_s(["Personele auteur familienaam"])
af0a515e-8e9a-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-af0a515e-8e9a-11ee-8f9d-96a6d245525a_s(["Personele auteur familienaam type"])
af0a5294-8e9a-11ee-8f9d-96a6d245525a["rdfs:Literal"]-.-af0a5294-8e9a-11ee-8f9d-96a6d245525a_s(["Personele auteur naam extensie"])
af0a52ee-8e9a-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-af0a52ee-8e9a-11ee-8f9d-96a6d245525a_s(["Personele auteur naam extensie type"])
af0a564a-8e9a-11ee-8f9d-96a6d245525a["crm:E39_Actor"]-.-af0a564a-8e9a-11ee-8f9d-96a6d245525a_s(["Personele auteur"])
af0a4df8-8e9a-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-af0a4df8-8e9a-11ee-8f9d-96a6d245525a_s(["Personele auteur rol"])
af0a54a6-8e9a-11ee-8f9d-96a6d245525a["rdfs:Literal"]-.-af0a54a6-8e9a-11ee-8f9d-96a6d245525a_s(["Corporatieve naam extensie"])
af0a550a-8e9a-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-af0a550a-8e9a-11ee-8f9d-96a6d245525a_s(["Corporatieve naam extensie type"])
af0a4c36-8e9a-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-.-af0a4c36-8e9a-11ee-8f9d-96a6d245525a_s(["Personal Author First Name"])
af0a508c-8e9a-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-.-af0a508c-8e9a-11ee-8f9d-96a6d245525a_s(["Personal Author Last Name"])
af0a5226-8e9a-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-.-af0a5226-8e9a-11ee-8f9d-96a6d245525a_s(["Personal Author Extension"])
af0a4e70-8e9a-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-.-af0a4e70-8e9a-11ee-8f9d-96a6d245525a_s(["Corporate Author Name"])
af0a542e-8e9a-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-.-af0a542e-8e9a-11ee-8f9d-96a6d245525a_s(["Corporate Author Extension"])
af0a5780-8e9a-11ee-8f9d-96a6d245525a["crm:E39_Actor"]-.-af0a5780-8e9a-11ee-8f9d-96a6d245525a_s(["Corporatieve auteur"])
af0a5712-8e9a-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-af0a5712-8e9a-11ee-8f9d-96a6d245525a_s(["Corporatieve auteur rol"])
c49a56a0-94f9-11ee-9be8-960002548b4f["rdfs:Literal"]-.-c49a56a0-94f9-11ee-9be8-960002548b4f_s(["Plaatskenmerk naam"])
b28333e8-8e98-11ee-8f9d-96a6d245525a["crm:PC14_carried_out_by"]-.-b28333e8-8e98-11ee-8f9d-96a6d245525a_s(["Manifestation Creation Carried Out By Publisher"])
b2833398-8e98-11ee-8f9d-96a6d245525a["crm:E52_Time-Span"]-.-b2833398-8e98-11ee-8f9d-96a6d245525a_s(["Manifestation Creation Time-Span"])
b283350a-8e98-11ee-8f9d-96a6d245525a["crm:E53_Place"]-.-b283350a-8e98-11ee-8f9d-96a6d245525a_s(["Uitgave plaats"])
b2833032-8e98-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-.-b2833032-8e98-11ee-8f9d-96a6d245525a_s(["Publisher Extension"])
b2833276-8e98-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-.-b2833276-8e98-11ee-8f9d-96a6d245525a_s(["Publisher Name"])
b2833078-8e98-11ee-8f9d-96a6d245525a["rdfs:Literal"]-.-b2833078-8e98-11ee-8f9d-96a6d245525a_s(["Uitgever extensie"])
b28330c8-8e98-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-b28330c8-8e98-11ee-8f9d-96a6d245525a_s(["Uitgever extensie type"])
b283319a-8e98-11ee-8f9d-96a6d245525a["rdfs:Literal"]-.-b283319a-8e98-11ee-8f9d-96a6d245525a_s(["Uitgave plaats"])
b28332bc-8e98-11ee-8f9d-96a6d245525a["rdfs:Literal"]-.-b28332bc-8e98-11ee-8f9d-96a6d245525a_s(["Uitgever naam"])
960a47dc-94fe-11ee-9c98-960002548b4f["crm:E55_Type"]-.-960a47dc-94fe-11ee-9c98-960002548b4f_s(["Uitgever naam type"])
b283342e-8e98-11ee-8f9d-96a6d245525a["rdfs:Literal"]-.-b283342e-8e98-11ee-8f9d-96a6d245525a_s(["Uitgave periode tijdspanne begin"])
b28334c4-8e98-11ee-8f9d-96a6d245525a["rdfs:Literal"]-.-b28334c4-8e98-11ee-8f9d-96a6d245525a_s(["Uitgave periode tijdspanne einde"])
b2832f1a-8e98-11ee-8f9d-96a6d245525a["crm:E39_Actor"]-.-b2832f1a-8e98-11ee-8f9d-96a6d245525a_s(["Uitgever"])
b2833474-8e98-11ee-8f9d-96a6d245525a["crm:E55_Type"]-.-b2833474-8e98-11ee-8f9d-96a6d245525a_s(["Uitgever rol"])
b2833154-8e98-11ee-8f9d-96a6d245525a["crm:E41_Appellation"]-.-b2833154-8e98-11ee-8f9d-96a6d245525a_s(["Manifestation Creation Place Name"])
c538dea4-cf15-11ee-971a-960002548b4f["rdfs:Literal"]-.-c538dea4-cf15-11ee-971a-960002548b4f_s(["Manifestatie andere identificator"])
c538df27-cf15-11ee-be5d-960002548b4f["crm:E55_Type"]-.-c538df27-cf15-11ee-be5d-960002548b4f_s(["Manifestatie andere identificator type"])
f59121a0-94e8-11ee-b33b-960002548b4f["crm:E55_Type"]-.-f59121a0-94e8-11ee-b33b-960002548b4f_s(["Plaatskenmerk type type"])
style 17e0efec-8e93-11ee-8f9d-96a6d245525a fill:#ffff00
style f59121a0-94e8-11ee-b33b-960002548b4f fill:#ffa500
style af0a52ee-8e9a-11ee-8f9d-96a6d245525a fill:#ffa500
style af0a501e-8e9a-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e10036-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style 17e0f866-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style af0a515e-8e9a-11ee-8f9d-96a6d245525a fill:#ffa500
style 17e108b0-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e0f23a-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e0dfca-8e93-11ee-8f9d-96a6d245525a fill:#ffc0cb
style 17e0f820-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style 1353d5ab-94e9-11ee-ba06-960002548b4f fill:#D3D3D3
style af0a5578-8e9a-11ee-8f9d-96a6d245525a fill:#D3D3D3
style af0a4df8-8e9a-11ee-8f9d-96a6d245525a fill:#ffa500
style 1025ca6d-94ea-11ee-b6c8-960002548b4f fill:#ffff00
style 17e10ad6-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e1127e-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 1353d539-94e9-11ee-b7c9-960002548b4f fill:#D3D3D3
style 17e0f97e-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e0fcee-8e93-11ee-8f9d-96a6d245525a fill:#ffff00
style af0a5226-8e9a-11ee-8f9d-96a6d245525a fill:#EEE8AA
style 17e10b62-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e10388-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 654f9122-8e96-11ee-8f9d-96a6d245525a fill:#ffff00
style 186212b9-934b-11ee-afd4-960002548b4f fill:#D3D3D3
style a5ab2f50-94fa-11ee-a37e-960002548b4f fill:#EEE8AA
style b2832fe2-8e98-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e118be-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 2d1ec11f-94f8-11ee-a675-960002548b4f fill:#ffff00
style 17e0f708-8e93-11ee-8f9d-96a6d245525a fill:#EEE8AA
style c538dbd4-cf15-11ee-aabf-960002548b4f fill:#EEE8AA
style 17e0d156-8e93-11ee-8f9d-96a6d245525a fill:#808080
style 1353d4c6-94e9-11ee-b2f7-960002548b4f fill:#ffa500
style 17e11008-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style 17e10e6e-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 2d1ec336-94f8-11ee-9c4b-960002548b4f fill:#ffa500
style b28334c4-8e98-11ee-8f9d-96a6d245525a fill:#D3D3D3
style b28332bc-8e98-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e0fb22-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 834639ce-934d-11ee-a516-960002548b4f fill:#D3D3D3
style 30726213-94e9-11ee-9f22-960002548b4f fill:#D3D3D3
style 17e1104e-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e10b1c-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style b2833474-8e98-11ee-8f9d-96a6d245525a fill:#ffa500
style 17e11346-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e1007c-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style c8e62cfe-934a-11ee-bd35-960002548b4f fill:#D3D3D3
style 4aa5cc92-cb12-11ee-a964-960002548b4f fill:#D3D3D3
style 17e117b0-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e10d92-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style 1025ce29-94ea-11ee-97f2-960002548b4f fill:#ffa500
style af0a4d94-8e9a-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e116de-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style 17e10824-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 024f06e7-94e9-11ee-b10b-960002548b4f fill:#ffc0cb
style 17e11878-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style 17e112ba-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style b283350a-8e98-11ee-8f9d-96a6d245525a fill:#8CBF76
style 17e106bc-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e0cf8a-8e93-11ee-8f9d-96a6d245525a fill:#ffff00
style af0a5712-8e9a-11ee-8f9d-96a6d245525a fill:#ffa500
style b2832f88-8e98-11ee-8f9d-96a6d245525a fill:#D3D3D3
style af0a55dc-8e9a-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e10e28-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style af0a56ae-8e9a-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e1194a-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e108f6-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style 17e0ea4c-8e93-11ee-8f9d-96a6d245525a fill:#8CBF76
style 17e0e894-8e93-11ee-8f9d-96a6d245525a fill:#76A5AF
style af0a5294-8e9a-11ee-8f9d-96a6d245525a fill:#D3D3D3
style b28333e8-8e98-11ee-8f9d-96a6d245525a fill:#ffffff
style a13e3c31-934d-11ee-a98f-960002548b4f fill:#D3D3D3
style b283342e-8e98-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e0f9c4-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style 17e115c6-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style c538dea4-cf15-11ee-971a-960002548b4f fill:#D3D3D3
style 17e103ce-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 0990acbf-936e-11ee-8fa2-960002548b4f fill:#D3D3D3
style b283310e-8e98-11ee-8f9d-96a6d245525a fill:#D3D3D3
style f59120f1-94e8-11ee-a417-960002548b4f fill:#D3D3D3
style 17e117f6-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e0fd34-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style af0a497a-8e9a-11ee-8f9d-96a6d245525a fill:#5DAEEC
style 8239f35e-934c-11ee-9e1e-960002548b4f fill:#D3D3D3
style 15fe2cb0-cb09-11ee-b492-960002548b4f fill:#D3D3D3
style 3072613d-94e9-11ee-99cf-960002548b4f fill:#ffa500
style b2833154-8e98-11ee-8f9d-96a6d245525a fill:#EEE8AA
style 17e0edc6-8e93-11ee-8f9d-96a6d245525a fill:#ffff00
style 1025cd00-94ea-11ee-b23b-960002548b4f fill:#ffa500
style 1353d445-94e9-11ee-aeb6-960002548b4f fill:#D3D3D3
style 30726293-94e9-11ee-8137-960002548b4f fill:#D3D3D3
style 17e110da-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e0f74e-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style af0a50f0-8e9a-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e10eaa-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style b2833398-8e98-11ee-8f9d-96a6d245525a fill:#76A5AF
style 17e10798-8e93-11ee-8f9d-96a6d245525a fill:#ffff00
style af0a53c0-8e9a-11ee-8f9d-96a6d245525a fill:#ffffff
style 17e10d06-8e93-11ee-8f9d-96a6d245525a fill:#ffff00
style b2832f1a-8e98-11ee-8f9d-96a6d245525a fill:#ffc0cb
style af0a54a6-8e9a-11ee-8f9d-96a6d245525a fill:#D3D3D3
style a93af378-934a-11ee-a78f-960002548b4f fill:#ffa500
style 17e0f3de-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style 17e11724-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e0e34e-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style 1353d187-94e9-11ee-a929-960002548b4f fill:#ffff00
style 17e1183c-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style b2833078-8e98-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e0c936-8e93-11ee-8f9d-96a6d245525a fill:#ffff00
style f5e2ebc1-94fa-11ee-b1d8-960002548b4f fill:#D3D3D3
style af0a5366-8e9a-11ee-8f9d-96a6d245525a fill:#D3D3D3
style af0a542e-8e9a-11ee-8f9d-96a6d245525a fill:#EEE8AA
style 43608edc-94f2-11ee-b4b5-960002548b4f fill:#B0927A
style af0a4ed4-8e9a-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e11300-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style 17e11094-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style af0a4c36-8e9a-11ee-8f9d-96a6d245525a fill:#EEE8AA
style b28330c8-8e98-11ee-8f9d-96a6d245525a fill:#ffa500
style 17e100c2-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e0f10e-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e0d502-8e93-11ee-8f9d-96a6d245525a fill:#EEE8AA
style 2d1ec50a-94f8-11ee-b549-960002548b4f fill:#D3D3D3
style b283355a-8e98-11ee-8f9d-96a6d245525a fill:#D3D3D3
style af0a508c-8e9a-11ee-8f9d-96a6d245525a fill:#EEE8AA
style 17e10bee-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style af0a4e70-8e9a-11ee-8f9d-96a6d245525a fill:#EEE8AA
style 17e10dd8-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 17e11698-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style 17e111f2-8e93-11ee-8f9d-96a6d245525a fill:#ffa500
style af0a4fb0-8e9a-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 18620f96-934b-11ee-b409-960002548b4f fill:#ffa500
style 17e11530-8e93-11ee-8f9d-96a6d245525a fill:#D3D3D3
style 37fd48e9-cf15-11ee-b45f-960002548b4f fill:#ffa500
style 960a47dc-94fe-11ee-9c98-960002548b4f fill:#ffa500
style 37fd4c54-cf15-11ee-bbd2-960002548b4f fill:#D3D3D3
```
