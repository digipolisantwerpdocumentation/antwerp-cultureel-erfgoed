```mermaid
graph LR
661851da-466f-11ee-a9ac-00163e71351b["crm:E78_Curated_Holding"]-->|"rdfs:label"|f1d48ea0-466f-11ee-974d-00163e71351b(xsd:string)
style 661851da-466f-11ee-a9ac-00163e71351b fill:#B0927A
style f1d48ea0-466f-11ee-974d-00163e71351b fill:#D3D3D3
```
