```mermaid
graph LR
9503f17e-4729-11ee-974d-00163e71351b["crm:E22_Man-Made_Object"]-->|"crm:P3_has_note"|dac07a32-47d5-11ee-a9ac-00163e71351b(rdfs:Literal)
style dac07a32-47d5-11ee-a9ac-00163e71351b_s stroke-dasharray: 5
dac07a32-47d5-11ee-a9ac-00163e71351b["rdfs:Literal"]-.-dac07a32-47d5-11ee-a9ac-00163e71351b_s(["Opmerking tekst"])
style dac07a32-47d5-11ee-a9ac-00163e71351b fill:#D3D3D3
```
