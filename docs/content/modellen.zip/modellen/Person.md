```mermaid
graph LR
0d9ce85a-e37c-11ed-9064-00163e71351b["crm:E55_Type"]-->|"rdfs:label"|0d9d4688-e37c-11ed-9064-00163e71351b(xsd:string)
0d9cefd0-e37c-11ed-9064-00163e71351b["crm:E69_Death"]-->|"crm:P3_has_note"|0d9d3d32-e37c-11ed-9064-00163e71351b(rdfs:Literal)
0d9cfaca-e37c-11ed-9064-00163e71351b["crm:E21_Person"]-->|"rdfs:label"|0d9d4be2-e37c-11ed-9064-00163e71351b(xsd:string)
0d9d05d8-e37c-11ed-9064-00163e71351b["crm:E74_Group"]-->|"rdfs:label"|0d9d3ed6-e37c-11ed-9064-00163e71351b(xsd:string)
0d9d0984-e37c-11ed-9064-00163e71351b["crm:E21_Person"]-->|"rdfs:label"|0d9d1f96-e37c-11ed-9064-00163e71351b(xsd:string)
0d9d10e6-e37c-11ed-9064-00163e71351b["crm:E33_E41_Linguistic_Appellation"]-->|"crm:P190_has_symbolic_content"|0d9d5006-e37c-11ed-9064-00163e71351b(rdfs:Literal)
0d9d1a64-e37c-11ed-9064-00163e71351b["crm:E53_Place"]-->|"rdfs:label"|0d9d3ab2-e37c-11ed-9064-00163e71351b(xsd:string)
0d9d1c58-e37c-11ed-9064-00163e71351b["crm:E52_Time-Span"]-->|"crm:P82a_begin_of_the_begin"|0d9d32f6-e37c-11ed-9064-00163e71351b(rdfs:Literal)
0d9d1c58-e37c-11ed-9064-00163e71351b["crm:E52_Time-Span"]-->|"crm:P82b_end_of_the_end"|0d9d4958-e37c-11ed-9064-00163e71351b(rdfs:Literal)
0d9d2086-e37c-11ed-9064-00163e71351b["crm:E55_Type"]-->|"rdfs:label"|0d9d2176-e37c-11ed-9064-00163e71351b(xsd:string)
0d9d2414-e37c-11ed-9064-00163e71351b["crm:E33_E41_Linguistic_Appellation"]-->|"crm:P190_has_symbolic_content"|0d9d4d7c-e37c-11ed-9064-00163e71351b(rdfs:Literal)
0d9d2874-e37c-11ed-9064-00163e71351b["crm:E56_Language"]-->|"rdfs:label"|0d9d1e9c-e37c-11ed-9064-00163e71351b(xsd:string)
0d9d2a2c-e37c-11ed-9064-00163e71351b["crm:E55_Type"]-->|"rdfs:label"|0d9d4a34-e37c-11ed-9064-00163e71351b(xsd:string)
0d9d3210-e37c-11ed-9064-00163e71351b["crm:E56_Language"]-->|"rdfs:label"|0d9d2338-e37c-11ed-9064-00163e71351b(xsd:string)
0d9d390e-e37c-11ed-9064-00163e71351b["crm:E55_Type"]-->|"rdfs:label"|0d9d3774-e37c-11ed-9064-00163e71351b(xsd:string)
0d9d3b84-e37c-11ed-9064-00163e71351b["crm:E56_Language"]-->|"rdfs:label"|0d9d4f34-e37c-11ed-9064-00163e71351b(xsd:string)
0d9d3c56-e37c-11ed-9064-00163e71351b["crm:E52_Time-Span"]-->|"crm:P82a_begin_of_the_begin"|0d9d2bee-e37c-11ed-9064-00163e71351b(rdfs:Literal)
0d9d3c56-e37c-11ed-9064-00163e71351b["crm:E52_Time-Span"]-->|"crm:P82b_end_of_the_end"|0d9d3418-e37c-11ed-9064-00163e71351b(rdfs:Literal)
0d9d3e04-e37c-11ed-9064-00163e71351b["crm:E55_Type"]-->|"rdfs:label"|0d9d4318-e37c-11ed-9064-00163e71351b(xsd:string)
0d9d4084-e37c-11ed-9064-00163e71351b["crm:E52_Time-Span"]-->|"crm:P82a_begin_of_the_begin"|0d9d44d0-e37c-11ed-9064-00163e71351b(rdfs:Literal)
0d9d4084-e37c-11ed-9064-00163e71351b["crm:E52_Time-Span"]-->|"crm:P82b_end_of_the_end"|0d9d2cca-e37c-11ed-9064-00163e71351b(rdfs:Literal)
0d9d43f4-e37c-11ed-9064-00163e71351b["crm:E53_Place"]-->|"rdfs:label"|0d9d2252-e37c-11ed-9064-00163e71351b(xsd:string)
0d9d4cb4-e37c-11ed-9064-00163e71351b["crm:E21_Person"]-->|"crm:P3_has_note"|c5f20b3e-e439-11ed-a1e6-00163e71351b(rdfs:Literal)
0d9d4e58-e37c-11ed-9064-00163e71351b["crm:E55_Type"]-->|"rdfs:label"|0d9d278e-e37c-11ed-9064-00163e71351b(xsd:string)
0d9d51b4-e37c-11ed-9064-00163e71351b["crm:E33_E41_Linguistic_Appellation"]-->|"crm:P190_has_symbolic_content"|0d9d4b10-e37c-11ed-9064-00163e71351b(rdfs:Literal)
15d1ad32-57a1-11ee-b0c4-00163e71351b["crm:E52_Time-Span"]-->|"crm:P82a_begin_of_the_begin"|2a3071ae-57a2-11ee-bc5c-00163e71351b(rdfs:Literal)
15d1ad32-57a1-11ee-b0c4-00163e71351b["crm:E52_Time-Span"]-->|"crm:P82b_end_of_the_end"|4730bcc8-57a2-11ee-974d-00163e71351b(rdfs:Literal)
348369c6-ea70-11ed-a1e6-00163e71351b["crm:E52_Time-Span"]-->|"crm:P82a_begin_of_the_begin"|38c4fbdc-57a1-11ee-974d-00163e71351b(rdfs:Literal)
348369c6-ea70-11ed-a1e6-00163e71351b["crm:E52_Time-Span"]-->|"crm:P82b_end_of_the_end"|67722874-57a1-11ee-bc5c-00163e71351b(rdfs:Literal)
79858ef4-ee3b-11ed-9064-00163e71351b["crm:E33_Linguistic_Object"]-->|"crm:P190_has_symbolic_content"|79859714-ee3b-11ed-9064-00163e71351b(rdfs:Literal)
798593b8-ee3b-11ed-9064-00163e71351b["crm:E55_Type"]-->|"rdfs:label"|798599da-ee3b-11ed-9064-00163e71351b(xsd:string)
79859584-ee3b-11ed-9064-00163e71351b["crm:E56_Language"]-->|"rdfs:label"|7985987c-ee3b-11ed-9064-00163e71351b(xsd:string)
852fddca-ed98-11ed-9232-00163e71351b["crm:E33_E41_Linguistic_Appellation"]-->|"crm:P190_has_symbolic_content"|852fe766-ed98-11ed-9232-00163e71351b(rdfs:Literal)
852fe4f0-ed98-11ed-9232-00163e71351b["crm:E56_Language"]-->|"rdfs:label"|852ff17a-ed98-11ed-9232-00163e71351b(xsd:string)
852fed92-ed98-11ed-9232-00163e71351b["crm:E56_Language"]-->|"rdfs:label"|852fef90-ed98-11ed-9232-00163e71351b(xsd:string)
852ff544-ed98-11ed-9232-00163e71351b["crm:E55_Type"]-->|"rdfs:label"|852feb8a-ed98-11ed-9232-00163e71351b(xsd:string)
852ff72e-ed98-11ed-9232-00163e71351b["crm:E33_E41_Linguistic_Appellation"]-->|"crm:P190_has_symbolic_content"|852ff35a-ed98-11ed-9232-00163e71351b(rdfs:Literal)
852ff918-ed98-11ed-9232-00163e71351b["crm:E55_Type"]-->|"rdfs:label"|852fe978-ed98-11ed-9232-00163e71351b(xsd:string)
b9e8fff2-ed97-11ed-9655-00163e71351b["crm:E33_Linguistic_Object"]-->|"crm:P190_has_symbolic_content"|b9e90498-ed97-11ed-9655-00163e71351b(rdfs:Literal)
b9e907b8-ed97-11ed-9655-00163e71351b["crm:E55_Type"]-->|"rdfs:label"|b9e9063c-ed97-11ed-9655-00163e71351b(xsd:string)
b9e90a60-ed97-11ed-9655-00163e71351b["crm:E56_Language"]-->|"rdfs:label"|b9e90916-ed97-11ed-9655-00163e71351b(xsd:string)
c22ec692-e9a5-11ed-9655-00163e71351b["crm:E55_Type"]-->|"rdfs:label"|07fc5d7e-e9a6-11ed-9655-00163e71351b(xsd:string)
d863f582-b083-11ee-993d-960002548b4f["crm:E53_Place"]-->|"rdfs:label"|6be3189e-b084-11ee-92eb-960002548b4f(xsd:string)
0911bc54-e438-11ed-a1e6-00163e71351b["crm:E85_Joining"]-->|"crm:P4_has_time-span"|15d1ad32-57a1-11ee-b0c4-00163e71351b["crm:E52_Time-Span"]
0d9ce85a-e37c-11ed-9064-00163e71351b["crm:E55_Type"]-->|"crm:P2_has_type"|0d9d4e58-e37c-11ed-9064-00163e71351b["crm:E55_Type"]
0d9cefd0-e37c-11ed-9064-00163e71351b["crm:E69_Death"]-->|"crm:P4_has_time-span"|0d9d3c56-e37c-11ed-9064-00163e71351b["crm:E52_Time-Span"]
0d9cefd0-e37c-11ed-9064-00163e71351b["crm:E69_Death"]-->|"crm:P7_took_place_at"|0d9d43f4-e37c-11ed-9064-00163e71351b["crm:E53_Place"]
0d9cf714-e37c-11ed-9064-00163e71351b["crm:E67_Birth"]-->|"crm:P4_has_time-span"|0d9d1c58-e37c-11ed-9064-00163e71351b["crm:E52_Time-Span"]
0d9cf714-e37c-11ed-9064-00163e71351b["crm:E67_Birth"]-->|"crm:P7_took_place_at"|0d9d1a64-e37c-11ed-9064-00163e71351b["crm:E53_Place"]
0d9cfe80-e37c-11ed-9064-00163e71351b["crm:E7_Activity"]-->|"crm:P2_has_type"|0d9d390e-e37c-11ed-9064-00163e71351b["crm:E55_Type"]
0d9cfe80-e37c-11ed-9064-00163e71351b["crm:E7_Activity"]-->|"crm:P4_has_time-span"|0d9d4084-e37c-11ed-9064-00163e71351b["crm:E52_Time-Span"]
0d9cfe80-e37c-11ed-9064-00163e71351b["crm:E7_Activity"]-->|"crm:P7_took_place_at"|d863f582-b083-11ee-993d-960002548b4f["crm:E53_Place"]
0d9d05d8-e37c-11ed-9064-00163e71351b["crm:E74_Group"]-->|"crm:P11i_participated_in"|cba2f8ae-e9a2-11ed-9064-00163e71351b["crm:E7_Activity"]
0d9d05d8-e37c-11ed-9064-00163e71351b["crm:E74_Group"]-->|"crm:P143i_was_joined_by"|0911bc54-e438-11ed-a1e6-00163e71351b["crm:E85_Joining"]
0d9d05d8-e37c-11ed-9064-00163e71351b["crm:E74_Group"]-->|"crm:P146i_lost_member_by"|5f145dfa-e9a1-11ed-a1e6-00163e71351b["crm:E86_Leaving"]
0d9d05d8-e37c-11ed-9064-00163e71351b["crm:E74_Group"]-->|"crm:P2_has_type"|0a82e242-e9a2-11ed-9232-00163e71351b["crm:E55_Type"]
0d9d10e6-e37c-11ed-9064-00163e71351b["crm:E33_E41_Linguistic_Appellation"]-->|"crm:P2_has_type"|0d9d3e04-e37c-11ed-9064-00163e71351b["crm:E55_Type"]
0d9d10e6-e37c-11ed-9064-00163e71351b["crm:E33_E41_Linguistic_Appellation"]-->|"crm:P72_has_language"|0d9d3b84-e37c-11ed-9064-00163e71351b["crm:E56_Language"]
0d9d1578-e37c-11ed-9064-00163e71351b["crm:E53_Place"]-->|"crm:P1_is_identified_by"|0d9d51b4-e37c-11ed-9064-00163e71351b["crm:E33_E41_Linguistic_Appellation"]
0d9d2414-e37c-11ed-9064-00163e71351b["crm:E33_E41_Linguistic_Appellation"]-->|"crm:P2_has_type"|0d9d2a2c-e37c-11ed-9064-00163e71351b["crm:E55_Type"]
0d9d2414-e37c-11ed-9064-00163e71351b["crm:E33_E41_Linguistic_Appellation"]-->|"crm:P72_has_language"|0d9d2874-e37c-11ed-9064-00163e71351b["crm:E56_Language"]
0d9d4cb4-e37c-11ed-9064-00163e71351b["crm:E21_Person"]-->|"crm:P1_is_identified_by"|852fddca-ed98-11ed-9232-00163e71351b["crm:E33_E41_Linguistic_Appellation"]
0d9d4cb4-e37c-11ed-9064-00163e71351b["crm:E21_Person"]-->|"crm:P100i_died_in"|0d9cefd0-e37c-11ed-9064-00163e71351b["crm:E69_Death"]
0d9d4cb4-e37c-11ed-9064-00163e71351b["crm:E21_Person"]-->|"crm:P107i_is_current_or_former_member_of"|0d9d05d8-e37c-11ed-9064-00163e71351b["crm:E74_Group"]
0d9d4cb4-e37c-11ed-9064-00163e71351b["crm:E21_Person"]-->|"crm:P129i_is_subject_of"|b9e8fff2-ed97-11ed-9655-00163e71351b["crm:E33_Linguistic_Object"]
0d9d4cb4-e37c-11ed-9064-00163e71351b["crm:E21_Person"]-->|"crm:P14i_performed"|0d9cfe80-e37c-11ed-9064-00163e71351b["crm:E7_Activity"]
0d9d4cb4-e37c-11ed-9064-00163e71351b["crm:E21_Person"]-->|"crm:P152_has_parent"|0d9cfaca-e37c-11ed-9064-00163e71351b["crm:E21_Person"]
0d9d4cb4-e37c-11ed-9064-00163e71351b["crm:E21_Person"]-->|"crm:P152i_is_parent_of"|0d9d0984-e37c-11ed-9064-00163e71351b["crm:E21_Person"]
0d9d4cb4-e37c-11ed-9064-00163e71351b["crm:E21_Person"]-->|"crm:P2_has_type"|0d9ce85a-e37c-11ed-9064-00163e71351b["crm:E55_Type"]
0d9d4cb4-e37c-11ed-9064-00163e71351b["crm:E21_Person"]-->|"crm:P67i_is_referred_to_by"|79858ef4-ee3b-11ed-9064-00163e71351b["crm:E33_Linguistic_Object"]
0d9d4cb4-e37c-11ed-9064-00163e71351b["crm:E21_Person"]-->|"crm:P74_has_current_or_former_residence"|0d9d1578-e37c-11ed-9064-00163e71351b["crm:E53_Place"]
0d9d4cb4-e37c-11ed-9064-00163e71351b["crm:E21_Person"]-->|"crm:P76_has_contact_point"|0d9d10e6-e37c-11ed-9064-00163e71351b["crm:E33_E41_Linguistic_Appellation"]
0d9d4cb4-e37c-11ed-9064-00163e71351b["crm:E21_Person"]-->|"crm:P98i_was_born"|0d9cf714-e37c-11ed-9064-00163e71351b["crm:E67_Birth"]
0d9d4cb4-e37c-11ed-9064-00163e71351b["crm:E21_Person"]-->|"la:equivalent"|0d9ce3fa-e37c-11ed-9064-00163e71351b["crm:E1_CRM_Entity"]
0d9d51b4-e37c-11ed-9064-00163e71351b["crm:E33_E41_Linguistic_Appellation"]-->|"crm:P106_is_composed_of"|0d9d2414-e37c-11ed-9064-00163e71351b["crm:E33_E41_Linguistic_Appellation"]
0d9d51b4-e37c-11ed-9064-00163e71351b["crm:E33_E41_Linguistic_Appellation"]-->|"crm:P2_has_type"|0d9d2086-e37c-11ed-9064-00163e71351b["crm:E55_Type"]
0d9d51b4-e37c-11ed-9064-00163e71351b["crm:E33_E41_Linguistic_Appellation"]-->|"crm:P72_has_language"|0d9d3210-e37c-11ed-9064-00163e71351b["crm:E56_Language"]
5f145dfa-e9a1-11ed-a1e6-00163e71351b["crm:E86_Leaving"]-->|"crm:P4_has_time-span"|348369c6-ea70-11ed-a1e6-00163e71351b["crm:E52_Time-Span"]
79858ef4-ee3b-11ed-9064-00163e71351b["crm:E33_Linguistic_Object"]-->|"crm:P2_has_type"|798593b8-ee3b-11ed-9064-00163e71351b["crm:E55_Type"]
79858ef4-ee3b-11ed-9064-00163e71351b["crm:E33_Linguistic_Object"]-->|"crm:P72_has_language"|79859584-ee3b-11ed-9064-00163e71351b["crm:E56_Language"]
852fddca-ed98-11ed-9232-00163e71351b["crm:E33_E41_Linguistic_Appellation"]-->|"crm:P106_is_composed_of"|852ff72e-ed98-11ed-9232-00163e71351b["crm:E33_E41_Linguistic_Appellation"]
852fddca-ed98-11ed-9232-00163e71351b["crm:E33_E41_Linguistic_Appellation"]-->|"crm:P2_has_type"|852ff544-ed98-11ed-9232-00163e71351b["crm:E55_Type"]
852fddca-ed98-11ed-9232-00163e71351b["crm:E33_E41_Linguistic_Appellation"]-->|"crm:P72_has_language"|852fe4f0-ed98-11ed-9232-00163e71351b["crm:E56_Language"]
852ff72e-ed98-11ed-9232-00163e71351b["crm:E33_E41_Linguistic_Appellation"]-->|"crm:P2_has_type"|852ff918-ed98-11ed-9232-00163e71351b["crm:E55_Type"]
852ff72e-ed98-11ed-9232-00163e71351b["crm:E33_E41_Linguistic_Appellation"]-->|"crm:P72_has_language"|852fed92-ed98-11ed-9232-00163e71351b["crm:E56_Language"]
b9e8fff2-ed97-11ed-9655-00163e71351b["crm:E33_Linguistic_Object"]-->|"crm:P2_has_type"|b9e907b8-ed97-11ed-9655-00163e71351b["crm:E55_Type"]
b9e8fff2-ed97-11ed-9655-00163e71351b["crm:E33_Linguistic_Object"]-->|"crm:P72_has_language"|b9e90a60-ed97-11ed-9655-00163e71351b["crm:E56_Language"]
cba2f8ae-e9a2-11ed-9064-00163e71351b["crm:E7_Activity"]-->|"crm:P2_has_type"|c22ec692-e9a5-11ed-9655-00163e71351b["crm:E55_Type"]
cba2f8ae-e9a2-11ed-9064-00163e71351b["crm:E7_Activity"]-->|"crm:P4_has_time-span"|0fb2af62-ea70-11ed-9232-00163e71351b["crm:E52_Time-Span"]
style 15d1ad32-57a1-11ee-b0c4-00163e71351b_s stroke-dasharray: 5
style 0d9d4e58-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d3d32-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d3c56-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d43f4-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d1c58-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d1a64-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d390e-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d4084-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style d863f582-b083-11ee-993d-960002548b4f_s stroke-dasharray: 5
style cba2f8ae-e9a2-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0911bc54-e438-11ed-a1e6-00163e71351b_s stroke-dasharray: 5
style 5f145dfa-e9a1-11ed-a1e6-00163e71351b_s stroke-dasharray: 5
style 0a82e242-e9a2-11ed-9232-00163e71351b_s stroke-dasharray: 5
style 0d9d5006-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d3e04-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d3b84-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d51b4-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d32f6-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d4958-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d4d7c-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d2a2c-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d2874-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d2bee-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d3418-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d44d0-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d2cca-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 852fddca-ed98-11ed-9232-00163e71351b_s stroke-dasharray: 5
style 0d9cefd0-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d05d8-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style b9e8fff2-ed97-11ed-9655-00163e71351b_s stroke-dasharray: 5
style 0d9cfe80-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9cfaca-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d0984-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9ce85a-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style c5f20b3e-e439-11ed-a1e6-00163e71351b_s stroke-dasharray: 5
style 79858ef4-ee3b-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d1578-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d10e6-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9cf714-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9ce3fa-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d2414-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d4b10-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d2086-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 0d9d3210-e37c-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 2a3071ae-57a2-11ee-bc5c-00163e71351b_s stroke-dasharray: 5
style 4730bcc8-57a2-11ee-974d-00163e71351b_s stroke-dasharray: 5
style 38c4fbdc-57a1-11ee-974d-00163e71351b_s stroke-dasharray: 5
style 67722874-57a1-11ee-bc5c-00163e71351b_s stroke-dasharray: 5
style 348369c6-ea70-11ed-a1e6-00163e71351b_s stroke-dasharray: 5
style 79859714-ee3b-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 798593b8-ee3b-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 79859584-ee3b-11ed-9064-00163e71351b_s stroke-dasharray: 5
style 852ff72e-ed98-11ed-9232-00163e71351b_s stroke-dasharray: 5
style 852fe766-ed98-11ed-9232-00163e71351b_s stroke-dasharray: 5
style 852ff544-ed98-11ed-9232-00163e71351b_s stroke-dasharray: 5
style 852fe4f0-ed98-11ed-9232-00163e71351b_s stroke-dasharray: 5
style 852ff35a-ed98-11ed-9232-00163e71351b_s stroke-dasharray: 5
style 852ff918-ed98-11ed-9232-00163e71351b_s stroke-dasharray: 5
style 852fed92-ed98-11ed-9232-00163e71351b_s stroke-dasharray: 5
style b9e90498-ed97-11ed-9655-00163e71351b_s stroke-dasharray: 5
style b9e907b8-ed97-11ed-9655-00163e71351b_s stroke-dasharray: 5
style b9e90a60-ed97-11ed-9655-00163e71351b_s stroke-dasharray: 5
style c22ec692-e9a5-11ed-9655-00163e71351b_s stroke-dasharray: 5
style 0fb2af62-ea70-11ed-9232-00163e71351b_s stroke-dasharray: 5
15d1ad32-57a1-11ee-b0c4-00163e71351b["crm:E52_Time-Span"]-.-15d1ad32-57a1-11ee-b0c4-00163e71351b_s(["Membership Joining Time-Span"])
0d9d4e58-e37c-11ed-9064-00163e71351b["crm:E55_Type"]-.-0d9d4e58-e37c-11ed-9064-00163e71351b_s(["Persoon type type"])
0d9d3d32-e37c-11ed-9064-00163e71351b["rdfs:Literal"]-.-0d9d3d32-e37c-11ed-9064-00163e71351b_s(["Overlijden opmerking"])
0d9d3c56-e37c-11ed-9064-00163e71351b["crm:E52_Time-Span"]-.-0d9d3c56-e37c-11ed-9064-00163e71351b_s(["Death Date"])
0d9d43f4-e37c-11ed-9064-00163e71351b["crm:E53_Place"]-.-0d9d43f4-e37c-11ed-9064-00163e71351b_s(["Overlijden plaats"])
0d9d1c58-e37c-11ed-9064-00163e71351b["crm:E52_Time-Span"]-.-0d9d1c58-e37c-11ed-9064-00163e71351b_s(["Birth Date"])
0d9d1a64-e37c-11ed-9064-00163e71351b["crm:E53_Place"]-.-0d9d1a64-e37c-11ed-9064-00163e71351b_s(["Geboorte plaats"])
0d9d390e-e37c-11ed-9064-00163e71351b["crm:E55_Type"]-.-0d9d390e-e37c-11ed-9064-00163e71351b_s(["Activiteit type"])
0d9d4084-e37c-11ed-9064-00163e71351b["crm:E52_Time-Span"]-.-0d9d4084-e37c-11ed-9064-00163e71351b_s(["Activity Time-Span"])
d863f582-b083-11ee-993d-960002548b4f["crm:E53_Place"]-.-d863f582-b083-11ee-993d-960002548b4f_s(["Activiteit plaats"])
cba2f8ae-e9a2-11ed-9064-00163e71351b["crm:E7_Activity"]-.-cba2f8ae-e9a2-11ed-9064-00163e71351b_s(["Membership Activity"])
0911bc54-e438-11ed-a1e6-00163e71351b["crm:E85_Joining"]-.-0911bc54-e438-11ed-a1e6-00163e71351b_s(["Membership Joining"])
5f145dfa-e9a1-11ed-a1e6-00163e71351b["crm:E86_Leaving"]-.-5f145dfa-e9a1-11ed-a1e6-00163e71351b_s(["Membership Leaving"])
0a82e242-e9a2-11ed-9232-00163e71351b["crm:E55_Type"]-.-0a82e242-e9a2-11ed-9232-00163e71351b_s(["Membership Type"])
0d9d5006-e37c-11ed-9064-00163e71351b["rdfs:Literal"]-.-0d9d5006-e37c-11ed-9064-00163e71351b_s(["Contactpunt"])
0d9d3e04-e37c-11ed-9064-00163e71351b["crm:E55_Type"]-.-0d9d3e04-e37c-11ed-9064-00163e71351b_s(["Contactpunt type"])
0d9d3b84-e37c-11ed-9064-00163e71351b["crm:E56_Language"]-.-0d9d3b84-e37c-11ed-9064-00163e71351b_s(["Contactpunt taal"])
0d9d51b4-e37c-11ed-9064-00163e71351b["crm:E33_E41_Linguistic_Appellation"]-.-0d9d51b4-e37c-11ed-9064-00163e71351b_s(["Place Appellation"])
0d9d32f6-e37c-11ed-9064-00163e71351b["rdfs:Literal"]-.-0d9d32f6-e37c-11ed-9064-00163e71351b_s(["Geboorte tijdspanne einde"])
0d9d4958-e37c-11ed-9064-00163e71351b["rdfs:Literal"]-.-0d9d4958-e37c-11ed-9064-00163e71351b_s(["Geboorte tijdspanne begin"])
0d9d4d7c-e37c-11ed-9064-00163e71351b["rdfs:Literal"]-.-0d9d4d7c-e37c-11ed-9064-00163e71351b_s(["Woonplaats naam deel"])
0d9d2a2c-e37c-11ed-9064-00163e71351b["crm:E55_Type"]-.-0d9d2a2c-e37c-11ed-9064-00163e71351b_s(["Woonplaats naam deel type"])
0d9d2874-e37c-11ed-9064-00163e71351b["crm:E56_Language"]-.-0d9d2874-e37c-11ed-9064-00163e71351b_s(["Woonplaats naam deel taal"])
0d9d2bee-e37c-11ed-9064-00163e71351b["rdfs:Literal"]-.-0d9d2bee-e37c-11ed-9064-00163e71351b_s(["Overlijden tijdspanne begin"])
0d9d3418-e37c-11ed-9064-00163e71351b["rdfs:Literal"]-.-0d9d3418-e37c-11ed-9064-00163e71351b_s(["Overlijden tijdspanne einde"])
0d9d44d0-e37c-11ed-9064-00163e71351b["rdfs:Literal"]-.-0d9d44d0-e37c-11ed-9064-00163e71351b_s(["Activiteit tijdspanne begin"])
0d9d2cca-e37c-11ed-9064-00163e71351b["rdfs:Literal"]-.-0d9d2cca-e37c-11ed-9064-00163e71351b_s(["Activiteit tijdspanne einde"])
852fddca-ed98-11ed-9232-00163e71351b["crm:E33_E41_Linguistic_Appellation"]-.-852fddca-ed98-11ed-9232-00163e71351b_s(["Appellation"])
0d9cefd0-e37c-11ed-9064-00163e71351b["crm:E69_Death"]-.-0d9cefd0-e37c-11ed-9064-00163e71351b_s(["Death"])
0d9d05d8-e37c-11ed-9064-00163e71351b["crm:E74_Group"]-.-0d9d05d8-e37c-11ed-9064-00163e71351b_s(["Lid van groep"])
b9e8fff2-ed97-11ed-9655-00163e71351b["crm:E33_Linguistic_Object"]-.-b9e8fff2-ed97-11ed-9655-00163e71351b_s(["Description"])
0d9cfe80-e37c-11ed-9064-00163e71351b["crm:E7_Activity"]-.-0d9cfe80-e37c-11ed-9064-00163e71351b_s(["Activity"])
0d9cfaca-e37c-11ed-9064-00163e71351b["crm:E21_Person"]-.-0d9cfaca-e37c-11ed-9064-00163e71351b_s(["Kind van agent"])
0d9d0984-e37c-11ed-9064-00163e71351b["crm:E21_Person"]-.-0d9d0984-e37c-11ed-9064-00163e71351b_s(["Ouder van"])
0d9ce85a-e37c-11ed-9064-00163e71351b["crm:E55_Type"]-.-0d9ce85a-e37c-11ed-9064-00163e71351b_s(["Persoon type"])
c5f20b3e-e439-11ed-a1e6-00163e71351b["rdfs:Literal"]-.-c5f20b3e-e439-11ed-a1e6-00163e71351b_s(["Persoon opmerking"])
79858ef4-ee3b-11ed-9064-00163e71351b["crm:E33_Linguistic_Object"]-.-79858ef4-ee3b-11ed-9064-00163e71351b_s(["Annotation"])
0d9d1578-e37c-11ed-9064-00163e71351b["crm:E53_Place"]-.-0d9d1578-e37c-11ed-9064-00163e71351b_s(["Residence"])
0d9d10e6-e37c-11ed-9064-00163e71351b["crm:E33_E41_Linguistic_Appellation"]-.-0d9d10e6-e37c-11ed-9064-00163e71351b_s(["Contactpoint"])
0d9cf714-e37c-11ed-9064-00163e71351b["crm:E67_Birth"]-.-0d9cf714-e37c-11ed-9064-00163e71351b_s(["Birth"])
0d9ce3fa-e37c-11ed-9064-00163e71351b["crm:E1_CRM_Entity"]-.-0d9ce3fa-e37c-11ed-9064-00163e71351b_s(["Equivalente entiteit"])
0d9d2414-e37c-11ed-9064-00163e71351b["crm:E33_E41_Linguistic_Appellation"]-.-0d9d2414-e37c-11ed-9064-00163e71351b_s(["Place Appellation Part"])
0d9d4b10-e37c-11ed-9064-00163e71351b["rdfs:Literal"]-.-0d9d4b10-e37c-11ed-9064-00163e71351b_s(["Woonplaats naam"])
0d9d2086-e37c-11ed-9064-00163e71351b["crm:E55_Type"]-.-0d9d2086-e37c-11ed-9064-00163e71351b_s(["Woonplaats naam type"])
0d9d3210-e37c-11ed-9064-00163e71351b["crm:E56_Language"]-.-0d9d3210-e37c-11ed-9064-00163e71351b_s(["Woonplaats naam taal"])
2a3071ae-57a2-11ee-bc5c-00163e71351b["rdfs:Literal"]-.-2a3071ae-57a2-11ee-bc5c-00163e71351b_s(["Lidmaatschap start tijdspanne begin"])
4730bcc8-57a2-11ee-974d-00163e71351b["rdfs:Literal"]-.-4730bcc8-57a2-11ee-974d-00163e71351b_s(["Lidmaatschap start tijdspanne einde"])
38c4fbdc-57a1-11ee-974d-00163e71351b["rdfs:Literal"]-.-38c4fbdc-57a1-11ee-974d-00163e71351b_s(["Lidmaatschap stop tijdspanne begin"])
67722874-57a1-11ee-bc5c-00163e71351b["rdfs:Literal"]-.-67722874-57a1-11ee-bc5c-00163e71351b_s(["Lidmaatschap stop tijdspanne einde"])
348369c6-ea70-11ed-a1e6-00163e71351b["crm:E52_Time-Span"]-.-348369c6-ea70-11ed-a1e6-00163e71351b_s(["Membership Leaving Time-Span"])
79859714-ee3b-11ed-9064-00163e71351b["rdfs:Literal"]-.-79859714-ee3b-11ed-9064-00163e71351b_s(["Persoon toelichting"])
798593b8-ee3b-11ed-9064-00163e71351b["crm:E55_Type"]-.-798593b8-ee3b-11ed-9064-00163e71351b_s(["Persoon toelichting type"])
79859584-ee3b-11ed-9064-00163e71351b["crm:E56_Language"]-.-79859584-ee3b-11ed-9064-00163e71351b_s(["Persoon toelichting taal"])
852ff72e-ed98-11ed-9232-00163e71351b["crm:E33_E41_Linguistic_Appellation"]-.-852ff72e-ed98-11ed-9232-00163e71351b_s(["Appellation Part"])
852fe766-ed98-11ed-9232-00163e71351b["rdfs:Literal"]-.-852fe766-ed98-11ed-9232-00163e71351b_s(["Persoon naam"])
852ff544-ed98-11ed-9232-00163e71351b["crm:E55_Type"]-.-852ff544-ed98-11ed-9232-00163e71351b_s(["Persoon naam type"])
852fe4f0-ed98-11ed-9232-00163e71351b["crm:E56_Language"]-.-852fe4f0-ed98-11ed-9232-00163e71351b_s(["Persoon naam taal"])
852ff35a-ed98-11ed-9232-00163e71351b["rdfs:Literal"]-.-852ff35a-ed98-11ed-9232-00163e71351b_s(["Persoon naam deel"])
852ff918-ed98-11ed-9232-00163e71351b["crm:E55_Type"]-.-852ff918-ed98-11ed-9232-00163e71351b_s(["Persoon naam deel type"])
852fed92-ed98-11ed-9232-00163e71351b["crm:E56_Language"]-.-852fed92-ed98-11ed-9232-00163e71351b_s(["Persoon naam deel taal"])
b9e90498-ed97-11ed-9655-00163e71351b["rdfs:Literal"]-.-b9e90498-ed97-11ed-9655-00163e71351b_s(["Persoon beschrijving"])
b9e907b8-ed97-11ed-9655-00163e71351b["crm:E55_Type"]-.-b9e907b8-ed97-11ed-9655-00163e71351b_s(["Persoon beschrijving type"])
b9e90a60-ed97-11ed-9655-00163e71351b["crm:E56_Language"]-.-b9e90a60-ed97-11ed-9655-00163e71351b_s(["Persoon beschrijving taal"])
c22ec692-e9a5-11ed-9655-00163e71351b["crm:E55_Type"]-.-c22ec692-e9a5-11ed-9655-00163e71351b_s(["Lidmaatschap type"])
0fb2af62-ea70-11ed-9232-00163e71351b["crm:E52_Time-Span"]-.-0fb2af62-ea70-11ed-9232-00163e71351b_s(["Membership Activity Time-Span"])
style 0d9d5006-e37c-11ed-9064-00163e71351b fill:#D3D3D3
style 0d9d3774-e37c-11ed-9064-00163e71351b fill:#D3D3D3
style 0d9d2338-e37c-11ed-9064-00163e71351b fill:#D3D3D3
style b9e8fff2-ed97-11ed-9655-00163e71351b fill:#ffff00
style cba2f8ae-e9a2-11ed-9064-00163e71351b fill:#5DAEEC
style b9e90916-ed97-11ed-9655-00163e71351b fill:#D3D3D3
style b9e907b8-ed97-11ed-9655-00163e71351b fill:#ffa500
style 0d9d1c58-e37c-11ed-9064-00163e71351b fill:#76A5AF
style 852fef90-ed98-11ed-9232-00163e71351b fill:#D3D3D3
style b9e90498-ed97-11ed-9655-00163e71351b fill:#D3D3D3
style 852ff72e-ed98-11ed-9232-00163e71351b fill:#EEE8AA
style 79858ef4-ee3b-11ed-9064-00163e71351b fill:#ffff00
style 852fe766-ed98-11ed-9232-00163e71351b fill:#D3D3D3
style 0d9d3b84-e37c-11ed-9064-00163e71351b fill:#ffa500
style 2a3071ae-57a2-11ee-bc5c-00163e71351b fill:#D3D3D3
style 0d9d44d0-e37c-11ed-9064-00163e71351b fill:#D3D3D3
style 0d9d4318-e37c-11ed-9064-00163e71351b fill:#D3D3D3
style 852ff544-ed98-11ed-9232-00163e71351b fill:#ffa500
style 67722874-57a1-11ee-bc5c-00163e71351b fill:#D3D3D3
style 0d9d4cb4-e37c-11ed-9064-00163e71351b fill:#ffc0cb
style 0d9d2414-e37c-11ed-9064-00163e71351b fill:#EEE8AA
style 852ff17a-ed98-11ed-9232-00163e71351b fill:#D3D3D3
style 0d9d3210-e37c-11ed-9064-00163e71351b fill:#ffa500
style 0d9d1a64-e37c-11ed-9064-00163e71351b fill:#8CBF76
style 348369c6-ea70-11ed-a1e6-00163e71351b fill:#76A5AF
style 0d9d0984-e37c-11ed-9064-00163e71351b fill:#ffc0cb
style 0d9d3e04-e37c-11ed-9064-00163e71351b fill:#ffa500
style 0d9d4688-e37c-11ed-9064-00163e71351b fill:#D3D3D3
style 0d9d4084-e37c-11ed-9064-00163e71351b fill:#76A5AF
style 0d9cfaca-e37c-11ed-9064-00163e71351b fill:#ffc0cb
style 852fe4f0-ed98-11ed-9232-00163e71351b fill:#ffa500
style 0d9d278e-e37c-11ed-9064-00163e71351b fill:#D3D3D3
style 0d9ce3fa-e37c-11ed-9064-00163e71351b fill:#ffffff
style 0d9d05d8-e37c-11ed-9064-00163e71351b fill:#ffc0cb
style 0fb2af62-ea70-11ed-9232-00163e71351b fill:#76A5AF
style c22ec692-e9a5-11ed-9655-00163e71351b fill:#ffa500
style 4730bcc8-57a2-11ee-974d-00163e71351b fill:#D3D3D3
style 0d9d4958-e37c-11ed-9064-00163e71351b fill:#D3D3D3
style 798593b8-ee3b-11ed-9064-00163e71351b fill:#ffa500
style 0d9d4e58-e37c-11ed-9064-00163e71351b fill:#ffa500
style 0911bc54-e438-11ed-a1e6-00163e71351b fill:#5DAEEC
style 0d9d4d7c-e37c-11ed-9064-00163e71351b fill:#D3D3D3
style 0d9d4b10-e37c-11ed-9064-00163e71351b fill:#D3D3D3
style 0d9d43f4-e37c-11ed-9064-00163e71351b fill:#8CBF76
style 0d9cf714-e37c-11ed-9064-00163e71351b fill:#5DAEEC
style 6be3189e-b084-11ee-92eb-960002548b4f fill:#D3D3D3
style 38c4fbdc-57a1-11ee-974d-00163e71351b fill:#D3D3D3
style 15d1ad32-57a1-11ee-b0c4-00163e71351b fill:#76A5AF
style 0d9d1f96-e37c-11ed-9064-00163e71351b fill:#D3D3D3
style 5f145dfa-e9a1-11ed-a1e6-00163e71351b fill:#5DAEEC
style 0d9d51b4-e37c-11ed-9064-00163e71351b fill:#EEE8AA
style 852ff918-ed98-11ed-9232-00163e71351b fill:#ffa500
style 0d9d4a34-e37c-11ed-9064-00163e71351b fill:#D3D3D3
style 0d9d2086-e37c-11ed-9064-00163e71351b fill:#ffa500
style 0d9d4be2-e37c-11ed-9064-00163e71351b fill:#D3D3D3
style 0d9d2bee-e37c-11ed-9064-00163e71351b fill:#D3D3D3
style 0d9d3418-e37c-11ed-9064-00163e71351b fill:#D3D3D3
style 852fddca-ed98-11ed-9232-00163e71351b fill:#EEE8AA
style 0d9d1578-e37c-11ed-9064-00163e71351b fill:#8CBF76
style 0d9d2874-e37c-11ed-9064-00163e71351b fill:#ffa500
style 852feb8a-ed98-11ed-9232-00163e71351b fill:#D3D3D3
style 798599da-ee3b-11ed-9064-00163e71351b fill:#D3D3D3
style 0d9d2a2c-e37c-11ed-9064-00163e71351b fill:#ffa500
style 0d9d3d32-e37c-11ed-9064-00163e71351b fill:#D3D3D3
style 07fc5d7e-e9a6-11ed-9655-00163e71351b fill:#D3D3D3
style 852ff35a-ed98-11ed-9232-00163e71351b fill:#D3D3D3
style 0a82e242-e9a2-11ed-9232-00163e71351b fill:#ffa500
style c5f20b3e-e439-11ed-a1e6-00163e71351b fill:#D3D3D3
style 0d9cefd0-e37c-11ed-9064-00163e71351b fill:#5DAEEC
style b9e9063c-ed97-11ed-9655-00163e71351b fill:#D3D3D3
style 0d9ce85a-e37c-11ed-9064-00163e71351b fill:#ffa500
style 0d9d1e9c-e37c-11ed-9064-00163e71351b fill:#D3D3D3
style d863f582-b083-11ee-993d-960002548b4f fill:#8CBF76
style 79859714-ee3b-11ed-9064-00163e71351b fill:#D3D3D3
style 852fed92-ed98-11ed-9232-00163e71351b fill:#ffa500
style 0d9d2176-e37c-11ed-9064-00163e71351b fill:#D3D3D3
style 0d9d4f34-e37c-11ed-9064-00163e71351b fill:#D3D3D3
style 0d9d10e6-e37c-11ed-9064-00163e71351b fill:#EEE8AA
style 0d9d3ab2-e37c-11ed-9064-00163e71351b fill:#D3D3D3
style 79859584-ee3b-11ed-9064-00163e71351b fill:#ffa500
style 0d9d3c56-e37c-11ed-9064-00163e71351b fill:#76A5AF
style 0d9d2252-e37c-11ed-9064-00163e71351b fill:#D3D3D3
style 0d9d32f6-e37c-11ed-9064-00163e71351b fill:#D3D3D3
style 0d9cfe80-e37c-11ed-9064-00163e71351b fill:#5DAEEC
style 852fe978-ed98-11ed-9232-00163e71351b fill:#D3D3D3
style 0d9d3ed6-e37c-11ed-9064-00163e71351b fill:#D3D3D3
style 7985987c-ee3b-11ed-9064-00163e71351b fill:#D3D3D3
style b9e90a60-ed97-11ed-9655-00163e71351b fill:#ffa500
style 0d9d390e-e37c-11ed-9064-00163e71351b fill:#ffa500
style 0d9d2cca-e37c-11ed-9064-00163e71351b fill:#D3D3D3
```
