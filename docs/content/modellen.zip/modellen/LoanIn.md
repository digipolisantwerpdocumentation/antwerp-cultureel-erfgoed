```mermaid
graph LR
014551c1-da02-11ee-b5bd-960002548b4f["crm:E31_Document"]-->|"la:digitally_carried_by"|0f69e5c3-da02-11ee-954a-960002548b4f["crmdig:D1_Digital_Object"]
10aad216-cc13-11ee-abbb-960002548b4f["crm:E22_Human-Made_Object"]-->|"crm:P2_has_type"|9e1673c6-dd2c-11ee-80ab-960002548b4f["crm:E55_Type"]
10aad216-cc13-11ee-abbb-960002548b4f["crm:E22_Human-Made_Object"]-->|"crm:P34i_was_assessed_by"|c80cb98b-da01-11ee-94fe-960002548b4f["crm:E14_Condition_Assessment"]
10aad216-cc13-11ee-abbb-960002548b4f["crm:E22_Human-Made_Object"]-->|"crm:P43_has_dimension"|a2629122-d7ab-11ee-a1cd-960002548b4f["crm:E97_Monetary_Amount"]
10aad216-cc13-11ee-abbb-960002548b4f["crm:E22_Human-Made_Object"]-->|"crm:P67i_is_referred_to_by"|95874d6e-da22-11ee-91f4-960002548b4f["crm:E33_Linguistic_Object"]
1d1a6bd6-cc14-11ee-9527-960002548b4f["crm:PC69_has_association_with"]-->|"crm:P02_has_range"|723e7d20-cc17-11ee-a479-960002548b4f["crm:E42_Identifier"]
1d1a6bd6-cc14-11ee-9527-960002548b4f["crm:PC69_has_association_with"]-->|"crm:P69.1_has_type"|af0e411d-cc17-11ee-a45a-960002548b4f["crm:E55_Type"]
23bbf2df-d7c5-11ee-87c7-960002548b4f["crm:E7_Activity"]-->|"crm:P2_has_type"|67bf14f7-d7c6-11ee-a3d7-960002548b4f["crm:E55_Type"]
248c0a58-dd34-11ee-96b6-960002548b4f["crm:E55_Type"]-->|"crm:P2_has_type"|350de3c0-e75d-11ee-b98b-960002548b4f["crm:E55_Type"]
248c0a58-dd34-11ee-96b6-960002548b4f["crm:E55_Type"]-->|"crm:P2_has_type"|f89610b8-dd34-11ee-b12b-960002548b4f["crm:E55_Type"]
279b8940-e75f-11ee-80c2-960002548b4f["crm:E17_Type_Assignment"]-->|"crm:P4_has_time-span"|50a5e5ba-e75f-11ee-a628-960002548b4f["crm:E52_Time-Span"]
2e8f1a81-e6ca-11ee-889d-960002548b4f["crm:E17_Type_Assignment"]-->|"crm:P4_has_time-span"|44aa15f1-e6ca-11ee-8692-960002548b4f["crm:E52_Time-Span"]
312ac111-d7b7-11ee-8008-960002548b4f["crm:E97_Monetary_Amount"]-->|"crm:P180_has_currency"|a7565018-d7b7-11ee-bc9b-960002548b4f["crm:E98_Currency"]
312ac111-d7b7-11ee-8008-960002548b4f["crm:E97_Monetary_Amount"]-->|"crm:P2_has_type"|6eac09f6-edcd-11ee-ada0-960002548b4f["crm:E55_Type"]
350de3c0-e75d-11ee-b98b-960002548b4f["crm:E55_Type"]-->|"crm:P141i_was_assigned_by"|46f91387-e75d-11ee-9b3f-960002548b4f["crm:E17_Type_Assignment"]
356208ad-d7b8-11ee-ab26-960002548b4f["crm:E97_Monetary_Amount"]-->|"crm:P180_has_currency"|6d43b669-d7b8-11ee-a743-960002548b4f["crm:E98_Currency"]
356208ad-d7b8-11ee-ab26-960002548b4f["crm:E97_Monetary_Amount"]-->|"crm:P2_has_type"|892e123a-edcd-11ee-83ca-960002548b4f["crm:E55_Type"]
3979bed7-edd1-11ee-8ae6-960002548b4f["crm:E55_Type"]-->|"crm:P141i_was_assigned_by"|bd86a4d9-edd1-11ee-b5f2-960002548b4f["crm:E17_Type_Assignment"]
3cad9490-d7c7-11ee-a3a3-960002548b4f["crm:E7_Activity"]-->|"crm:P4_has_time-span"|e2fd7e6f-d7c7-11ee-8e64-960002548b4f["crm:E52_Time-Span"]
3cad9490-d7c7-11ee-a3a3-960002548b4f["crm:E7_Activity"]-->|"crm:P70i_is_documented_in"|65619c80-d7c7-11ee-9af0-960002548b4f["crm:E31_Document"]
417226f6-cc12-11ee-8447-960002548b4f["crm:E21_Person"]-->|"crm:P2_has_type"|39aecdfb-edce-11ee-bdf8-960002548b4f["crm:E55_Type"]
46f91387-e75d-11ee-9b3f-960002548b4f["crm:E17_Type_Assignment"]-->|"crm:P4_has_time-span"|5a67bd0e-e75d-11ee-b8aa-960002548b4f["crm:E52_Time-Span"]
55c27964-cc0f-11ee-a690-960002548b4f["crm:E39_Actor"]-->|"crm:P2_has_type"|d7fcd74d-e6cd-11ee-b069-960002548b4f["crm:E55_Type"]
55c27964-cc0f-11ee-a690-960002548b4f["crm:E39_Actor"]-->|"crm:P74_has_current_or_former_residence"|91b0b823-cc0f-11ee-9776-960002548b4f["crm:E53_Place"]
5ae77dfc-d7cc-11ee-a6a6-960002548b4f["crm:E31_Document"]-->|"crm:P2_has_type"|3bbecdd8-edb5-11ee-854f-960002548b4f["crm:E55_Type"]
5ae77dfc-d7cc-11ee-a6a6-960002548b4f["crm:E31_Document"]-->|"crm:P70_documents"|7bc2b9e9-d7d1-11ee-b535-960002548b4f["crm:E33_Linguistic_Object"]
5ae77dfc-d7cc-11ee-a6a6-960002548b4f["crm:E31_Document"]-->|"crm:P70_documents"|92baaabb-d9f8-11ee-91ea-960002548b4f["crm:E33_Linguistic_Object"]
5ae77dfc-d7cc-11ee-a6a6-960002548b4f["crm:E31_Document"]-->|"crm:P70_documents"|bde49fdf-d7ce-11ee-a596-960002548b4f["crm:E52_Time-Span"]
5ae77dfc-d7cc-11ee-a6a6-960002548b4f["crm:E31_Document"]-->|"la:digitally_carried_by"|156ba1a0-d7cd-11ee-91be-960002548b4f["crmdig:D1_Digital_Object"]
5ae77dfc-d7cc-11ee-a6a6-960002548b4f["crm:E31_Document"]-->|"la:digitally_carried_by"|ac5efedc-d7d0-11ee-b808-960002548b4f["crmdig:D1_Digital_Object"]
5e113378-edd1-11ee-acaa-960002548b4f["crm:E31_Document"]-->|"la:digitally_carried_by"|6ccd13e5-edd1-11ee-b209-960002548b4f["crmdig:D1_Digital_Object"]
5fde700b-edcf-11ee-8d31-960002548b4f["crm:E55_Type"]-->|"crm:P141i_was_assigned_by"|e736e43c-edd0-11ee-ac25-960002548b4f["crm:E17_Type_Assignment"]
60435eae-d7d3-11ee-b537-960002548b4f["crm:E31_Document"]-->|"la:digitally_carried_by"|6f7b22e1-d7d3-11ee-82d3-960002548b4f["crmdig:D1_Digital_Object"]
63567555-cc10-11ee-9937-960002548b4f["crm:E7_Activity"]-->|"crm:P17i_motivated"|23bbf2df-d7c5-11ee-87c7-960002548b4f["crm:E7_Activity"]
0f69e5c3-da02-11ee-954a-960002548b4f["crmdig:D1_Digital_Object"]-.-0f69e5c3-da02-11ee-954a-960002548b4f_s(["Object conditie document uri"])
0e151afa-edd1-11ee-9275-960002548b4f["rdfs:Literal"]-.-0e151afa-edd1-11ee-9275-960002548b4f_s(["Verlengingsverzoek type toewijzingsdatum"])
125fa348-f1b9-11ee-9b80-960002548b4f["rdfs:Literal"]-.-125fa348-f1b9-11ee-9b80-960002548b4f_s(["Inhoud autorisatiedatum"])
9e1673c6-dd2c-11ee-80ab-960002548b4f["crm:E55_Type"]-.-9e1673c6-dd2c-11ee-80ab-960002548b4f_s(["Object status"])
349d2e72-dd2f-11ee-b573-960002548b4f["rdfs:Literal"]-.-349d2e72-dd2f-11ee-b573-960002548b4f_s(["Object bijzonderheden"])
c80cb98b-da01-11ee-94fe-960002548b4f["crm:E14_Condition_Assessment"]-.-c80cb98b-da01-11ee-94fe-960002548b4f_s(["Object conditie"])
a2629122-d7ab-11ee-a1cd-960002548b4f["crm:E97_Monetary_Amount"]-.-a2629122-d7ab-11ee-a1cd-960002548b4f_s(["Object verzekering"])
95874d6e-da22-11ee-91f4-960002548b4f["crm:E33_Linguistic_Object"]-.-95874d6e-da22-11ee-91f4-960002548b4f_s(["Object creditline"])
723e7d20-cc17-11ee-a479-960002548b4f["crm:E42_Identifier"]-.-723e7d20-cc17-11ee-a479-960002548b4f_s(["Gerelateerde bruikleen nummer"])
af0e411d-cc17-11ee-a45a-960002548b4f["crm:E55_Type"]-.-af0e411d-cc17-11ee-a45a-960002548b4f_s(["Gerelateerde bruikleen type"])
67bf14f7-d7c6-11ee-a3d7-960002548b4f["crm:E55_Type"]-.-67bf14f7-d7c6-11ee-a3d7-960002548b4f_s(["Verzoek reden type"])
350de3c0-e75d-11ee-b98b-960002548b4f["crm:E55_Type"]-.-350de3c0-e75d-11ee-b98b-960002548b4f_s(["Statusgeschiedenis datum"])
f89610b8-dd34-11ee-b12b-960002548b4f["crm:E55_Type"]-.-f89610b8-dd34-11ee-b12b-960002548b4f_s(["Statusgeschiedenis type"])
50a5e5ba-e75f-11ee-a628-960002548b4f["crm:E52_Time-Span"]-.-50a5e5ba-e75f-11ee-a628-960002548b4f_s(["Object statustoewijzing tijdsspanne"])
44aa15f1-e6ca-11ee-8692-960002548b4f["crm:E52_Time-Span"]-.-44aa15f1-e6ca-11ee-8692-960002548b4f_s(["Status tijdsspanne"])
a7565018-d7b7-11ee-bc9b-960002548b4f["crm:E98_Currency"]-.-a7565018-d7b7-11ee-bc9b-960002548b4f_s(["Leenkosten valuta"])
6eac09f6-edcd-11ee-ada0-960002548b4f["crm:E55_Type"]-.-6eac09f6-edcd-11ee-ada0-960002548b4f_s(["Leenkosten type"])
9ad2b7d8-d7b7-11ee-aa5b-960002548b4f["rdfs:Literal"]-.-9ad2b7d8-d7b7-11ee-aa5b-960002548b4f_s(["Leenkosten waarde"])
46f91387-e75d-11ee-9b3f-960002548b4f["crm:E17_Type_Assignment"]-.-46f91387-e75d-11ee-9b3f-960002548b4f_s(["Statusgeschiedenis datum toewijzing"])
6d43b669-d7b8-11ee-a743-960002548b4f["crm:E98_Currency"]-.-6d43b669-d7b8-11ee-a743-960002548b4f_s(["Totale andere kosten valuta"])
892e123a-edcd-11ee-83ca-960002548b4f["crm:E55_Type"]-.-892e123a-edcd-11ee-83ca-960002548b4f_s(["Totale andere kosten type"])
53826280-d7b8-11ee-8261-960002548b4f["rdfs:Literal"]-.-53826280-d7b8-11ee-8261-960002548b4f_s(["Totale andere kosten waarde"])
bd86a4d9-edd1-11ee-b5f2-960002548b4f["crm:E17_Type_Assignment"]-.-bd86a4d9-edd1-11ee-b5f2-960002548b4f_s(["Verlengingsbeoordeling type toewijzing"])
49c05ec7-d7c9-11ee-84bc-960002548b4f["rdfs:Literal"]-.-49c05ec7-d7c9-11ee-84bc-960002548b4f_s(["Verzoek einddatum"])
e2fd7e6f-d7c7-11ee-8e64-960002548b4f["crm:E52_Time-Span"]-.-e2fd7e6f-d7c7-11ee-8e64-960002548b4f_s(["Bevestiging verzoek datum"])
65619c80-d7c7-11ee-9af0-960002548b4f["crm:E31_Document"]-.-65619c80-d7c7-11ee-9af0-960002548b4f_s(["Bevestiging verzoek document"])
39aecdfb-edce-11ee-bdf8-960002548b4f["crm:E55_Type"]-.-39aecdfb-edce-11ee-bdf8-960002548b4f_s(["Coördinator type"])
638ceb79-e6ca-11ee-b29a-960002548b4f["rdfs:Literal"]-.-638ceb79-e6ca-11ee-b29a-960002548b4f_s(["Status datum inhoud"])
5a67bd0e-e75d-11ee-b8aa-960002548b4f["crm:E52_Time-Span"]-.-5a67bd0e-e75d-11ee-b8aa-960002548b4f_s(["Statusgeschiedenis tijdsspanne"])
6bc17b5c-e75f-11ee-8fe9-960002548b4f["rdfs:Literal"]-.-6bc17b5c-e75f-11ee-8fe9-960002548b4f_s(["Object statustoewijzing datum"])
d7fcd74d-e6cd-11ee-b069-960002548b4f["crm:E55_Type"]-.-d7fcd74d-e6cd-11ee-b069-960002548b4f_s(["Bruikleengever type"])
91b0b823-cc0f-11ee-9776-960002548b4f["crm:E53_Place"]-.-91b0b823-cc0f-11ee-9776-960002548b4f_s(["Bruikleengever plaats"])
61ae3a04-e75d-11ee-af2b-960002548b4f["rdfs:Literal"]-.-61ae3a04-e75d-11ee-af2b-960002548b4f_s(["Statusgeschiedenis datum inhoud"])
3bbecdd8-edb5-11ee-854f-960002548b4f["crm:E55_Type"]-.-3bbecdd8-edb5-11ee-854f-960002548b4f_s(["Contract type"])
5da1ed2f-d7cd-11ee-a715-960002548b4f["rdfs:Literal"]-.-5da1ed2f-d7cd-11ee-a715-960002548b4f_s(["Contract bijzonderheden"])
7bc2b9e9-d7d1-11ee-b535-960002548b4f["crm:E33_Linguistic_Object"]-.-7bc2b9e9-d7d1-11ee-b535-960002548b4f_s(["Contractvoorwaarde"])
92baaabb-d9f8-11ee-91ea-960002548b4f["crm:E33_Linguistic_Object"]-.-92baaabb-d9f8-11ee-91ea-960002548b4f_s(["Immuniteit"])
bde49fdf-d7ce-11ee-a596-960002548b4f["crm:E52_Time-Span"]-.-bde49fdf-d7ce-11ee-a596-960002548b4f_s(["Contract tijdsspanne"])
156ba1a0-d7cd-11ee-91be-960002548b4f["crmdig:D1_Digital_Object"]-.-156ba1a0-d7cd-11ee-91be-960002548b4f_s(["Contract uri"])
ac5efedc-d7d0-11ee-b808-960002548b4f["crmdig:D1_Digital_Object"]-.-ac5efedc-d7d0-11ee-b808-960002548b4f_s(["Geretourneerd contract uri"])
6ccd13e5-edd1-11ee-b209-960002548b4f["crmdig:D1_Digital_Object"]-.-6ccd13e5-edd1-11ee-b209-960002548b4f_s(["Verlengingsbeoordeling document uri"])
e736e43c-edd0-11ee-ac25-960002548b4f["crm:E17_Type_Assignment"]-.-e736e43c-edd0-11ee-ac25-960002548b4f_s(["Verlengingsverzoek type toewijzing"])
6f7b22e1-d7d3-11ee-82d3-960002548b4f["crmdig:D1_Digital_Object"]-.-6f7b22e1-d7d3-11ee-82d3-960002548b4f_s(["Verlengingsverzoek document uri"])
23bbf2df-d7c5-11ee-87c7-960002548b4f["crm:E7_Activity"]-.-23bbf2df-d7c5-11ee-87c7-960002548b4f_s(["Verzoek reden"])
3cad9490-d7c7-11ee-a3a3-960002548b4f["crm:E7_Activity"]-.-3cad9490-d7c7-11ee-a3a3-960002548b4f_s(["Bevestiging verzoek"])
0de21125-edcd-11ee-b6ec-960002548b4f["crm:E55_Type"]-.-0de21125-edcd-11ee-b6ec-960002548b4f_s(["Verzoek type"])
3c375b91-d7c9-11ee-a9fb-960002548b4f["crm:E52_Time-Span"]-.-3c375b91-d7c9-11ee-a9fb-960002548b4f_s(["Verzoek datum"])
6b8b4891-d7c9-11ee-bc58-960002548b4f["crm:E31_Document"]-.-6b8b4891-d7c9-11ee-bc58-960002548b4f_s(["Verzoek document"])
8c64e97c-d7c7-11ee-856b-960002548b4f["crmdig:D1_Digital_Object"]-.-8c64e97c-d7c7-11ee-856b-960002548b4f_s(["Bevestiging verzoek document uri"])
7ad9f97f-d7c9-11ee-8f23-960002548b4f["crmdig:D1_Digital_Object"]-.-7ad9f97f-d7c9-11ee-8f23-960002548b4f_s(["Verzoek document uri"])
9ae1a30d-cc17-11ee-88a0-960002548b4f["rdfs:Literal"]-.-9ae1a30d-cc17-11ee-88a0-960002548b4f_s(["Gerelateerde bruikleen nummer inhoud"])
3fe22cb5-cc0b-11ee-a01f-960002548b4f["rdfs:Literal"]-.-3fe22cb5-cc0b-11ee-a01f-960002548b4f_s(["Duur inhoud"])
23e4eb9c-d7d2-11ee-9c8e-960002548b4f["rdfs:Literal"]-.-23e4eb9c-d7d2-11ee-9c8e-960002548b4f_s(["Contractvoorwaarde inhoud"])
de27a123-f1b8-11ee-a1b3-960002548b4f["crm:E39_Actor"]-.-de27a123-f1b8-11ee-a1b3-960002548b4f_s(["Autorisator"])
a09b43a7-f1b8-11ee-8578-960002548b4f["crm:E55_Type"]-.-a09b43a7-f1b8-11ee-8578-960002548b4f_s(["Autorisatie type"])
06fbe301-f1b9-11ee-9f1c-960002548b4f["crm:E52_Time-Span"]-.-06fbe301-f1b9-11ee-9f1c-960002548b4f_s(["Autorisatiedatum"])
9e1b8a96-edce-11ee-b71a-960002548b4f["crm:E55_Type"]-.-9e1b8a96-edce-11ee-b71a-960002548b4f_s(["Tentoonstelling type"])
3979bed7-edd1-11ee-8ae6-960002548b4f["crm:E55_Type"]-.-3979bed7-edd1-11ee-8ae6-960002548b4f_s(["Verlengingsbeoordeling type"])
8a3e1100-edd1-11ee-b825-960002548b4f["crm:E52_Time-Span"]-.-8a3e1100-edd1-11ee-b825-960002548b4f_s(["Verlengingsbeoordeling tijdsspanne"])
5e113378-edd1-11ee-acaa-960002548b4f["crm:E31_Document"]-.-5e113378-edd1-11ee-acaa-960002548b4f_s(["Verlengingsbeoordeling document"])
9ccb6608-edd1-11ee-b1ea-960002548b4f["rdfs:Literal"]-.-9ccb6608-edd1-11ee-b1ea-960002548b4f_s(["Verlengingsbeoordeling nieuwe einddatum"])
22b2cb12-cc07-11ee-96f0-960002548b4f["rdfs:Literal"]-.-22b2cb12-cc07-11ee-96f0-960002548b4f_s(["Nummer inhoud"])
46c13a89-cc07-11ee-a44e-960002548b4f["crm:E55_Type"]-.-46c13a89-cc07-11ee-a44e-960002548b4f_s(["Nummer type"])
9f2556d3-d632-11ee-ba81-960002548b4f["crm:E61_Time_Primitive"]-.-9f2556d3-d632-11ee-ba81-960002548b4f_s(["Actiedatum voltooid"])
b7c9c9e8-d9f8-11ee-984f-960002548b4f["rdfs:Literal"]-.-b7c9c9e8-d9f8-11ee-984f-960002548b4f_s(["Immuniteit inhoud"])
87140935-edcf-11ee-8020-960002548b4f["crm:E7_Activity"]-.-87140935-edcf-11ee-8020-960002548b4f_s(["Verlengingsbeoordeling"])
5fde700b-edcf-11ee-8d31-960002548b4f["crm:E55_Type"]-.-5fde700b-edcf-11ee-8d31-960002548b4f_s(["Verlengingsverzoek type"])
f1a1d793-d7d2-11ee-88c3-960002548b4f["crm:E52_Time-Span"]-.-f1a1d793-d7d2-11ee-88c3-960002548b4f_s(["Verlengingsverzoek tijdsspanne"])
60435eae-d7d3-11ee-b537-960002548b4f["crm:E31_Document"]-.-60435eae-d7d3-11ee-b537-960002548b4f_s(["Verlengingsverzoek document"])
366aef7d-da23-11ee-843a-960002548b4f["rdfs:Literal"]-.-366aef7d-da23-11ee-843a-960002548b4f_s(["Object creditline inhoud"])
c7a02c01-cfdc-11ee-8e63-960002548b4f["crm:E21_Person"]-.-c7a02c01-cfdc-11ee-8e63-960002548b4f_s(["Verantwoordelijke actie"])
cd20228b-edcd-11ee-b592-960002548b4f["crm:E55_Type"]-.-cd20228b-edcd-11ee-b592-960002548b4f_s(["Actie type"])
b3e8a849-cfdc-11ee-98a4-960002548b4f["rdfs:Literal"]-.-b3e8a849-cfdc-11ee-98a4-960002548b4f_s(["Bijzonderheden actie"])
8e8a22eb-d631-11ee-b9e8-960002548b4f["crm:E52_Time-Span"]-.-8e8a22eb-d631-11ee-b9e8-960002548b4f_s(["Actiedatum"])
279b8940-e75f-11ee-80c2-960002548b4f["crm:E17_Type_Assignment"]-.-279b8940-e75f-11ee-80c2-960002548b4f_s(["Object statustoewijzing"])
ef4723f7-dd2c-11ee-9a94-960002548b4f["crm:E55_Type"]-.-ef4723f7-dd2c-11ee-9a94-960002548b4f_s(["Object status type"])
09376bd6-d7ac-11ee-b04e-960002548b4f["crm:E98_Currency"]-.-09376bd6-d7ac-11ee-b04e-960002548b4f_s(["Object verzekering valuta"])
ed647679-d7ab-11ee-8f64-960002548b4f["rdfs:Literal"]-.-ed647679-d7ab-11ee-8f64-960002548b4f_s(["Object verzekering waarde"])
034c11c9-edd1-11ee-93d0-960002548b4f["crm:E52_Time-Span"]-->|"crm:P170i_time_is_defined_by"|0e151afa-edd1-11ee-9275-960002548b4f(rdfs:Literal)
06fbe301-f1b9-11ee-9f1c-960002548b4f["crm:E52_Time-Span"]-->|"crm:P170i_time_is_defined_by"|125fa348-f1b9-11ee-9b80-960002548b4f(rdfs:Literal)
09376bd6-d7ac-11ee-b04e-960002548b4f["crm:E98_Currency"]-->|"rdfs:label"|2ecba880-d7ac-11ee-b117-960002548b4f(xsd:string)
0de21125-edcd-11ee-b6ec-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|20dd0329-edcd-11ee-ac47-960002548b4f(xsd:string)
10aad216-cc13-11ee-abbb-960002548b4f["crm:E22_Human-Made_Object"]-->|"crm:P3_has_note"|349d2e72-dd2f-11ee-b573-960002548b4f(rdfs:Literal)
10aad216-cc13-11ee-abbb-960002548b4f["crm:E22_Human-Made_Object"]-->|"rdfs:label"|511ce710-dd2d-11ee-bc28-960002548b4f(xsd:string)
20f53b6b-cf25-11ee-ac9b-960002548b4f["crm:E9_Move"]-->|"rdfs:label"|c868f461-edce-11ee-88e3-960002548b4f(xsd:string)
248c0a58-dd34-11ee-96b6-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|d1dacec5-e759-11ee-99a4-960002548b4f(xsd:string)
312ac111-d7b7-11ee-8008-960002548b4f["crm:E97_Monetary_Amount"]-->|"crm:P90_has_value"|9ad2b7d8-d7b7-11ee-aa5b-960002548b4f(rdfs:Literal)
33f35a42-edb1-11ee-9a85-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|5aac7ff0-edb1-11ee-a0d6-960002548b4f(xsd:string)
356208ad-d7b8-11ee-ab26-960002548b4f["crm:E97_Monetary_Amount"]-->|"crm:P90_has_value"|53826280-d7b8-11ee-8261-960002548b4f(rdfs:Literal)
36079316-edcd-11ee-956c-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|470a6106-edcd-11ee-b18d-960002548b4f(xsd:string)
3979bed7-edd1-11ee-8ae6-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|4e781eac-edd1-11ee-879f-960002548b4f(xsd:string)
39aecdfb-edce-11ee-bdf8-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|467d0fe2-edce-11ee-9818-960002548b4f(xsd:string)
3bbecdd8-edb5-11ee-854f-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|50dba7c2-edb5-11ee-bbd7-960002548b4f(xsd:string)
3c375b91-d7c9-11ee-a9fb-960002548b4f["crm:E52_Time-Span"]-->|"crm:P82b_end_of_the_end"|49c05ec7-d7c9-11ee-84bc-960002548b4f(rdfs:Literal)
417226f6-cc12-11ee-8447-960002548b4f["crm:E21_Person"]-->|"rdfs:label"|a68dc7fb-d7d9-11ee-b78a-960002548b4f(xsd:string)
44aa15f1-e6ca-11ee-8692-960002548b4f["crm:E52_Time-Span"]-->|"crm:P170i_time_is_defined_by"|638ceb79-e6ca-11ee-b29a-960002548b4f(rdfs:Literal)
450943b6-cf2b-11ee-81fa-960002548b4f["crm:E39_Actor"]-->|"rdfs:label"|f847f53a-cf2b-11ee-98a8-960002548b4f(xsd:string)
46c13a89-cc07-11ee-a44e-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|6bd1515d-cc07-11ee-8e80-960002548b4f(xsd:string)
50a5e5ba-e75f-11ee-a628-960002548b4f["crm:E52_Time-Span"]-->|"crm:P170i_time_is_defined_by"|6bc17b5c-e75f-11ee-8fe9-960002548b4f(rdfs:Literal)
55c27964-cc0f-11ee-a690-960002548b4f["crm:E39_Actor"]-->|"rdfs:label"|d9040c90-cc0f-11ee-8069-960002548b4f(xsd:string)
5a67bd0e-e75d-11ee-b8aa-960002548b4f["crm:E52_Time-Span"]-->|"crm:P170i_time_is_defined_by"|61ae3a04-e75d-11ee-af2b-960002548b4f(rdfs:Literal)
5ae77dfc-d7cc-11ee-a6a6-960002548b4f["crm:E31_Document"]-->|"crm:P3_has_note"|5da1ed2f-d7cd-11ee-a715-960002548b4f(rdfs:Literal)
5fde700b-edcf-11ee-8d31-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|6eca3788-edcf-11ee-b896-960002548b4f(xsd:string)
67bf14f7-d7c6-11ee-a3d7-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|7b548bc1-d7c6-11ee-8db6-960002548b4f(xsd:string)
6ba70dc5-edb1-11ee-a9f2-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|cc928ec1-edb1-11ee-941f-960002548b4f(xsd:string)
6d43b669-d7b8-11ee-a743-960002548b4f["crm:E98_Currency"]-->|"rdfs:label"|7ca2f809-d7b8-11ee-b148-960002548b4f(xsd:string)
6eac09f6-edcd-11ee-ada0-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|7cd0bfe8-edcd-11ee-85d6-960002548b4f(xsd:string)
723e7d20-cc17-11ee-a479-960002548b4f["crm:E42_Identifier"]-->|"crm:P190_has_symbolic_content"|9ae1a30d-cc17-11ee-88a0-960002548b4f(rdfs:Literal)
766c660f-cc0a-11ee-ae45-960002548b4f["crm:E54_Dimension"]-->|"crm:P90_has_value"|3fe22cb5-cc0b-11ee-a01f-960002548b4f(rdfs:Literal)
7864a87e-cf2b-11ee-b2ce-960002548b4f["crm:E39_Actor"]-->|"rdfs:label"|02861821-cf2c-11ee-acf1-960002548b4f(xsd:string)
7bc2b9e9-d7d1-11ee-b535-960002548b4f["crm:E33_Linguistic_Object"]-->|"crm:P190_has_symbolic_content"|23e4eb9c-d7d2-11ee-9c8e-960002548b4f(rdfs:Literal)
82ff697e-cc11-11ee-a35c-960002548b4f["crm:E7_Activity"]-->|"rdfs:label"|d380a0a1-cc11-11ee-996f-960002548b4f(xsd:string)
892e123a-edcd-11ee-83ca-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|9b25cc9c-edcd-11ee-864c-960002548b4f(xsd:string)
8a3e1100-edd1-11ee-b825-960002548b4f["crm:E52_Time-Span"]-->|"crm:P170i_time_is_defined_by"|9ccb6608-edd1-11ee-b1ea-960002548b4f(rdfs:Literal)
8d4c3532-cc06-11ee-a4fb-960002548b4f["crm:E42_Identifier"]-->|"crm:P190_has_symbolic_content"|22b2cb12-cc07-11ee-96f0-960002548b4f(rdfs:Literal)
91b0b823-cc0f-11ee-9776-960002548b4f["crm:E53_Place"]-->|"rdfs:label"|e3042575-cc0f-11ee-9554-960002548b4f(xsd:string)
92baaabb-d9f8-11ee-91ea-960002548b4f["crm:E33_Linguistic_Object"]-->|"crm:P190_has_symbolic_content"|b7c9c9e8-d9f8-11ee-984f-960002548b4f(rdfs:Literal)
95874d6e-da22-11ee-91f4-960002548b4f["crm:E33_Linguistic_Object"]-->|"crm:P190_has_symbolic_content"|366aef7d-da23-11ee-843a-960002548b4f(rdfs:Literal)
95c26b84-cfdc-11ee-8ffa-960002548b4f["crm:E7_Activity"]-->|"crm:P3_has_note"|b3e8a849-cfdc-11ee-98a4-960002548b4f(rdfs:Literal)
9e1673c6-dd2c-11ee-80ab-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|0487a820-dd2d-11ee-a2c2-960002548b4f(xsd:string)
9e1b8a96-edce-11ee-b71a-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|afe177c9-edce-11ee-a1f2-960002548b4f(xsd:string)
a09b43a7-f1b8-11ee-8578-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|cdcac76f-f1b8-11ee-9cf9-960002548b4f(xsd:string)
a2629122-d7ab-11ee-a1cd-960002548b4f["crm:E97_Monetary_Amount"]-->|"crm:P90_has_value"|ed647679-d7ab-11ee-8f64-960002548b4f(rdfs:Literal)
a4c84153-cc09-11ee-9566-960002548b4f["crm:E52_Time-Span"]-->|"crm:P82a_begin_of_the_begin"|d141f43c-cc09-11ee-b1bf-960002548b4f(rdfs:Literal)
a4c84153-cc09-11ee-9566-960002548b4f["crm:E52_Time-Span"]-->|"crm:P82b_end_of_the_end"|eaa0353a-cc09-11ee-a158-960002548b4f(rdfs:Literal)
a7565018-d7b7-11ee-bc9b-960002548b4f["crm:E98_Currency"]-->|"rdfs:label"|06854fdf-d7b8-11ee-a8db-960002548b4f(xsd:string)
af0e411d-cc17-11ee-a45a-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|d42b33f7-cc17-11ee-a682-960002548b4f(xsd:string)
bde49fdf-d7ce-11ee-a596-960002548b4f["crm:E52_Time-Span"]-->|"crm:P82a_begin_of_the_begin"|ebb7c571-d7ce-11ee-ba33-960002548b4f(rdfs:Literal)
bde49fdf-d7ce-11ee-a596-960002548b4f["crm:E52_Time-Span"]-->|"crm:P82b_end_of_the_end"|fc8f20ab-d7ce-11ee-bb90-960002548b4f(rdfs:Literal)
c585cc26-cc05-11ee-876f-960002548b4f["crm:E7_Activity"]-->|"crm:P3_has_note"|40512369-d625-11ee-be37-960002548b4f(rdfs:Literal)
c7a02c01-cfdc-11ee-8e63-960002548b4f["crm:E21_Person"]-->|"rdfs:label"|f7f0b171-edcd-11ee-abba-960002548b4f(xsd:string)
c810dd40-cc0e-11ee-b600-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|e5a36bd2-d7a9-11ee-9996-960002548b4f(xsd:string)
ca450f1b-d7b7-11ee-b164-960002548b4f["crm:E97_Monetary_Amount"]-->|"crm:P90_has_value"|d7fce329-d7b7-11ee-a8c4-960002548b4f(rdfs:Literal)
cd20228b-edcd-11ee-b592-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|e33195bd-edcd-11ee-b487-960002548b4f(xsd:string)
d0cce7d8-edd1-11ee-87e9-960002548b4f["crm:E52_Time-Span"]-->|"crm:P170i_time_is_defined_by"|ddc8e25b-edd1-11ee-8789-960002548b4f(rdfs:Literal)
d7fcd74d-e6cd-11ee-b069-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|1d7cd614-e6ce-11ee-855a-960002548b4f(xsd:string)
de27a123-f1b8-11ee-a1b3-960002548b4f["crm:E39_Actor"]-->|"rdfs:label"|28e8ff25-f1b9-11ee-b585-960002548b4f(xsd:string)
e2fd7e6f-d7c7-11ee-8e64-960002548b4f["crm:E52_Time-Span"]-->|"crm:P82b_end_of_the_end"|f2564375-d7c7-11ee-ba30-960002548b4f(rdfs:Literal)
e5c31f83-dd36-11ee-a688-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|ee3fdca2-e755-11ee-9f52-960002548b4f(xsd:string)
e8dc46dd-d7b7-11ee-8ef9-960002548b4f["crm:E98_Currency"]-->|"rdfs:label"|f87ac63c-d7b7-11ee-a30a-960002548b4f(xsd:string)
ef4723f7-dd2c-11ee-9a94-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|15044fd1-dd2d-11ee-8d54-960002548b4f(xsd:string)
f1a1d793-d7d2-11ee-88c3-960002548b4f["crm:E52_Time-Span"]-->|"crm:P170i_time_is_defined_by"|0b08146c-edd0-11ee-9320-960002548b4f(rdfs:Literal)
f89610b8-dd34-11ee-b12b-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|e0e6f504-e759-11ee-860c-960002548b4f(xsd:string)
fc175863-dd36-11ee-8bcd-960002548b4f["crm:E55_Type"]-->|"rdfs:label"|f9ea68a6-e755-11ee-9d41-960002548b4f(xsd:string)
63567555-cc10-11ee-9937-960002548b4f["crm:E7_Activity"]-->|"crm:P17i_motivated"|3cad9490-d7c7-11ee-a3a3-960002548b4f["crm:E7_Activity"]
63567555-cc10-11ee-9937-960002548b4f["crm:E7_Activity"]-->|"crm:P2_has_type"|0de21125-edcd-11ee-b6ec-960002548b4f["crm:E55_Type"]
63567555-cc10-11ee-9937-960002548b4f["crm:E7_Activity"]-->|"crm:P4_has_time-span"|3c375b91-d7c9-11ee-a9fb-960002548b4f["crm:E52_Time-Span"]
63567555-cc10-11ee-9937-960002548b4f["crm:E7_Activity"]-->|"crm:P70i_is_documented_in"|6b8b4891-d7c9-11ee-bc58-960002548b4f["crm:E31_Document"]
65619c80-d7c7-11ee-9af0-960002548b4f["crm:E31_Document"]-->|"la:digitally_carried_by"|8c64e97c-d7c7-11ee-856b-960002548b4f["crmdig:D1_Digital_Object"]
6b8b4891-d7c9-11ee-bc58-960002548b4f["crm:E31_Document"]-->|"la:digitally_carried_by"|7ad9f97f-d7c9-11ee-8f23-960002548b4f["crmdig:D1_Digital_Object"]
7f915bae-f1b8-11ee-b67b-960002548b4f["crm:E7_Activity"]-->|"crm:P14_carried_out_by"|de27a123-f1b8-11ee-a1b3-960002548b4f["crm:E39_Actor"]
7f915bae-f1b8-11ee-b67b-960002548b4f["crm:E7_Activity"]-->|"crm:P2_has_type"|a09b43a7-f1b8-11ee-8578-960002548b4f["crm:E55_Type"]
7f915bae-f1b8-11ee-b67b-960002548b4f["crm:E7_Activity"]-->|"crm:P4_has_time-span"|06fbe301-f1b9-11ee-9f1c-960002548b4f["crm:E52_Time-Span"]
82ff697e-cc11-11ee-a35c-960002548b4f["crm:E7_Activity"]-->|"crm:P2_has_type"|9e1b8a96-edce-11ee-b71a-960002548b4f["crm:E55_Type"]
87140935-edcf-11ee-8020-960002548b4f["crm:E7_Activity"]-->|"crm:P2_has_type"|3979bed7-edd1-11ee-8ae6-960002548b4f["crm:E55_Type"]
87140935-edcf-11ee-8020-960002548b4f["crm:E7_Activity"]-->|"crm:P4_has_time-span"|8a3e1100-edd1-11ee-b825-960002548b4f["crm:E52_Time-Span"]
87140935-edcf-11ee-8020-960002548b4f["crm:E7_Activity"]-->|"crm:P70i_is_documented_in"|5e113378-edd1-11ee-acaa-960002548b4f["crm:E31_Document"]
8d4c3532-cc06-11ee-a4fb-960002548b4f["crm:E42_Identifier"]-->|"crm:P2_has_type"|46c13a89-cc07-11ee-a44e-960002548b4f["crm:E55_Type"]
8e8a22eb-d631-11ee-b9e8-960002548b4f["crm:E52_Time-Span"]-->|"crm:P82b_end_of_the_end"|9f2556d3-d632-11ee-ba81-960002548b4f["crm:E61_Time_Primitive"]
942df705-d7d2-11ee-96fb-960002548b4f["crm:E7_Activity"]-->|"crm:P17i_motivated"|87140935-edcf-11ee-8020-960002548b4f["crm:E7_Activity"]
942df705-d7d2-11ee-96fb-960002548b4f["crm:E7_Activity"]-->|"crm:P2_has_type"|5fde700b-edcf-11ee-8d31-960002548b4f["crm:E55_Type"]
942df705-d7d2-11ee-96fb-960002548b4f["crm:E7_Activity"]-->|"crm:P4_has_time-span"|f1a1d793-d7d2-11ee-88c3-960002548b4f["crm:E52_Time-Span"]
942df705-d7d2-11ee-96fb-960002548b4f["crm:E7_Activity"]-->|"crm:P70i_is_documented_in"|60435eae-d7d3-11ee-b537-960002548b4f["crm:E31_Document"]
95c26b84-cfdc-11ee-8ffa-960002548b4f["crm:E7_Activity"]-->|"crm:P14_carried_out_by"|c7a02c01-cfdc-11ee-8e63-960002548b4f["crm:E21_Person"]
95c26b84-cfdc-11ee-8ffa-960002548b4f["crm:E7_Activity"]-->|"crm:P2_has_type"|cd20228b-edcd-11ee-b592-960002548b4f["crm:E55_Type"]
95c26b84-cfdc-11ee-8ffa-960002548b4f["crm:E7_Activity"]-->|"crm:P4_has_time-span"|8e8a22eb-d631-11ee-b9e8-960002548b4f["crm:E52_Time-Span"]
9e1673c6-dd2c-11ee-80ab-960002548b4f["crm:E55_Type"]-->|"crm:P141i_was_assigned_by"|279b8940-e75f-11ee-80c2-960002548b4f["crm:E17_Type_Assignment"]
9e1673c6-dd2c-11ee-80ab-960002548b4f["crm:E55_Type"]-->|"crm:P2_has_type"|ef4723f7-dd2c-11ee-9a94-960002548b4f["crm:E55_Type"]
a2629122-d7ab-11ee-a1cd-960002548b4f["crm:E97_Monetary_Amount"]-->|"crm:P180_has_currency"|09376bd6-d7ac-11ee-b04e-960002548b4f["crm:E98_Currency"]
a4c84153-cc09-11ee-9566-960002548b4f["crm:E52_Time-Span"]-->|"crm:P191_had_duration"|766c660f-cc0a-11ee-ae45-960002548b4f["crm:E54_Dimension"]
bd86a4d9-edd1-11ee-b5f2-960002548b4f["crm:E17_Type_Assignment"]-->|"crm:P4_has_time-span"|d0cce7d8-edd1-11ee-87e9-960002548b4f["crm:E52_Time-Span"]
bf934d6a-d9fa-11ee-a30c-960002548b4f["crm:E31_Document"]-->|"crm:P2_has_type"|36079316-edcd-11ee-956c-960002548b4f["crm:E55_Type"]
bf934d6a-d9fa-11ee-a30c-960002548b4f["crm:E31_Document"]-->|"la:digitally_carried_by"|f7e178fc-d9fa-11ee-badf-960002548b4f["crmdig:D1_Digital_Object"]
c054c98e-cf26-11ee-bf82-960002548b4f["crm:E96_Purchase"]-->|"crm:P179_had_sales_price"|312ac111-d7b7-11ee-8008-960002548b4f["crm:E97_Monetary_Amount"]
c054c98e-cf26-11ee-bf82-960002548b4f["crm:E96_Purchase"]-->|"crm:P179_had_sales_price"|356208ad-d7b8-11ee-ab26-960002548b4f["crm:E97_Monetary_Amount"]
c054c98e-cf26-11ee-bf82-960002548b4f["crm:E96_Purchase"]-->|"crm:P179_had_sales_price"|ca450f1b-d7b7-11ee-b164-960002548b4f["crm:E97_Monetary_Amount"]
c585cc26-cc05-11ee-876f-960002548b4f["crm:E7_Activity"]-->|"crm:P01i_is_domain_of"|1d1a6bd6-cc14-11ee-9527-960002548b4f["crm:PC69_has_association_with"]
c585cc26-cc05-11ee-876f-960002548b4f["crm:E7_Activity"]-->|"crm:P1_is_identified_by"|8d4c3532-cc06-11ee-a4fb-960002548b4f["crm:E42_Identifier"]
c585cc26-cc05-11ee-876f-960002548b4f["crm:E7_Activity"]-->|"crm:P134i_was_continued_by"|942df705-d7d2-11ee-96fb-960002548b4f["crm:E7_Activity"]
c585cc26-cc05-11ee-876f-960002548b4f["crm:E7_Activity"]-->|"crm:P14_carried_out_by"|417226f6-cc12-11ee-8447-960002548b4f["crm:E21_Person"]
c585cc26-cc05-11ee-876f-960002548b4f["crm:E7_Activity"]-->|"crm:P15_was_influenced_by"|55c27964-cc0f-11ee-a690-960002548b4f["crm:E39_Actor"]
c585cc26-cc05-11ee-876f-960002548b4f["crm:E7_Activity"]-->|"crm:P15_was_influenced_by"|f417375a-edb0-11ee-9443-960002548b4f["crm:E39_Actor"]
c585cc26-cc05-11ee-876f-960002548b4f["crm:E7_Activity"]-->|"crm:P17_was_motivated_by"|63567555-cc10-11ee-9937-960002548b4f["crm:E7_Activity"]
c585cc26-cc05-11ee-876f-960002548b4f["crm:E7_Activity"]-->|"crm:P17_was_motivated_by"|7f915bae-f1b8-11ee-b67b-960002548b4f["crm:E7_Activity"]
c585cc26-cc05-11ee-876f-960002548b4f["crm:E7_Activity"]-->|"crm:P17i_motivated"|20f53b6b-cf25-11ee-ac9b-960002548b4f["crm:E9_Move"]
c585cc26-cc05-11ee-876f-960002548b4f["crm:E7_Activity"]-->|"crm:P17i_motivated"|82ff697e-cc11-11ee-a35c-960002548b4f["crm:E7_Activity"]
c585cc26-cc05-11ee-876f-960002548b4f["crm:E7_Activity"]-->|"crm:P17i_motivated"|95c26b84-cfdc-11ee-8ffa-960002548b4f["crm:E7_Activity"]
c585cc26-cc05-11ee-876f-960002548b4f["crm:E7_Activity"]-->|"crm:P17i_motivated"|c054c98e-cf26-11ee-bf82-960002548b4f["crm:E96_Purchase"]
c585cc26-cc05-11ee-876f-960002548b4f["crm:E7_Activity"]-->|"crm:P2_has_type"|248c0a58-dd34-11ee-96b6-960002548b4f["crm:E55_Type"]
c585cc26-cc05-11ee-876f-960002548b4f["crm:E7_Activity"]-->|"crm:P2_has_type"|c810dd40-cc0e-11ee-b600-960002548b4f["crm:E55_Type"]
c585cc26-cc05-11ee-876f-960002548b4f["crm:E7_Activity"]-->|"crm:P2_has_type"|e5c31f83-dd36-11ee-a688-960002548b4f["crm:E55_Type"]
c585cc26-cc05-11ee-876f-960002548b4f["crm:E7_Activity"]-->|"crm:P20i_was_purpose_of"|da1df108-cc12-11ee-aa62-960002548b4f["crm:E10_Transfer_of_Custody"]
c585cc26-cc05-11ee-876f-960002548b4f["crm:E7_Activity"]-->|"crm:P4_has_time-span"|a4c84153-cc09-11ee-9566-960002548b4f["crm:E52_Time-Span"]
c585cc26-cc05-11ee-876f-960002548b4f["crm:E7_Activity"]-->|"crm:P70i_is_documented_in"|5ae77dfc-d7cc-11ee-a6a6-960002548b4f["crm:E31_Document"]
c585cc26-cc05-11ee-876f-960002548b4f["crm:E7_Activity"]-->|"crm:P70i_is_documented_in"|bf934d6a-d9fa-11ee-a30c-960002548b4f["crm:E31_Document"]
c80cb98b-da01-11ee-94fe-960002548b4f["crm:E14_Condition_Assessment"]-->|"crm:P70i_is_documented_in"|014551c1-da02-11ee-b5bd-960002548b4f["crm:E31_Document"]
ca450f1b-d7b7-11ee-b164-960002548b4f["crm:E97_Monetary_Amount"]-->|"crm:P180_has_currency"|e8dc46dd-d7b7-11ee-8ef9-960002548b4f["crm:E98_Currency"]
ca450f1b-d7b7-11ee-b164-960002548b4f["crm:E97_Monetary_Amount"]-->|"crm:P2_has_type"|aa29c24e-edcd-11ee-99e6-960002548b4f["crm:E55_Type"]
da1df108-cc12-11ee-aa62-960002548b4f["crm:E10_Transfer_of_Custody"]-->|"crm:P28_custody_surrendered_by"|450943b6-cf2b-11ee-81fa-960002548b4f["crm:E39_Actor"]
da1df108-cc12-11ee-aa62-960002548b4f["crm:E10_Transfer_of_Custody"]-->|"crm:P29_custody_received_by"|7864a87e-cf2b-11ee-b2ce-960002548b4f["crm:E39_Actor"]
da1df108-cc12-11ee-aa62-960002548b4f["crm:E10_Transfer_of_Custody"]-->|"crm:P30_transferred_custody_of"|10aad216-cc13-11ee-abbb-960002548b4f["crm:E22_Human-Made_Object"]
e5c31f83-dd36-11ee-a688-960002548b4f["crm:E55_Type"]-->|"crm:P141i_was_assigned_by"|2e8f1a81-e6ca-11ee-889d-960002548b4f["crm:E17_Type_Assignment"]
e5c31f83-dd36-11ee-a688-960002548b4f["crm:E55_Type"]-->|"crm:P2_has_type"|fc175863-dd36-11ee-8bcd-960002548b4f["crm:E55_Type"]
e736e43c-edd0-11ee-ac25-960002548b4f["crm:E17_Type_Assignment"]-->|"crm:P4_has_time-span"|034c11c9-edd1-11ee-93d0-960002548b4f["crm:E52_Time-Span"]
f417375a-edb0-11ee-9443-960002548b4f["crm:E39_Actor"]-->|"crm:P2_has_type"|33f35a42-edb1-11ee-9a85-960002548b4f["crm:E55_Type"]
f417375a-edb0-11ee-9443-960002548b4f["crm:E39_Actor"]-->|"crm:P2_has_type"|6ba70dc5-edb1-11ee-a9f2-960002548b4f["crm:E55_Type"]
style 0f69e5c3-da02-11ee-954a-960002548b4f_s stroke-dasharray: 5
style 0e151afa-edd1-11ee-9275-960002548b4f_s stroke-dasharray: 5
style 125fa348-f1b9-11ee-9b80-960002548b4f_s stroke-dasharray: 5
style 9e1673c6-dd2c-11ee-80ab-960002548b4f_s stroke-dasharray: 5
style 349d2e72-dd2f-11ee-b573-960002548b4f_s stroke-dasharray: 5
style c80cb98b-da01-11ee-94fe-960002548b4f_s stroke-dasharray: 5
style a2629122-d7ab-11ee-a1cd-960002548b4f_s stroke-dasharray: 5
style 95874d6e-da22-11ee-91f4-960002548b4f_s stroke-dasharray: 5
style 723e7d20-cc17-11ee-a479-960002548b4f_s stroke-dasharray: 5
style af0e411d-cc17-11ee-a45a-960002548b4f_s stroke-dasharray: 5
style 67bf14f7-d7c6-11ee-a3d7-960002548b4f_s stroke-dasharray: 5
style 350de3c0-e75d-11ee-b98b-960002548b4f_s stroke-dasharray: 5
style f89610b8-dd34-11ee-b12b-960002548b4f_s stroke-dasharray: 5
style 50a5e5ba-e75f-11ee-a628-960002548b4f_s stroke-dasharray: 5
style 44aa15f1-e6ca-11ee-8692-960002548b4f_s stroke-dasharray: 5
style a7565018-d7b7-11ee-bc9b-960002548b4f_s stroke-dasharray: 5
style 6eac09f6-edcd-11ee-ada0-960002548b4f_s stroke-dasharray: 5
style 9ad2b7d8-d7b7-11ee-aa5b-960002548b4f_s stroke-dasharray: 5
style 46f91387-e75d-11ee-9b3f-960002548b4f_s stroke-dasharray: 5
style 6d43b669-d7b8-11ee-a743-960002548b4f_s stroke-dasharray: 5
style 892e123a-edcd-11ee-83ca-960002548b4f_s stroke-dasharray: 5
style 53826280-d7b8-11ee-8261-960002548b4f_s stroke-dasharray: 5
style bd86a4d9-edd1-11ee-b5f2-960002548b4f_s stroke-dasharray: 5
style 49c05ec7-d7c9-11ee-84bc-960002548b4f_s stroke-dasharray: 5
style e2fd7e6f-d7c7-11ee-8e64-960002548b4f_s stroke-dasharray: 5
style 65619c80-d7c7-11ee-9af0-960002548b4f_s stroke-dasharray: 5
style 39aecdfb-edce-11ee-bdf8-960002548b4f_s stroke-dasharray: 5
style 638ceb79-e6ca-11ee-b29a-960002548b4f_s stroke-dasharray: 5
style 5a67bd0e-e75d-11ee-b8aa-960002548b4f_s stroke-dasharray: 5
style 6bc17b5c-e75f-11ee-8fe9-960002548b4f_s stroke-dasharray: 5
style d7fcd74d-e6cd-11ee-b069-960002548b4f_s stroke-dasharray: 5
style 91b0b823-cc0f-11ee-9776-960002548b4f_s stroke-dasharray: 5
style 61ae3a04-e75d-11ee-af2b-960002548b4f_s stroke-dasharray: 5
style 3bbecdd8-edb5-11ee-854f-960002548b4f_s stroke-dasharray: 5
style 5da1ed2f-d7cd-11ee-a715-960002548b4f_s stroke-dasharray: 5
style 7bc2b9e9-d7d1-11ee-b535-960002548b4f_s stroke-dasharray: 5
style 92baaabb-d9f8-11ee-91ea-960002548b4f_s stroke-dasharray: 5
style bde49fdf-d7ce-11ee-a596-960002548b4f_s stroke-dasharray: 5
style 156ba1a0-d7cd-11ee-91be-960002548b4f_s stroke-dasharray: 5
style ac5efedc-d7d0-11ee-b808-960002548b4f_s stroke-dasharray: 5
style 6ccd13e5-edd1-11ee-b209-960002548b4f_s stroke-dasharray: 5
style e736e43c-edd0-11ee-ac25-960002548b4f_s stroke-dasharray: 5
style 6f7b22e1-d7d3-11ee-82d3-960002548b4f_s stroke-dasharray: 5
style 23bbf2df-d7c5-11ee-87c7-960002548b4f_s stroke-dasharray: 5
style 3cad9490-d7c7-11ee-a3a3-960002548b4f_s stroke-dasharray: 5
style 0de21125-edcd-11ee-b6ec-960002548b4f_s stroke-dasharray: 5
style 3c375b91-d7c9-11ee-a9fb-960002548b4f_s stroke-dasharray: 5
style 6b8b4891-d7c9-11ee-bc58-960002548b4f_s stroke-dasharray: 5
style 8c64e97c-d7c7-11ee-856b-960002548b4f_s stroke-dasharray: 5
style 7ad9f97f-d7c9-11ee-8f23-960002548b4f_s stroke-dasharray: 5
style 9ae1a30d-cc17-11ee-88a0-960002548b4f_s stroke-dasharray: 5
style 3fe22cb5-cc0b-11ee-a01f-960002548b4f_s stroke-dasharray: 5
style 23e4eb9c-d7d2-11ee-9c8e-960002548b4f_s stroke-dasharray: 5
style de27a123-f1b8-11ee-a1b3-960002548b4f_s stroke-dasharray: 5
style a09b43a7-f1b8-11ee-8578-960002548b4f_s stroke-dasharray: 5
style 06fbe301-f1b9-11ee-9f1c-960002548b4f_s stroke-dasharray: 5
style 9e1b8a96-edce-11ee-b71a-960002548b4f_s stroke-dasharray: 5
style 3979bed7-edd1-11ee-8ae6-960002548b4f_s stroke-dasharray: 5
style 8a3e1100-edd1-11ee-b825-960002548b4f_s stroke-dasharray: 5
style 5e113378-edd1-11ee-acaa-960002548b4f_s stroke-dasharray: 5
style 9ccb6608-edd1-11ee-b1ea-960002548b4f_s stroke-dasharray: 5
style 22b2cb12-cc07-11ee-96f0-960002548b4f_s stroke-dasharray: 5
style 46c13a89-cc07-11ee-a44e-960002548b4f_s stroke-dasharray: 5
style 9f2556d3-d632-11ee-ba81-960002548b4f_s stroke-dasharray: 5
style b7c9c9e8-d9f8-11ee-984f-960002548b4f_s stroke-dasharray: 5
style 87140935-edcf-11ee-8020-960002548b4f_s stroke-dasharray: 5
style 5fde700b-edcf-11ee-8d31-960002548b4f_s stroke-dasharray: 5
style f1a1d793-d7d2-11ee-88c3-960002548b4f_s stroke-dasharray: 5
style 60435eae-d7d3-11ee-b537-960002548b4f_s stroke-dasharray: 5
style 366aef7d-da23-11ee-843a-960002548b4f_s stroke-dasharray: 5
style c7a02c01-cfdc-11ee-8e63-960002548b4f_s stroke-dasharray: 5
style cd20228b-edcd-11ee-b592-960002548b4f_s stroke-dasharray: 5
style b3e8a849-cfdc-11ee-98a4-960002548b4f_s stroke-dasharray: 5
style 8e8a22eb-d631-11ee-b9e8-960002548b4f_s stroke-dasharray: 5
style 279b8940-e75f-11ee-80c2-960002548b4f_s stroke-dasharray: 5
style ef4723f7-dd2c-11ee-9a94-960002548b4f_s stroke-dasharray: 5
style 09376bd6-d7ac-11ee-b04e-960002548b4f_s stroke-dasharray: 5
style ed647679-d7ab-11ee-8f64-960002548b4f_s stroke-dasharray: 5
style 766c660f-cc0a-11ee-ae45-960002548b4f_s stroke-dasharray: 5
style d141f43c-cc09-11ee-b1bf-960002548b4f_s stroke-dasharray: 5
style eaa0353a-cc09-11ee-a158-960002548b4f_s stroke-dasharray: 5
style d0cce7d8-edd1-11ee-87e9-960002548b4f_s stroke-dasharray: 5
style ebb7c571-d7ce-11ee-ba33-960002548b4f_s stroke-dasharray: 5
style fc8f20ab-d7ce-11ee-bb90-960002548b4f_s stroke-dasharray: 5
style 36079316-edcd-11ee-956c-960002548b4f_s stroke-dasharray: 5
style f7e178fc-d9fa-11ee-badf-960002548b4f_s stroke-dasharray: 5
style 312ac111-d7b7-11ee-8008-960002548b4f_s stroke-dasharray: 5
style 356208ad-d7b8-11ee-ab26-960002548b4f_s stroke-dasharray: 5
style ca450f1b-d7b7-11ee-b164-960002548b4f_s stroke-dasharray: 5
style 1d1a6bd6-cc14-11ee-9527-960002548b4f_s stroke-dasharray: 5
style 8d4c3532-cc06-11ee-a4fb-960002548b4f_s stroke-dasharray: 5
style 942df705-d7d2-11ee-96fb-960002548b4f_s stroke-dasharray: 5
style 417226f6-cc12-11ee-8447-960002548b4f_s stroke-dasharray: 5
style 55c27964-cc0f-11ee-a690-960002548b4f_s stroke-dasharray: 5
style f417375a-edb0-11ee-9443-960002548b4f_s stroke-dasharray: 5
style 63567555-cc10-11ee-9937-960002548b4f_s stroke-dasharray: 5
style 7f915bae-f1b8-11ee-b67b-960002548b4f_s stroke-dasharray: 5
style 20f53b6b-cf25-11ee-ac9b-960002548b4f_s stroke-dasharray: 5
style 82ff697e-cc11-11ee-a35c-960002548b4f_s stroke-dasharray: 5
style 95c26b84-cfdc-11ee-8ffa-960002548b4f_s stroke-dasharray: 5
style c054c98e-cf26-11ee-bf82-960002548b4f_s stroke-dasharray: 5
style 248c0a58-dd34-11ee-96b6-960002548b4f_s stroke-dasharray: 5
style c810dd40-cc0e-11ee-b600-960002548b4f_s stroke-dasharray: 5
style e5c31f83-dd36-11ee-a688-960002548b4f_s stroke-dasharray: 5
style da1df108-cc12-11ee-aa62-960002548b4f_s stroke-dasharray: 5
style 40512369-d625-11ee-be37-960002548b4f_s stroke-dasharray: 5
style a4c84153-cc09-11ee-9566-960002548b4f_s stroke-dasharray: 5
style 5ae77dfc-d7cc-11ee-a6a6-960002548b4f_s stroke-dasharray: 5
style bf934d6a-d9fa-11ee-a30c-960002548b4f_s stroke-dasharray: 5
style 014551c1-da02-11ee-b5bd-960002548b4f_s stroke-dasharray: 5
style e8dc46dd-d7b7-11ee-8ef9-960002548b4f_s stroke-dasharray: 5
style aa29c24e-edcd-11ee-99e6-960002548b4f_s stroke-dasharray: 5
style d7fce329-d7b7-11ee-a8c4-960002548b4f_s stroke-dasharray: 5
style ddc8e25b-edd1-11ee-8789-960002548b4f_s stroke-dasharray: 5
style 450943b6-cf2b-11ee-81fa-960002548b4f_s stroke-dasharray: 5
style 7864a87e-cf2b-11ee-b2ce-960002548b4f_s stroke-dasharray: 5
style 10aad216-cc13-11ee-abbb-960002548b4f_s stroke-dasharray: 5
style f2564375-d7c7-11ee-ba30-960002548b4f_s stroke-dasharray: 5
style 2e8f1a81-e6ca-11ee-889d-960002548b4f_s stroke-dasharray: 5
style fc175863-dd36-11ee-8bcd-960002548b4f_s stroke-dasharray: 5
style 034c11c9-edd1-11ee-93d0-960002548b4f_s stroke-dasharray: 5
style 0b08146c-edd0-11ee-9320-960002548b4f_s stroke-dasharray: 5
style 33f35a42-edb1-11ee-9a85-960002548b4f_s stroke-dasharray: 5
style 6ba70dc5-edb1-11ee-a9f2-960002548b4f_s stroke-dasharray: 5
766c660f-cc0a-11ee-ae45-960002548b4f["crm:E54_Dimension"]-.-766c660f-cc0a-11ee-ae45-960002548b4f_s(["Duur"])
d141f43c-cc09-11ee-b1bf-960002548b4f["rdfs:Literal"]-.-d141f43c-cc09-11ee-b1bf-960002548b4f_s(["Begin"])
eaa0353a-cc09-11ee-a158-960002548b4f["rdfs:Literal"]-.-eaa0353a-cc09-11ee-a158-960002548b4f_s(["Einde"])
d0cce7d8-edd1-11ee-87e9-960002548b4f["crm:E52_Time-Span"]-.-d0cce7d8-edd1-11ee-87e9-960002548b4f_s(["Verlengingsbeoordeling type toewijzingstijdsspanne"])
ebb7c571-d7ce-11ee-ba33-960002548b4f["rdfs:Literal"]-.-ebb7c571-d7ce-11ee-ba33-960002548b4f_s(["Begin contract tijdsspanne"])
fc8f20ab-d7ce-11ee-bb90-960002548b4f["rdfs:Literal"]-.-fc8f20ab-d7ce-11ee-bb90-960002548b4f_s(["Einde contract tijdsspanne"])
36079316-edcd-11ee-956c-960002548b4f["crm:E55_Type"]-.-36079316-edcd-11ee-956c-960002548b4f_s(["Collegebesluit type"])
f7e178fc-d9fa-11ee-badf-960002548b4f["crmdig:D1_Digital_Object"]-.-f7e178fc-d9fa-11ee-badf-960002548b4f_s(["Collegebesluit uri"])
312ac111-d7b7-11ee-8008-960002548b4f["crm:E97_Monetary_Amount"]-.-312ac111-d7b7-11ee-8008-960002548b4f_s(["Leenkosten"])
356208ad-d7b8-11ee-ab26-960002548b4f["crm:E97_Monetary_Amount"]-.-356208ad-d7b8-11ee-ab26-960002548b4f_s(["Totale andere kosten"])
ca450f1b-d7b7-11ee-b164-960002548b4f["crm:E97_Monetary_Amount"]-.-ca450f1b-d7b7-11ee-b164-960002548b4f_s(["Behandelingskosten"])
1d1a6bd6-cc14-11ee-9527-960002548b4f["crm:PC69_has_association_with"]-.-1d1a6bd6-cc14-11ee-9527-960002548b4f_s(["Gerelateerde bruikleen"])
8d4c3532-cc06-11ee-a4fb-960002548b4f["crm:E42_Identifier"]-.-8d4c3532-cc06-11ee-a4fb-960002548b4f_s(["Nummer"])
942df705-d7d2-11ee-96fb-960002548b4f["crm:E7_Activity"]-.-942df705-d7d2-11ee-96fb-960002548b4f_s(["Verlengingsverzoek"])
417226f6-cc12-11ee-8447-960002548b4f["crm:E21_Person"]-.-417226f6-cc12-11ee-8447-960002548b4f_s(["Coördinator"])
55c27964-cc0f-11ee-a690-960002548b4f["crm:E39_Actor"]-.-55c27964-cc0f-11ee-a690-960002548b4f_s(["Bruikleengever"])
f417375a-edb0-11ee-9443-960002548b4f["crm:E39_Actor"]-.-f417375a-edb0-11ee-9443-960002548b4f_s(["Bruikleengever contactpersoon"])
63567555-cc10-11ee-9937-960002548b4f["crm:E7_Activity"]-.-63567555-cc10-11ee-9937-960002548b4f_s(["Verzoek"])
7f915bae-f1b8-11ee-b67b-960002548b4f["crm:E7_Activity"]-.-7f915bae-f1b8-11ee-b67b-960002548b4f_s(["Autorisatie"])
20f53b6b-cf25-11ee-ac9b-960002548b4f["crm:E9_Move"]-.-20f53b6b-cf25-11ee-ac9b-960002548b4f_s(["Verplaatsing"])
82ff697e-cc11-11ee-a35c-960002548b4f["crm:E7_Activity"]-.-82ff697e-cc11-11ee-a35c-960002548b4f_s(["Tentoonstelling"])
95c26b84-cfdc-11ee-8ffa-960002548b4f["crm:E7_Activity"]-.-95c26b84-cfdc-11ee-8ffa-960002548b4f_s(["Actie"])
c054c98e-cf26-11ee-bf82-960002548b4f["crm:E96_Purchase"]-.-c054c98e-cf26-11ee-bf82-960002548b4f_s(["Kosten"])
248c0a58-dd34-11ee-96b6-960002548b4f["crm:E55_Type"]-.-248c0a58-dd34-11ee-96b6-960002548b4f_s(["Statusgeschiedenis"])
c810dd40-cc0e-11ee-b600-960002548b4f["crm:E55_Type"]-.-c810dd40-cc0e-11ee-b600-960002548b4f_s(["Bruikleen type"])
e5c31f83-dd36-11ee-a688-960002548b4f["crm:E55_Type"]-.-e5c31f83-dd36-11ee-a688-960002548b4f_s(["Status"])
da1df108-cc12-11ee-aa62-960002548b4f["crm:E10_Transfer_of_Custody"]-.-da1df108-cc12-11ee-aa62-960002548b4f_s(["Inkomend object"])
40512369-d625-11ee-be37-960002548b4f["rdfs:Literal"]-.-40512369-d625-11ee-be37-960002548b4f_s(["Totaal aantal gevraagde objecten"])
a4c84153-cc09-11ee-9566-960002548b4f["crm:E52_Time-Span"]-.-a4c84153-cc09-11ee-9566-960002548b4f_s(["Periode"])
5ae77dfc-d7cc-11ee-a6a6-960002548b4f["crm:E31_Document"]-.-5ae77dfc-d7cc-11ee-a6a6-960002548b4f_s(["Contract"])
bf934d6a-d9fa-11ee-a30c-960002548b4f["crm:E31_Document"]-.-bf934d6a-d9fa-11ee-a30c-960002548b4f_s(["Collegebesluit"])
014551c1-da02-11ee-b5bd-960002548b4f["crm:E31_Document"]-.-014551c1-da02-11ee-b5bd-960002548b4f_s(["Object conditie document"])
e8dc46dd-d7b7-11ee-8ef9-960002548b4f["crm:E98_Currency"]-.-e8dc46dd-d7b7-11ee-8ef9-960002548b4f_s(["Behandelingskosten valuta"])
aa29c24e-edcd-11ee-99e6-960002548b4f["crm:E55_Type"]-.-aa29c24e-edcd-11ee-99e6-960002548b4f_s(["Behandelingskosten type"])
d7fce329-d7b7-11ee-a8c4-960002548b4f["rdfs:Literal"]-.-d7fce329-d7b7-11ee-a8c4-960002548b4f_s(["Behandelingskosten waarde"])
ddc8e25b-edd1-11ee-8789-960002548b4f["rdfs:Literal"]-.-ddc8e25b-edd1-11ee-8789-960002548b4f_s(["Verlengingsbeoordeling type toewijzingsdatum"])
450943b6-cf2b-11ee-81fa-960002548b4f["crm:E39_Actor"]-.-450943b6-cf2b-11ee-81fa-960002548b4f_s(["Inkomend object bron"])
7864a87e-cf2b-11ee-b2ce-960002548b4f["crm:E39_Actor"]-.-7864a87e-cf2b-11ee-b2ce-960002548b4f_s(["Object bestemming"])
10aad216-cc13-11ee-abbb-960002548b4f["crm:E22_Human-Made_Object"]-.-10aad216-cc13-11ee-abbb-960002548b4f_s(["Object"])
f2564375-d7c7-11ee-ba30-960002548b4f["rdfs:Literal"]-.-f2564375-d7c7-11ee-ba30-960002548b4f_s(["Bevestiging verzoek einddatum"])
2e8f1a81-e6ca-11ee-889d-960002548b4f["crm:E17_Type_Assignment"]-.-2e8f1a81-e6ca-11ee-889d-960002548b4f_s(["Status datum"])
fc175863-dd36-11ee-8bcd-960002548b4f["crm:E55_Type"]-.-fc175863-dd36-11ee-8bcd-960002548b4f_s(["Status type"])
034c11c9-edd1-11ee-93d0-960002548b4f["crm:E52_Time-Span"]-.-034c11c9-edd1-11ee-93d0-960002548b4f_s(["Verlengingsverzoek type toewijzingstijdsspanne"])
0b08146c-edd0-11ee-9320-960002548b4f["rdfs:Literal"]-.-0b08146c-edd0-11ee-9320-960002548b4f_s(["Verlengingsverzoek nieuwe einddatum"])
33f35a42-edb1-11ee-9a85-960002548b4f["crm:E55_Type"]-.-33f35a42-edb1-11ee-9a85-960002548b4f_s(["Bruikleengever contactpersoon type"])
6ba70dc5-edb1-11ee-a9f2-960002548b4f["crm:E55_Type"]-.-6ba70dc5-edb1-11ee-a9f2-960002548b4f_s(["Bruikleengever contactpersoon roltype"])
style 61ae3a04-e75d-11ee-af2b-960002548b4f fill:#D3D3D3
style 87140935-edcf-11ee-8020-960002548b4f fill:#5DAEEC
style f847f53a-cf2b-11ee-98a8-960002548b4f fill:#D3D3D3
style d7fcd74d-e6cd-11ee-b069-960002548b4f fill:#ffa500
style c80cb98b-da01-11ee-94fe-960002548b4f fill:#5DAEEC
style 6eca3788-edcf-11ee-b896-960002548b4f fill:#D3D3D3
style 450943b6-cf2b-11ee-81fa-960002548b4f fill:#ffc0cb
style 8a3e1100-edd1-11ee-b825-960002548b4f fill:#76A5AF
style ebb7c571-d7ce-11ee-ba33-960002548b4f fill:#D3D3D3
style 8d4c3532-cc06-11ee-a4fb-960002548b4f fill:#EEE8AA
style 6bd1515d-cc07-11ee-8e80-960002548b4f fill:#D3D3D3
style d380a0a1-cc11-11ee-996f-960002548b4f fill:#D3D3D3
style 39aecdfb-edce-11ee-bdf8-960002548b4f fill:#ffa500
style 312ac111-d7b7-11ee-8008-960002548b4f fill:#808080
style 06854fdf-d7b8-11ee-a8db-960002548b4f fill:#D3D3D3
style 9b25cc9c-edcd-11ee-864c-960002548b4f fill:#D3D3D3
style 23bbf2df-d7c5-11ee-87c7-960002548b4f fill:#5DAEEC
style 7ad9f97f-d7c9-11ee-8f23-960002548b4f fill:#C5B4E3
style d1dacec5-e759-11ee-99a4-960002548b4f fill:#D3D3D3
style 6ba70dc5-edb1-11ee-a9f2-960002548b4f fill:#ffa500
style 67bf14f7-d7c6-11ee-a3d7-960002548b4f fill:#ffa500
style ca450f1b-d7b7-11ee-b164-960002548b4f fill:#808080
style 6bc17b5c-e75f-11ee-8fe9-960002548b4f fill:#D3D3D3
style 4e781eac-edd1-11ee-879f-960002548b4f fill:#D3D3D3
style 279b8940-e75f-11ee-80c2-960002548b4f fill:#5DAEEC
style af0e411d-cc17-11ee-a45a-960002548b4f fill:#ffa500
style 20dd0329-edcd-11ee-ac47-960002548b4f fill:#D3D3D3
style 6ccd13e5-edd1-11ee-b209-960002548b4f fill:#C5B4E3
style 638ceb79-e6ca-11ee-b29a-960002548b4f fill:#D3D3D3
style d141f43c-cc09-11ee-b1bf-960002548b4f fill:#D3D3D3
style 9f2556d3-d632-11ee-ba81-960002548b4f fill:#D3D3D3
style eaa0353a-cc09-11ee-a158-960002548b4f fill:#D3D3D3
style 0487a820-dd2d-11ee-a2c2-960002548b4f fill:#D3D3D3
style d7fce329-d7b7-11ee-a8c4-960002548b4f fill:#D3D3D3
style afe177c9-edce-11ee-a1f2-960002548b4f fill:#D3D3D3
style 95c26b84-cfdc-11ee-8ffa-960002548b4f fill:#5DAEEC
style 7cd0bfe8-edcd-11ee-85d6-960002548b4f fill:#D3D3D3
style 467d0fe2-edce-11ee-9818-960002548b4f fill:#D3D3D3
style 6d43b669-d7b8-11ee-a743-960002548b4f fill:#ffa500
style aa29c24e-edcd-11ee-99e6-960002548b4f fill:#ffa500
style 723e7d20-cc17-11ee-a479-960002548b4f fill:#EEE8AA
style 22b2cb12-cc07-11ee-96f0-960002548b4f fill:#D3D3D3
style 09376bd6-d7ac-11ee-b04e-960002548b4f fill:#ffa500
style a4c84153-cc09-11ee-9566-960002548b4f fill:#76A5AF
style d42b33f7-cc17-11ee-a682-960002548b4f fill:#D3D3D3
style b3e8a849-cfdc-11ee-98a4-960002548b4f fill:#D3D3D3
style 46c13a89-cc07-11ee-a44e-960002548b4f fill:#ffa500
style a7565018-d7b7-11ee-bc9b-960002548b4f fill:#ffa500
style 40512369-d625-11ee-be37-960002548b4f fill:#D3D3D3
style f7e178fc-d9fa-11ee-badf-960002548b4f fill:#C5B4E3
style 10aad216-cc13-11ee-abbb-960002548b4f fill:#B0927A
style e33195bd-edcd-11ee-b487-960002548b4f fill:#D3D3D3
style 5aac7ff0-edb1-11ee-a0d6-960002548b4f fill:#D3D3D3
style 36079316-edcd-11ee-956c-960002548b4f fill:#ffa500
style 02861821-cf2c-11ee-acf1-960002548b4f fill:#D3D3D3
style f9ea68a6-e755-11ee-9d41-960002548b4f fill:#D3D3D3
style 7ca2f809-d7b8-11ee-b148-960002548b4f fill:#D3D3D3
style 9e1b8a96-edce-11ee-b71a-960002548b4f fill:#ffa500
style 1d7cd614-e6ce-11ee-855a-960002548b4f fill:#D3D3D3
style e736e43c-edd0-11ee-ac25-960002548b4f fill:#5DAEEC
style 0f69e5c3-da02-11ee-954a-960002548b4f fill:#C5B4E3
style f417375a-edb0-11ee-9443-960002548b4f fill:#ffc0cb
style 766c660f-cc0a-11ee-ae45-960002548b4f fill:#808080
style 3c375b91-d7c9-11ee-a9fb-960002548b4f fill:#76A5AF
style 1d1a6bd6-cc14-11ee-9527-960002548b4f fill:#ffffff
style a2629122-d7ab-11ee-a1cd-960002548b4f fill:#808080
style 470a6106-edcd-11ee-b18d-960002548b4f fill:#D3D3D3
style 5fde700b-edcf-11ee-8d31-960002548b4f fill:#ffa500
style 2e8f1a81-e6ca-11ee-889d-960002548b4f fill:#5DAEEC
style ddc8e25b-edd1-11ee-8789-960002548b4f fill:#D3D3D3
style 9ad2b7d8-d7b7-11ee-aa5b-960002548b4f fill:#D3D3D3
style 034c11c9-edd1-11ee-93d0-960002548b4f fill:#76A5AF
style 9ae1a30d-cc17-11ee-88a0-960002548b4f fill:#D3D3D3
style 9ccb6608-edd1-11ee-b1ea-960002548b4f fill:#D3D3D3
style 63567555-cc10-11ee-9937-960002548b4f fill:#5DAEEC
style c868f461-edce-11ee-88e3-960002548b4f fill:#D3D3D3
style bf934d6a-d9fa-11ee-a30c-960002548b4f fill:#ffff00
style 349d2e72-dd2f-11ee-b573-960002548b4f fill:#D3D3D3
style 3cad9490-d7c7-11ee-a3a3-960002548b4f fill:#5DAEEC
style fc175863-dd36-11ee-8bcd-960002548b4f fill:#ffa500
style 248c0a58-dd34-11ee-96b6-960002548b4f fill:#ffa500
style 95874d6e-da22-11ee-91f4-960002548b4f fill:#ffff00
style f87ac63c-d7b7-11ee-a30a-960002548b4f fill:#D3D3D3
style e8dc46dd-d7b7-11ee-8ef9-960002548b4f fill:#ffa500
style 3979bed7-edd1-11ee-8ae6-960002548b4f fill:#ffa500
style 3bbecdd8-edb5-11ee-854f-960002548b4f fill:#ffa500
style f2564375-d7c7-11ee-ba30-960002548b4f fill:#D3D3D3
style 2ecba880-d7ac-11ee-b117-960002548b4f fill:#D3D3D3
style f1a1d793-d7d2-11ee-88c3-960002548b4f fill:#76A5AF
style ef4723f7-dd2c-11ee-9a94-960002548b4f fill:#ffa500
style e5c31f83-dd36-11ee-a688-960002548b4f fill:#ffa500
style 33f35a42-edb1-11ee-9a85-960002548b4f fill:#ffa500
style cd20228b-edcd-11ee-b592-960002548b4f fill:#ffa500
style da1df108-cc12-11ee-aa62-960002548b4f fill:#5DAEEC
style 55c27964-cc0f-11ee-a690-960002548b4f fill:#ffc0cb
style 6b8b4891-d7c9-11ee-bc58-960002548b4f fill:#ffff00
style 417226f6-cc12-11ee-8447-960002548b4f fill:#ffc0cb
style 0de21125-edcd-11ee-b6ec-960002548b4f fill:#ffa500
style 65619c80-d7c7-11ee-9af0-960002548b4f fill:#ffff00
style 7b548bc1-d7c6-11ee-8db6-960002548b4f fill:#D3D3D3
style 366aef7d-da23-11ee-843a-960002548b4f fill:#D3D3D3
style 7bc2b9e9-d7d1-11ee-b535-960002548b4f fill:#ffff00
style 50dba7c2-edb5-11ee-bbd7-960002548b4f fill:#D3D3D3
style ee3fdca2-e755-11ee-9f52-960002548b4f fill:#D3D3D3
style bd86a4d9-edd1-11ee-b5f2-960002548b4f fill:#5DAEEC
style 20f53b6b-cf25-11ee-ac9b-960002548b4f fill:#5DAEEC
style f7f0b171-edcd-11ee-abba-960002548b4f fill:#D3D3D3
style c585cc26-cc05-11ee-876f-960002548b4f fill:#5DAEEC
style de27a123-f1b8-11ee-a1b3-960002548b4f fill:#ffc0cb
style 7f915bae-f1b8-11ee-b67b-960002548b4f fill:#5DAEEC
style 5e113378-edd1-11ee-acaa-960002548b4f fill:#ffff00
style 82ff697e-cc11-11ee-a35c-960002548b4f fill:#5DAEEC
style c810dd40-cc0e-11ee-b600-960002548b4f fill:#ffa500
style c054c98e-cf26-11ee-bf82-960002548b4f fill:#5DAEEC
style 0e151afa-edd1-11ee-9275-960002548b4f fill:#D3D3D3
style bde49fdf-d7ce-11ee-a596-960002548b4f fill:#76A5AF
style 28e8ff25-f1b9-11ee-b585-960002548b4f fill:#D3D3D3
style e0e6f504-e759-11ee-860c-960002548b4f fill:#D3D3D3
style 8e8a22eb-d631-11ee-b9e8-960002548b4f fill:#76A5AF
style 53826280-d7b8-11ee-8261-960002548b4f fill:#D3D3D3
style cc928ec1-edb1-11ee-941f-960002548b4f fill:#D3D3D3
style e2fd7e6f-d7c7-11ee-8e64-960002548b4f fill:#76A5AF
style a68dc7fb-d7d9-11ee-b78a-960002548b4f fill:#D3D3D3
style 014551c1-da02-11ee-b5bd-960002548b4f fill:#ffff00
style 3fe22cb5-cc0b-11ee-a01f-960002548b4f fill:#D3D3D3
style 23e4eb9c-d7d2-11ee-9c8e-960002548b4f fill:#D3D3D3
style fc8f20ab-d7ce-11ee-bb90-960002548b4f fill:#D3D3D3
style 7864a87e-cf2b-11ee-b2ce-960002548b4f fill:#ffc0cb
style 125fa348-f1b9-11ee-9b80-960002548b4f fill:#D3D3D3
style e5a36bd2-d7a9-11ee-9996-960002548b4f fill:#D3D3D3
style 5a67bd0e-e75d-11ee-b8aa-960002548b4f fill:#76A5AF
style 8c64e97c-d7c7-11ee-856b-960002548b4f fill:#C5B4E3
style 511ce710-dd2d-11ee-bc28-960002548b4f fill:#D3D3D3
style d9040c90-cc0f-11ee-8069-960002548b4f fill:#D3D3D3
style 92baaabb-d9f8-11ee-91ea-960002548b4f fill:#ffff00
style 06fbe301-f1b9-11ee-9f1c-960002548b4f fill:#76A5AF
style b7c9c9e8-d9f8-11ee-984f-960002548b4f fill:#D3D3D3
style 0b08146c-edd0-11ee-9320-960002548b4f fill:#D3D3D3
style ed647679-d7ab-11ee-8f64-960002548b4f fill:#D3D3D3
style 9e1673c6-dd2c-11ee-80ab-960002548b4f fill:#ffa500
style 5da1ed2f-d7cd-11ee-a715-960002548b4f fill:#D3D3D3
style ac5efedc-d7d0-11ee-b808-960002548b4f fill:#C5B4E3
style 6f7b22e1-d7d3-11ee-82d3-960002548b4f fill:#C5B4E3
style 60435eae-d7d3-11ee-b537-960002548b4f fill:#ffff00
style 5ae77dfc-d7cc-11ee-a6a6-960002548b4f fill:#ffff00
style a09b43a7-f1b8-11ee-8578-960002548b4f fill:#ffa500
style 6eac09f6-edcd-11ee-ada0-960002548b4f fill:#ffa500
style d0cce7d8-edd1-11ee-87e9-960002548b4f fill:#76A5AF
style 892e123a-edcd-11ee-83ca-960002548b4f fill:#ffa500
style 356208ad-d7b8-11ee-ab26-960002548b4f fill:#808080
style f89610b8-dd34-11ee-b12b-960002548b4f fill:#ffa500
style 91b0b823-cc0f-11ee-9776-960002548b4f fill:#8CBF76
style 50a5e5ba-e75f-11ee-a628-960002548b4f fill:#76A5AF
style 156ba1a0-d7cd-11ee-91be-960002548b4f fill:#C5B4E3
style cdcac76f-f1b8-11ee-9cf9-960002548b4f fill:#D3D3D3
style 46f91387-e75d-11ee-9b3f-960002548b4f fill:#5DAEEC
style 350de3c0-e75d-11ee-b98b-960002548b4f fill:#ffa500
style 15044fd1-dd2d-11ee-8d54-960002548b4f fill:#D3D3D3
style 44aa15f1-e6ca-11ee-8692-960002548b4f fill:#76A5AF
style 49c05ec7-d7c9-11ee-84bc-960002548b4f fill:#D3D3D3
style e3042575-cc0f-11ee-9554-960002548b4f fill:#D3D3D3
style 942df705-d7d2-11ee-96fb-960002548b4f fill:#5DAEEC
style c7a02c01-cfdc-11ee-8e63-960002548b4f fill:#ffc0cb
```
