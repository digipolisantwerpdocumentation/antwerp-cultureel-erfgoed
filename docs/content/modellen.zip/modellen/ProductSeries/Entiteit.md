```mermaid
graph LR
4d27c45e-522b-11ee-974d-00163e71351b["crm:E99_Product_Type"]-->|"crm:P2_has_type"|621a9706-522b-11ee-bc5c-00163e71351b["crm:E55_Type"]
621a9706-522b-11ee-bc5c-00163e71351b["crm:E55_Type"]-.-621a9706-522b-11ee-bc5c-00163e71351b_s(["Fomu type"])
style 621a9706-522b-11ee-bc5c-00163e71351b_s stroke-dasharray: 5
style 4d27c45e-522b-11ee-974d-00163e71351b fill:#ffa500
style 621a9706-522b-11ee-bc5c-00163e71351b fill:#ffa500
```
