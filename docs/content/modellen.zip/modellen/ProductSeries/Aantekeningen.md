```mermaid
graph LR
4d27c45e-522b-11ee-974d-00163e71351b["crm:E99_Product_Type"]-->|"crm:P3_has_note"|6e43045a-522b-11ee-b0c4-00163e71351b(rdfs:Literal)
style 6e43045a-522b-11ee-b0c4-00163e71351b_s stroke-dasharray: 5
6e43045a-522b-11ee-b0c4-00163e71351b["rdfs:Literal"]-.-6e43045a-522b-11ee-b0c4-00163e71351b_s(["Opmerking tekst"])
style 6e43045a-522b-11ee-b0c4-00163e71351b fill:#D3D3D3
```
