```mermaid
graph LR
fa95cea2-dd27-11ed-9655-00163e71351b["crm:E22_Human-Made_Object"]-->|"crm:P24i_changed_ownership_through"|2912c76c-62c5-11ee-b0c4-00163e71351b["crm:E8_Acquisition"]
2912c76c-62c5-11ee-b0c4-00163e71351b["crm:E8_Acquisition"]-.-2912c76c-62c5-11ee-b0c4-00163e71351b_s(["Verwerving"])
style 2912c76c-62c5-11ee-b0c4-00163e71351b_s stroke-dasharray: 5
style 2912c76c-62c5-11ee-b0c4-00163e71351b fill:#5DAEEC
style fa95cea2-dd27-11ed-9655-00163e71351b fill:#B0927A
```
